<?php
// ── Simple PHP session / page routing ──────────────────────────────
session_start();
require_once __DIR__ . '/session_guard.php';

// Currently logged-in admin (set at login in signin.php)
$admin = [
  'name'  => $_SESSION['admin_name']  ?? 'Admin',
  'role'  => $_SESSION['admin_role']  ?? 'Admin',
  'email' => $_SESSION['admin_email'] ?? '',
];

// Active page from query string
$page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'dashboard';

// ── Role permission helpers ─────────────────────────────────────────
$role = $admin['role'];

// Pages each role can access
$role_pages = [
  'Super Admin' => ['dashboard','messages','portfolio','portfoliotiles','mainwall','aboutus','clientlogos','ourclients','invoice','quotation','usermgmt'],
  'Admin'       => ['dashboard','messages','portfolio','portfoliotiles','mainwall','aboutus','clientlogos','ourclients','invoice','quotation'],
  'Editor'      => ['dashboard','portfolio'],
  'Viewer'      => ['dashboard','messages','portfolio','invoice','quotation'],
];

$allowed_pages = $role_pages[$role] ?? ['dashboard'];

// Redirect to dashboard if trying to access a page not allowed
if (!in_array($page, $allowed_pages)) {
  $page = 'dashboard';
}

// Helper: can current role access a feature?
function canAccess($feature) {
  global $role;
  $perms = [
    'portfoliotiles'    => ['Super Admin','Admin'],
    'mainwall'          => ['Super Admin','Admin'],
    'aboutus'           => ['Super Admin','Admin'],
    'clientlogos'       => ['Super Admin','Admin'],
    'clients'           => ['Super Admin','Admin'],
    'invoice'           => ['Super Admin','Admin','Viewer'],
    'quotation'         => ['Super Admin','Admin','Viewer'],
    'usermgmt'          => ['Super Admin'],
    'portfolio_add'     => ['Super Admin','Admin','Editor'],
    'portfolio_delete'  => ['Super Admin','Admin'],
    'finance'           => ['Super Admin','Admin'],
    'messages'          => ['Super Admin','Admin','Viewer'],
  ];
  return in_array($role, $perms[$feature] ?? ['Super Admin']);
}

// Admin users are loaded live from Firestore via signin.php (list_admins action) — see umLoadAdmins() in JS.
// $role_permissions below is just static permission *labels* per role (not user data), kept as-is.

$role_permissions = [
  'Super Admin' => ['Full system access', 'Manage all admins', 'Delete records', 'Financial data', 'Settings'],
  'Admin'       => ['Manage content', 'Manage clients', 'Generate invoices', 'View reports'],
  'Editor'      => ['Edit portfolio', 'Edit client info', 'View invoices'],
  'Viewer'      => ['View-only access', 'Export reports'],
];

// Status badge helper
function statusBadge($s) {
  $map = [
    'completed'   => ['bg'=>'#dcfce7','color'=>'#15803d','dot'=>'#22c55e'],
    'in progress' => ['bg'=>'#dbeafe','color'=>'#1d4ed8','dot'=>'#3b82f6'],
    'review'      => ['bg'=>'#fef9c3','color'=>'#92400e','dot'=>'#eab308'],
    'pending'     => ['bg'=>'#fee2e2','color'=>'#b91c1c','dot'=>'#ef4444'],
    'active'      => ['bg'=>'#dcfce7','color'=>'#15803d','dot'=>'#22c55e'],
    'inactive'    => ['bg'=>'#f3f4f6','color'=>'#374151','dot'=>'#9ca3af'],
  ];
  $c = $map[$s] ?? ['bg'=>'#f3f4f6','color'=>'#374151','dot'=>'#9ca3af'];
  return "<span style='background:{$c['bg']};color:{$c['color']};padding:3px 10px;border-radius:50px;font-size:.73rem;font-weight:700;display:inline-flex;align-items:center;gap:5px;'>
    <span style='width:7px;height:7px;border-radius:50%;background:{$c['dot']};display:inline-block;'></span>
    ".ucfirst($s)."</span>";
}

function roleBadge($role) {
  $map = [
    'Super Admin' => ['bg'=>'#ede9fe','color'=>'#6d28d9'],
    'Admin'       => ['bg'=>'#dbeafe','color'=>'#1d4ed8'],
    'Editor'      => ['bg'=>'#fef3c7','color'=>'#b45309'],
    'Viewer'      => ['bg'=>'#f3f4f6','color'=>'#374151'],
  ];
  $c = $map[$role] ?? ['bg'=>'#f3f4f6','color'=>'#374151'];
  return "<span style='background:{$c['bg']};color:{$c['color']};padding:3px 11px;border-radius:50px;font-size:.73rem;font-weight:700;'>{$role}</span>";
}

// Initials helper
function initials($name) {
  $parts = explode(' ', $name);
  return strtoupper(substr($parts[0],0,1) . (isset($parts[2]) ? substr($parts[2],0,1) : (isset($parts[1]) ? substr($parts[1],0,1) : '')));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Creative4 – Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"/>
<style>
  :root {
    --cyan:      #0ea5e9;
    --cyan-dark: #0284c7;
    --cyan-mid:  #38bdf8;
    --cyan-pale: #e0f2fe;
    --cyan-bg:   #f0f9ff;
    --sidebar-w: 230px;
    --dark:      #0f172a;
    --text:      #1e293b;
    --muted:     #64748b;
    --border:    #e2e8f0;
    --white:     #ffffff;
    --card-r:    14px;
    --danger:    #ef4444;
    --success:   #22c55e;
    --purple:    #7c3aed;
  }

  *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
  html, body { height:100%; }
  body {
    font-family:'DM Sans', sans-serif;
    background: var(--cyan-bg);
    color: var(--text);
    overflow-x:hidden;
  }

  /* ══ SIDEBAR ══════════════════════════════════════ */
  .sidebar {
    position:fixed; top:0; left:0; bottom:0;
    width: var(--sidebar-w);
    background: linear-gradient(180deg, #0369a1 0%, #0284c7 40%, #0ea5e9 100%);
    display:flex; flex-direction:column;
    z-index:900;
    box-shadow: 4px 0 24px rgba(2,132,199,.25);
    transition: width .3s;
  }

  .sidebar-logo {
    padding: 22px 20px 18px;
    border-bottom: 1px solid rgba(255,255,255,.15);
    display:flex; align-items:center; gap:10px;
  }
  .logo-mark {
    width:42px; height:42px; border-radius:10px;
    background:#fff;
    display:flex; align-items:center; justify-content:center;
    flex-shrink:0;
    box-shadow: 0 4px 12px rgba(0,0,0,.15);
  }
  .logo-mark span {
    font-family:'Bebas Neue', sans-serif;
    font-size:1.35rem; letter-spacing:1px;
    color: var(--cyan-dark); line-height:1;
  }
  .logo-text {
    font-family:'Bebas Neue', sans-serif;
    font-size:1.5rem; letter-spacing:2px;
    color:#fff; line-height:1;
  }
  .logo-text small {
    display:block; font-family:'DM Sans', sans-serif;
    font-size:.6rem; font-weight:500; letter-spacing:2px;
    text-transform:uppercase; color:rgba(255,255,255,.6);
    margin-top:1px;
  }

  .sidebar-nav { flex:1; padding:18px 0; overflow-y:auto; }
  .sidebar-nav::-webkit-scrollbar { width:0; }

  .nav-section-label {
    font-size:.64rem; font-weight:700; letter-spacing:2px;
    text-transform:uppercase; color:rgba(255,255,255,.45);
    padding:10px 22px 6px;
  }

  .sidebar-link {
    display:flex; align-items:center; gap:12px;
    padding:11px 22px;
    color:rgba(255,255,255,.8);
    text-decoration:none;
    font-size:.88rem; font-weight:500;
    border-left:3px solid transparent;
    transition: all .22s; position:relative;
  }
  .sidebar-link i { width:20px; text-align:center; font-size:.95rem; flex-shrink:0; }
  .sidebar-link:hover { color:#fff; background:rgba(255,255,255,.12); border-left-color:rgba(255,255,255,.5); }
  .sidebar-link.active { color:#fff; background:rgba(255,255,255,.18); border-left-color:#fff; font-weight:700; }
  .sidebar-link .badge-pill {
    margin-left:auto;
    background:rgba(255,255,255,.25);
    color:#fff; font-size:.65rem; font-weight:700;
    padding:2px 8px; border-radius:50px;
  }

  .sidebar-footer {
    padding:16px 20px;
    border-top:1px solid rgba(255,255,255,.15);
    display:flex; align-items:center; gap:10px;
  }
  .sidebar-footer .avatar {
    width:36px; height:36px; border-radius:50%;
    background:rgba(255,255,255,.25);
    display:flex; align-items:center; justify-content:center;
    font-weight:700; font-size:.85rem; color:#fff; flex-shrink:0;
  }
  .sidebar-footer .info { flex:1; min-width:0; }
  .sidebar-footer .info .name { font-size:.82rem; font-weight:700; color:#fff; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .sidebar-footer .info .role { font-size:.68rem; color:rgba(255,255,255,.6); margin-top:1px; }
  .sidebar-footer .logout-btn { color:rgba(255,255,255,.6); font-size:.9rem; background:none; border:none; cursor:pointer; transition:color .2s; padding:4px; }
  .sidebar-footer .logout-btn:hover { color:#fff; }

  /* ══ MAIN CONTENT ══════════════════════════════════ */
  .main-wrap { margin-left: var(--sidebar-w); min-height:100vh; display:flex; flex-direction:column; }

  .topbar {
    height:64px; background:#fff; border-bottom:1px solid var(--border);
    display:flex; align-items:center; padding:0 28px; gap:16px;
    position:sticky; top:0; z-index:800;
    box-shadow:0 1px 8px rgba(0,0,0,.06);
  }
  .topbar .page-title { font-family:'Bebas Neue', sans-serif; font-size:1.7rem; letter-spacing:2px; color: var(--dark); flex:1; }
  .topbar .search-wrap { position:relative; flex:0 0 260px; }
  .topbar .search-wrap i { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--muted); font-size:.85rem; }
  .topbar .search-wrap input { width:100%; border:1px solid var(--border); border-radius:50px; padding:7px 16px 7px 36px; font-size:.85rem; outline:none; font-family:'DM Sans', sans-serif; background:var(--cyan-bg); transition:border-color .2s; }
  .topbar .search-wrap input:focus { border-color:var(--cyan); }
  .topbar .topbar-actions { display:flex; align-items:center; gap:10px; }
  .topbar .icon-btn { width:38px; height:38px; border-radius:50%; border:1px solid var(--border); background:#fff; display:flex; align-items:center; justify-content:center; color:var(--muted); cursor:pointer; transition:all .2s; position:relative; }
  .topbar .icon-btn:hover { border-color:var(--cyan); color:var(--cyan); }
  .topbar .icon-btn .dot { position:absolute; top:6px; right:6px; width:8px; height:8px; border-radius:50%; background:#ef4444; border:2px solid #fff; }
  .topbar .admin-chip { display:flex; align-items:center; gap:9px; background:var(--cyan-pale); border-radius:50px; padding:5px 14px 5px 5px; cursor:pointer; }
  .topbar .admin-chip .av { width:30px; height:30px; border-radius:50%; background: linear-gradient(135deg, var(--cyan-dark), var(--cyan)); display:flex; align-items:center; justify-content:center; color:#fff; font-size:.75rem; font-weight:700; }
  .topbar .admin-chip .info .n { font-size:.82rem; font-weight:700; color:var(--dark); }
  .topbar .admin-chip .info .r { font-size:.68rem; color:var(--muted); }

  /* ══ TOPBAR NOTIFICATION/MESSAGE PANELS ══════════════ */
  .topbar-panel {
    display:none; position:absolute; top:48px; right:0; width:320px; max-height:380px;
    overflow-y:auto; background:#fff; border:1px solid var(--border); border-radius:12px;
    box-shadow:0 14px 40px rgba(15,23,42,.16); z-index:1200;
  }
  .topbar-panel.show { display:block; animation:fadeOverlay .18s ease; }
  .topbar-panel-head { display:flex; align-items:center; justify-content:space-between; padding:12px 16px; font-weight:700; font-size:.85rem; border-bottom:1px solid var(--border); position:sticky; top:0; background:#fff; }
  .topbar-panel-empty { padding:24px 16px; text-align:center; color:var(--muted); font-size:.82rem; }
  .topbar-panel-item { padding:11px 16px; border-bottom:1px solid #f1f5f9; cursor:pointer; transition:background .15s; }
  .topbar-panel-item:hover { background:#f8fafc; }
  .topbar-panel-item.unread { background:#f0f9ff; }
  .topbar-panel-item .tpi-top { display:flex; justify-content:space-between; align-items:baseline; gap:8px; }
  .topbar-panel-item .tpi-name { font-size:.83rem; font-weight:700; color:var(--dark); }
  .topbar-panel-item .tpi-time { font-size:.68rem; color:var(--muted); white-space:nowrap; }
  .topbar-panel-item .tpi-msg { font-size:.78rem; color:var(--muted); margin-top:2px; overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; }

  /* ══ CONTENT AREA ══════════════════════════════════ */
  .content-area { flex:1; padding:28px; }

  /* Stat cards */
  .stat-card { background:#fff; border-radius:var(--card-r); padding:22px 22px; display:flex; align-items:center; gap:16px; box-shadow:0 2px 12px rgba(14,165,233,.08); border:1px solid var(--border); transition: transform .25s, box-shadow .25s; }
  .stat-card:hover { transform:translateY(-3px); box-shadow:0 8px 28px rgba(14,165,233,.15); }
  .stat-card.accent { background: linear-gradient(135deg, var(--cyan-dark) 0%, var(--cyan) 100%); color:#fff; border:none; box-shadow:0 8px 24px rgba(14,165,233,.35); }
  .stat-icon { width:52px; height:52px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.3rem; flex-shrink:0; }
  .stat-card:not(.accent) .stat-icon { background:var(--cyan-pale); color:var(--cyan-dark); }
  .stat-card.accent .stat-icon { background:rgba(255,255,255,.2); color:#fff; }
  .stat-value { font-family:'Bebas Neue', sans-serif; font-size:2.1rem; letter-spacing:1px; line-height:1; }
  .stat-label { font-size:.78rem; font-weight:500; letter-spacing:.3px; opacity:.7; margin-top:2px; }

  /* Section card */
  .section-card { background:#fff; border-radius:var(--card-r); border:1px solid var(--border); box-shadow:0 2px 12px rgba(14,165,233,.06); overflow:hidden; }
  .section-head { padding:18px 22px; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
  .section-head h5 { font-family:'Bebas Neue', sans-serif; font-size:1.2rem; letter-spacing:1.5px; color:var(--dark); margin:0; }
  .see-all-btn { background:var(--cyan); color:#fff; font-size:.75rem; font-weight:700; font-family:'DM Sans', sans-serif; letter-spacing:.5px; text-transform:uppercase; border:none; border-radius:50px; padding:5px 16px; cursor:pointer; transition:background .2s; }
  .see-all-btn:hover { background:var(--cyan-dark); }

  /* Projects table */
  .proj-table { width:100%; border-collapse:collapse; }
  .proj-table th { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.8px; color:var(--muted); padding:10px 20px; text-align:left; background:#f8fafc; border-bottom:1px solid var(--border); }
  .proj-table td { padding:11px 20px; font-size:.85rem; border-bottom:1px solid #f1f5f9; vertical-align:middle; }
  .proj-table tr:last-child td { border-bottom:none; }
  .proj-table tr:hover td { background:#f8fafc; }
  .proj-title { font-weight:600; color:var(--dark); }
  .proj-dept  { color:var(--muted); font-size:.8rem; }

  /* Client list */
  .client-item { display:flex; align-items:center; gap:13px; padding:11px 20px; border-bottom:1px solid #f1f5f9; transition:background .2s; }
  .client-item:last-child { border-bottom:none; }
  .client-item:hover { background:#f8fafc; }
  .client-av { width:38px; height:38px; border-radius:50%; flex-shrink:0; background: linear-gradient(135deg, var(--cyan-dark), var(--cyan-mid)); display:flex; align-items:center; justify-content:center; color:#fff; font-size:.78rem; font-weight:700; box-shadow:0 2px 8px rgba(14,165,233,.3); }
  .client-info .name { font-size:.87rem; font-weight:600; color:var(--dark); }
  .client-info .role { font-size:.72rem; color:var(--muted); }
  .client-actions { margin-left:auto; display:flex; gap:6px; }
  .client-actions .act-btn { width:30px; height:30px; border-radius:8px; border:1px solid var(--border); background:#fff; display:flex; align-items:center; justify-content:center; color:var(--muted); font-size:.8rem; cursor:pointer; transition:all .2s; }
  .client-actions .act-btn:hover { border-color:var(--cyan); color:var(--cyan); background:var(--cyan-pale); }

  /* Forms */
  .form-panel { padding:24px; }
  .form-panel .form-label { font-size:.78rem; font-weight:700; text-transform:uppercase; letter-spacing:.6px; color:var(--muted); margin-bottom:5px; }
  .form-panel .form-control, .form-panel .form-select { border:1px solid var(--border); border-radius:8px; font-family:'DM Sans', sans-serif; font-size:.88rem; padding:9px 14px; outline:none; transition:border-color .2s, box-shadow .2s; background:#fff; }
  .form-panel .form-control:focus, .form-panel .form-select:focus { border-color:var(--cyan); box-shadow:0 0 0 3px rgba(14,165,233,.12); }
  .line-item-row { background:#f8fafc; border-radius:10px; padding:12px 14px; margin-bottom:10px; }

  .btn-cyan { background: linear-gradient(135deg, var(--cyan-dark), var(--cyan)); color:#fff; border:none; border-radius:8px; padding:10px 26px; font-weight:700; font-size:.88rem; font-family:'DM Sans', sans-serif; cursor:pointer; transition:opacity .2s; box-shadow:0 4px 14px rgba(14,165,233,.35); }
  .btn-cyan:hover { opacity:.88; }
  .btn-outline-cyan { background:none; border:1.5px solid var(--cyan); color:var(--cyan); border-radius:8px; padding:9px 22px; font-weight:700; font-size:.88rem; font-family:'DM Sans', sans-serif; cursor:pointer; transition:all .2s; }
  .btn-outline-cyan:hover { background:var(--cyan); color:#fff; }

  /* Invoice preview */
  .invoice-preview { background:#fff; border-radius:var(--card-r); border:1px solid var(--border); padding:30px 32px; }
  .invoice-preview .inv-header { display:flex; justify-content:space-between; align-items:flex-start; padding-bottom:20px; border-bottom:2px solid var(--cyan-pale); margin-bottom:20px; }
  .inv-logo { font-family:'Bebas Neue', sans-serif; font-size:2rem; color:var(--cyan-dark); letter-spacing:2px; }
  .inv-logo small { display:block; font-family:'DM Sans', sans-serif; font-size:.62rem; color:var(--muted); font-weight:500; letter-spacing:1px; }
  .doc-logo-img { display:block; height:34px; width:auto; margin-bottom:6px; }
  .invoice-preview .inv-header small { display:block; font-family:'DM Sans', sans-serif; font-size:.62rem; color:var(--muted); font-weight:500; line-height:1.5; }
  .doc-footer-row { display:flex; align-items:flex-end; justify-content:space-between; gap:14px; margin-top:14px; }
  .doc-footer-row .doc-disclaimer { flex:1; margin-top:0; border-top:1px solid var(--border); padding-top:10px; }
  .doc-qr-img { width:64px; height:64px; object-fit:contain; border:1px solid var(--border); border-radius:6px; padding:3px; background:#fff; flex-shrink:0; }
  .inv-title { font-family:'Bebas Neue', sans-serif; font-size:2.5rem; letter-spacing:3px; color:var(--cyan); }
  .inv-table { width:100%; border-collapse:collapse; margin:16px 0; }
  .inv-table th { background:var(--cyan-pale); color:var(--cyan-dark); font-size:.75rem; font-weight:700; text-transform:uppercase; letter-spacing:.5px; padding:8px 12px; }
  .inv-table td { padding:8px 12px; font-size:.85rem; border-bottom:1px solid #f1f5f9; }
  .inv-total-box { background:var(--cyan-pale); border-radius:10px; padding:14px 20px; text-align:right; }
  .inv-total-box .total-label { font-size:.78rem; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; }
  .inv-total-box .total-val { font-family:'Bebas Neue', sans-serif; font-size:2rem; color:var(--cyan-dark); }
  /* ── Terms & Conditions checklist (invoice / quotation) ── */
  .tc-checklist { border:1px solid var(--border); border-radius:8px; padding:10px 14px; max-height:190px; overflow-y:auto; background:#fff; }
  .tc-check-item { font-size:.83rem; padding:3px 0; }
  .tc-check-item .form-check-label { color:#334155; cursor:pointer; }
  /* ── Rendered terms block inside invoice/quotation preview ── */
  .doc-terms-block { margin-top:16px; padding-top:14px; border-top:1px solid var(--border); font-size:.78rem; color:#334155; }
  .doc-terms-title { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.6px; color:var(--cyan-dark); background:var(--cyan-pale); display:inline-block; padding:3px 10px; border-radius:4px; margin-bottom:8px; }
  .doc-terms-cat { font-weight:700; font-size:.8rem; color:#0f172a; margin-top:10px; }
  .doc-terms-subhead { font-weight:700; font-size:.75rem; color:var(--cyan-dark); margin-top:6px; }
  .doc-terms-list { margin:4px 0 0 0; padding-left:18px; }
  .doc-terms-list li { margin-bottom:2px; line-height:1.4; }
  /* ── Bank details box ── */
  .doc-bank-box { margin-top:16px; background:var(--cyan-pale); border-radius:10px; padding:12px 16px; font-size:.8rem; color:#0f172a; }
  .doc-bank-title { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.6px; color:var(--cyan-dark); margin-bottom:4px; }
  .doc-disclaimer { margin-top:14px; font-size:.72rem; color:var(--muted); font-style:italic; border-top:1px solid var(--border); padding-top:10px; }
  /* ── Advance / Balance box (invoice) ── */
  .balance-box { border:1px solid var(--border); border-radius:10px; padding:10px 16px; }
  .balance-row { display:flex; justify-content:space-between; font-size:.85rem; color:var(--muted); padding:4px 0; }
  .balance-row strong { color:#0f172a; }
  .balance-row.balance-due { border-top:1px solid var(--border); margin-top:4px; padding-top:8px; }
  .balance-row.balance-due span, .balance-row.balance-due strong { color:var(--cyan-dark); font-weight:700; }

  /* ══ USER MANAGEMENT ══════════════════════════════ */

  /* Stats row for user mgmt */
  .um-stat {
    background:#fff; border-radius:var(--card-r);
    padding:18px 20px; border:1px solid var(--border);
    box-shadow:0 2px 12px rgba(14,165,233,.06);
    display:flex; align-items:center; gap:14px;
    transition:transform .25s, box-shadow .25s;
  }
  .um-stat:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(14,165,233,.12); }
  .um-stat-icon { width:46px; height:46px; border-radius:11px; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; }
  .um-stat-val { font-family:'Bebas Neue', sans-serif; font-size:1.8rem; letter-spacing:1px; line-height:1; color:var(--dark); }
  .um-stat-lbl { font-size:.75rem; font-weight:600; color:var(--muted); margin-top:2px; }

  /* Admin table */
  .admin-table { width:100%; border-collapse:collapse; }
  .admin-table th { font-size:.71rem; font-weight:700; text-transform:uppercase; letter-spacing:.8px; color:var(--muted); padding:11px 20px; text-align:left; background:#f8fafc; border-bottom:1px solid var(--border); white-space:nowrap; }
  .admin-table td { padding:13px 20px; font-size:.85rem; border-bottom:1px solid #f1f5f9; vertical-align:middle; }
  .admin-table tr:last-child td { border-bottom:none; }
  .admin-table tr:hover td { background:#f8fafc; }

  .admin-av {
    width:38px; height:38px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    font-size:.78rem; font-weight:700; color:#fff; flex-shrink:0;
  }
  .admin-av.super { background: linear-gradient(135deg,#7c3aed,#a78bfa); box-shadow:0 2px 8px rgba(124,58,237,.3); }
  .admin-av.admin { background: linear-gradient(135deg,var(--cyan-dark),var(--cyan)); box-shadow:0 2px 8px rgba(14,165,233,.3); }
  .admin-av.editor { background: linear-gradient(135deg,#d97706,#fbbf24); box-shadow:0 2px 8px rgba(217,119,6,.3); }
  .admin-av.viewer { background: linear-gradient(135deg,#475569,#94a3b8); box-shadow:0 2px 8px rgba(71,85,105,.2); }

  .admin-name { font-weight:700; color:var(--dark); font-size:.88rem; }
  .admin-email { font-size:.76rem; color:var(--muted); margin-top:1px; }

  .act-btn { width:30px; height:30px; border-radius:8px; border:1px solid var(--border); background:#fff; display:inline-flex; align-items:center; justify-content:center; color:var(--muted); font-size:.8rem; cursor:pointer; transition:all .2s; }
  .act-btn:hover { border-color:var(--cyan); color:var(--cyan); background:var(--cyan-pale); }
  .act-btn.danger:hover { border-color:var(--danger); color:var(--danger); background:#fee2e2; }

  /* Permissions panel */
  .perm-list { list-style:none; padding:0; margin:0; }
  .perm-list li { display:flex; align-items:center; gap:8px; font-size:.82rem; color:var(--text); padding:5px 0; border-bottom:1px solid var(--border); }
  .perm-list li:last-child { border-bottom:none; }
  .perm-list li i { color:var(--cyan); font-size:.78rem; }

  .role-card {
    border:2px solid var(--border); border-radius:12px;
    padding:14px 16px; cursor:pointer;
    transition:all .22s;
  }
  .role-card:hover { border-color:var(--cyan); background:var(--cyan-pale); }
  .role-card.selected { border-color:var(--cyan); background:var(--cyan-pale); }
  .role-card .role-title { font-weight:700; font-size:.9rem; color:var(--dark); }
  .role-card .role-count { font-size:.72rem; color:var(--muted); margin-top:2px; }

  /* ══ MODAL ══════════════════════════════════════════ */
  .modal-overlay {
    display:none; position:fixed; inset:0;
    background:rgba(15,23,42,.55);
    backdrop-filter:blur(4px);
    z-index:1100;
    align-items:center; justify-content:center;
  }
  .modal-overlay.show { display:flex; animation:fadeOverlay .22s ease; }
  @keyframes fadeOverlay { from{opacity:0} to{opacity:1} }

  .modal-box {
    background:#fff; border-radius:18px;
    width:100%; max-width:520px;
    max-height:92vh; overflow-y:auto;
    box-shadow:0 24px 80px rgba(0,0,0,.2);
    animation:slideUp .28s cubic-bezier(.34,1.56,.64,1);
    position:relative;
  }
  @keyframes slideUp { from{opacity:0;transform:translateY(30px) scale(.97)} to{opacity:1;transform:none} }

  .modal-box::-webkit-scrollbar { width:4px; }
  .modal-box::-webkit-scrollbar-thumb { background:var(--border); border-radius:4px; }

  .modal-header {
    padding:22px 26px 18px;
    border-bottom:1px solid var(--border);
    display:flex; align-items:center; justify-content:space-between;
    position:sticky; top:0; background:#fff; z-index:1;
  }
  .modal-header h4 { font-family:'Bebas Neue', sans-serif; font-size:1.4rem; letter-spacing:1.5px; color:var(--dark); margin:0; }
  .modal-close { background:none; border:none; font-size:1.1rem; color:var(--muted); cursor:pointer; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; transition:all .2s; }
  .modal-close:hover { background:#f1f5f9; color:var(--dark); }
  .modal-body { padding:22px 26px; }
  .modal-footer { padding:16px 26px 22px; display:flex; justify-content:flex-end; gap:10px; }

  .form-label-um { font-size:.75rem; font-weight:700; text-transform:uppercase; letter-spacing:.6px; color:var(--muted); margin-bottom:5px; display:block; }
  .form-ctrl { width:100%; border:1.5px solid var(--border); border-radius:8px; font-family:'DM Sans', sans-serif; font-size:.88rem; padding:10px 14px; outline:none; transition:border-color .2s, box-shadow .2s; background:#fff; }
  .form-ctrl:focus { border-color:var(--cyan); box-shadow:0 0 0 3px rgba(14,165,233,.12); }
  .form-ctrl.error { border-color:var(--danger); box-shadow:0 0 0 3px rgba(239,68,68,.1); }
  .field-error { font-size:.74rem; color:var(--danger); margin-top:4px; display:none; }
  .field-error.show { display:block; }

  /* Role selector inside modal */
  .role-selector { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:6px; }
  .role-opt {
    border:1.5px solid var(--border); border-radius:10px;
    padding:10px 14px; cursor:pointer; transition:all .2s;
    display:flex; align-items:center; gap:8px;
  }
  .role-opt:hover { border-color:var(--cyan); }
  .role-opt.selected { border-color:var(--cyan); background:var(--cyan-pale); }
  .role-opt .ro-icon { width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:.85rem; flex-shrink:0; }
  .role-opt .ro-name { font-size:.84rem; font-weight:700; color:var(--dark); }
  .role-opt .ro-desc { font-size:.7rem; color:var(--muted); margin-top:1px; }
  .role-opt input[type=radio] { display:none; }

  /* Password strength */
  .pw-strength { height:4px; border-radius:4px; margin-top:8px; background:var(--border); overflow:hidden; }
  .pw-strength-bar { height:100%; border-radius:4px; transition:width .4s, background .4s; width:0; }
  .pw-hint { font-size:.73rem; color:var(--muted); margin-top:5px; }

  /* Toggle switch */
  .toggle-wrap { display:flex; align-items:center; gap:10px; }
  .toggle { position:relative; width:42px; height:24px; }
  .toggle input { opacity:0; width:0; height:0; }
  .toggle-slider { position:absolute; inset:0; background:var(--border); border-radius:50px; cursor:pointer; transition:.3s; }
  .toggle-slider:before { content:''; position:absolute; width:18px; height:18px; left:3px; top:3px; background:#fff; border-radius:50%; transition:.3s; box-shadow:0 1px 4px rgba(0,0,0,.2); }
  .toggle input:checked + .toggle-slider { background:var(--cyan); }
  .toggle input:checked + .toggle-slider:before { transform:translateX(18px); }
  .toggle-label { font-size:.84rem; font-weight:600; color:var(--text); }

  /* Toast notification */
  .toast-wrap { position:fixed; bottom:28px; right:28px; z-index:9999; display:flex; flex-direction:column; gap:10px; pointer-events:none; }
  .toast {
    background:#fff; border-radius:12px;
    padding:14px 18px; display:flex; align-items:center; gap:12px;
    box-shadow:0 8px 32px rgba(0,0,0,.15);
    border-left:4px solid var(--cyan);
    min-width:280px; pointer-events:all;
    animation:toastIn .35s cubic-bezier(.34,1.56,.64,1);
  }
  .toast.success { border-left-color:var(--success); }
  .toast.danger  { border-left-color:var(--danger); }
  .toast .ti { font-size:1.1rem; }
  .toast.success .ti { color:var(--success); }
  .toast.danger  .ti { color:var(--danger); }
  .toast.info    .ti { color:var(--cyan); }
  .toast .tm { font-size:.85rem; font-weight:600; color:var(--dark); }
  @keyframes toastIn { from{opacity:0;transform:translateX(40px)} to{opacity:1;transform:none} }

  /* Delete confirm modal */
  .del-modal { max-width:380px; text-align:center; padding:32px 28px; }
  .del-icon { width:64px; height:64px; border-radius:50%; background:#fee2e2; color:var(--danger); font-size:1.6rem; display:flex; align-items:center; justify-content:center; margin:0 auto 16px; }
  .del-title { font-family:'Bebas Neue', sans-serif; font-size:1.4rem; letter-spacing:1px; color:var(--dark); margin-bottom:8px; }
  .del-msg { font-size:.85rem; color:var(--muted); line-height:1.6; }
  .btn-danger { background: linear-gradient(135deg,#dc2626,#ef4444); color:#fff; border:none; border-radius:8px; padding:10px 26px; font-weight:700; font-size:.88rem; font-family:'DM Sans', sans-serif; cursor:pointer; transition:opacity .2s; box-shadow:0 4px 14px rgba(239,68,68,.3); }
  .btn-danger:hover { opacity:.88; }

  /* Page section hide/show */
  .page-section { display:none; }
  .page-section.active { display:block; animation:fadeIn .35s ease; }
  @keyframes fadeIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }

  /* Hamburger mobile */
  .topbar-toggle { background:none; border:none; color:var(--dark); font-size:1.2rem; cursor:pointer; display:none; padding:4px; }

  @media (max-width:768px) {
    .sidebar { transform:translateX(-100%); transition:transform .3s; }
    .sidebar.open { transform:translateX(0); }
    .sidebar-backdrop { display:none; position:fixed; inset:0; background:rgba(15,23,42,.5); z-index:890; }
    .sidebar-backdrop.show { display:block; }
    .main-wrap { margin-left:0; }
    .topbar-toggle { display:block; }
    .content-area { padding:16px; }
    .role-selector { grid-template-columns:1fr; }

    /* Topbar: drop the search box, shrink title, hide admin name/role text */
    .topbar { padding:0 14px; gap:8px; }
    .topbar .page-title { font-size:1.25rem; }
    .topbar .search-wrap { display:none; }
    .topbar .admin-chip .info { display:none; }
    .topbar .admin-chip { padding:4px; gap:0; }

    /* Notification/message dropdown panels: stay on-screen */
    .topbar-panel { position:fixed; top:60px; right:10px; left:10px; width:auto; max-height:70vh; }

    /* Modals: don't touch screen edges */
    .modal-overlay { padding:14px; }
    .modal-box { max-width:100%; }

    /* Section headers with buttons: stack instead of overflowing */
    .section-head { flex-wrap:wrap; gap:8px; }

    /* Generic tables: smaller text/padding so more columns fit before scrolling */
    .proj-table th, .proj-table td { padding:9px 12px; font-size:.78rem; }
    .admin-table th, .admin-table td { padding:9px 12px; font-size:.78rem; }
  }

  @media (max-width:480px) {
    .topbar .page-title { font-size:1.05rem; }
    .stat-value { font-size:1.3rem !important; }
    .um-stat-val { font-size:1.1rem !important; }
  }

  /* Search / filter bar */
  .filter-bar { background:#fff; border-radius:12px; border:1px solid var(--border); padding:14px 18px; display:flex; flex-wrap:wrap; gap:10px; align-items:center; margin-bottom:18px; }
  .filter-bar .fb-search { position:relative; flex:1; min-width:180px; }
  .filter-bar .fb-search i { position:absolute; left:11px; top:50%; transform:translateY(-50%); color:var(--muted); font-size:.82rem; }
  .filter-bar .fb-search input { width:100%; border:1.5px solid var(--border); border-radius:8px; padding:8px 12px 8px 32px; font-size:.84rem; font-family:'DM Sans', sans-serif; outline:none; transition:border-color .2s; }
  .filter-bar .fb-search input:focus { border-color:var(--cyan); }
  .filter-bar select { border:1.5px solid var(--border); border-radius:8px; padding:8px 12px; font-size:.84rem; font-family:'DM Sans', sans-serif; outline:none; color:var(--text); cursor:pointer; transition:border-color .2s; }
  .filter-bar select:focus { border-color:var(--cyan); }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
</head>
<body>

<!-- ════ SIDEBAR ════════════════════════════════════ -->
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-mark"><span>C4</span></div>
    <div class="logo-text">CREATIVE<span style="color:rgba(255,255,255,.5)">4</span>
      <small>The Ultimate Imagination</small>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section-label">Main Menu</div>
    <a href="?page=dashboard" class="sidebar-link <?= $page==='dashboard' ? 'active':'' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
    <?php if(canAccess('messages')): ?>
    <a href="?page=messages" class="sidebar-link <?= $page==='messages' ? 'active':'' ?>"><i class="fas fa-envelope-open-text"></i> Messages <span class="badge-pill" id="sidebar-msg-count" style="display:none;">0</span></a>
    <?php endif; ?>
    <a href="?page=portfolio" class="sidebar-link <?= $page==='portfolio' ? 'active':'' ?>"><i class="fas fa-images"></i> Portfolio</a>
    <?php if(canAccess('portfoliotiles')): ?>
    <a href="?page=portfoliotiles" class="sidebar-link <?= $page==='portfoliotiles' ? 'active':'' ?>"><i class="fas fa-th-large"></i> Portfolio Tiles</a>
    <?php endif; ?>
    <?php if(canAccess('mainwall')): ?>
    <a href="?page=mainwall" class="sidebar-link <?= $page==='mainwall' ? 'active':'' ?>"><i class="fas fa-display"></i> Main Wall</a>
    <?php endif; ?>
    <?php if(canAccess('aboutus')): ?>
    <a href="?page=aboutus" class="sidebar-link <?= $page==='aboutus' ? 'active':'' ?>"><i class="fas fa-info-circle"></i> About Us</a>
    <?php endif; ?>
    <?php if(canAccess('clientlogos')): ?>
    <a href="?page=clientlogos" class="sidebar-link <?= $page==='clientlogos' ? 'active':'' ?>"><i class="fas fa-image"></i> Client Logos</a>
    <?php endif; ?>

    <?php if(canAccess('finance')): ?>
    <div class="nav-section-label" style="margin-top:10px;">Finance</div>
    <a href="?page=ourclients" class="sidebar-link <?= $page==='ourclients' ? 'active':'' ?>"><i class="fas fa-users"></i> Clients</a>
    <?php endif; ?>
    <?php if(canAccess('invoice')): ?>
    <?php if(!canAccess('finance')): ?><div class="nav-section-label" style="margin-top:10px;">Finance</div><?php endif; ?>
    <a href="?page=invoice" class="sidebar-link <?= $page==='invoice' ? 'active':'' ?>"><i class="fas fa-file-invoice-dollar"></i> Generate Invoice</a>
    <a href="?page=quotation" class="sidebar-link <?= $page==='quotation' ? 'active':'' ?>"><i class="fas fa-file-alt"></i> Generate Quotation</a>
    <?php endif; ?>

    <?php if(canAccess('usermgmt')): ?>
    <div class="nav-section-label" style="margin-top:10px;">System</div>
    <a href="?page=usermgmt" class="sidebar-link <?= $page==='usermgmt' ? 'active':'' ?>">
      <i class="fas fa-user-shield"></i> User Management
    </a>
    <?php endif; ?>
  </nav>

  <div class="sidebar-footer">
    <div class="avatar"><?= initials($admin['name']) ?></div>
    <div class="info">
      <div class="name"><?= $admin['name'] ?></div>
      <div class="role"><?= $admin['role'] ?></div>
    </div>
    <a href="logout.php" class="logout-btn" title="Logout" onclick="return confirm('Sign out of Creative4 Admin?')"><i class="fas fa-sign-out-alt"></i></a>
  </div>
</aside>

<!-- ════ MAIN ════════════════════════════════════════ -->
<div class="main-wrap">

  <!-- Topbar -->
  <div class="topbar">
    <button class="topbar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
    <div class="page-title" id="topbarTitle">
      <?php
        $titles = ['dashboard'=>'Dashboard','messages'=>'Messages','portfolio'=>'Portfolio','portfoliotiles'=>'Portfolio Tiles','mainwall'=>'Main Wall','aboutus'=>'About Us','ourclients'=>'Our Clients','clientlogos'=>'Client Logos','invoice'=>'Generate Invoice','quotation'=>'Generate Quotation','usermgmt'=>'User Management'];
        echo $titles[$page] ?? ucfirst($page);
      ?>
    </div>
    <div class="search-wrap"><i class="fas fa-search"></i><input type="text" placeholder="Search here…"/></div>
    <div class="topbar-actions">
      <div class="icon-btn-wrap" style="position:relative;">
        <div class="icon-btn" id="bellBtn" onclick="toggleTopbarPanel('bell')"><i class="fas fa-bell"></i><span class="dot" id="bellDot" style="display:none;"></span></div>
        <div class="topbar-panel" id="bellPanel">
          <div class="topbar-panel-head">Notifications</div>
          <div id="bellPanelBody"><div class="topbar-panel-empty">Loading…</div></div>
        </div>
      </div>
      <div class="icon-btn-wrap" style="position:relative;">
        <div class="icon-btn" id="envBtn" onclick="toggleTopbarPanel('env')"><i class="fas fa-envelope"></i><span class="dot" id="envDot" style="display:none;"></span></div>
        <div class="topbar-panel" id="envPanel">
          <div class="topbar-panel-head">Messages <a href="?page=messages" style="font-size:.72rem;font-weight:600;color:var(--cyan-dark);text-decoration:none;">View all →</a></div>
          <div id="envPanelBody"><div class="topbar-panel-empty">Loading…</div></div>
        </div>
      </div>
      <div class="admin-chip">
        <div class="av"><?= initials($admin['name']) ?></div>
        <div class="info"><div class="n"><?= htmlspecialchars($admin['name']) ?></div><div class="r"><?= htmlspecialchars($admin['role']) ?></div></div>
      </div>
    </div>
  </div>

  <!-- ════ CONTENT ════ -->
  <div class="content-area">

    <!-- ── DASHBOARD ── -->
    <?php if($page === 'dashboard'): ?>
    <div class="page-section active" id="sec-dashboard">
      <div class="row g-3 mb-4" id="dash-stats">
        <div class="col-6 col-md-3">
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-images"></i></div>
            <div><div class="stat-value" id="dash-stat-portfolio">—</div><div class="stat-label">Portfolio Items</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-users"></i></div>
            <div><div class="stat-value" id="dash-stat-clients">—</div><div class="stat-label">Clients</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-file-invoice"></i></div>
            <div><div class="stat-value" id="dash-stat-invoices">—</div><div class="stat-label">Invoices</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-card accent">
            <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
            <div><div class="stat-value" id="dash-stat-revenue">—</div><div class="stat-label">Revenue</div></div>
          </div>
        </div>
      </div>
      <div class="row g-3">
        <div class="col-12 col-lg-7">
          <div class="section-card">
            <div class="section-head"><h5>Recent Projects</h5><button class="see-all-btn" onclick="window.location='?page=portfolio'">See all →</button></div>
            <div style="overflow-x:auto;">
            <table class="proj-table">
              <thead><tr><th>Project Title</th><th>Category</th><th>Status</th><th>Date</th></tr></thead>
              <tbody id="dash-recent-projects">
                <tr><td colspan="4" style="text-align:center;color:var(--muted);padding:20px;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</td></tr>
              </tbody>
            </table>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-5">
          <div class="section-card h-100">
            <div class="section-head"><h5>New Clients</h5><button class="see-all-btn" onclick="window.location='?page=ourclients'">See all →</button></div>
            <div id="dash-new-clients">
              <div style="text-align:center;color:var(--muted);padding:20px;font-size:.85rem;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── MESSAGES ── -->
    <?php elseif($page === 'messages'): ?>
    <div class="page-section active">
      <div class="section-card">
        <div class="section-head"><h5>Contact Messages</h5></div>
        <div style="overflow-x:auto;">
        <table class="proj-table">
          <thead><tr><th>From</th><th>Message</th><th>Reply Via</th><th>Received</th><th>Actions</th></tr></thead>
          <tbody id="msg-table-body">
            <tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</td></tr>
          </tbody>
        </table>
        </div>
      </div>
    </div>

    <!-- ── PORTFOLIO ── -->
    <?php elseif($page === 'portfolio'): ?>
    <div class="page-section active" id="pf-admin-section">

      <!-- ── CATEGORY TILES ── -->
      <div class="section-card mb-3">
        <div class="section-head">
          <h5>Portfolio Categories</h5>
          <div style="display:flex;gap:8px;align-items:center;">
            <span id="pf-firebase-status" style="font-size:.75rem;font-weight:700;padding:4px 12px;border-radius:20px;background:#dcfce7;color:#15803d;"><i class="fas fa-circle" style="font-size:.5rem;margin-right:4px;"></i>Connecting…</span>
            <?php if(canAccess('portfolio_add')): ?>
            <button class="btn-cyan" style="font-size:.78rem;padding:6px 16px;" onclick="pfOpenAddModal()"><i class="fas fa-plus me-1"></i>Add Item</button>
            <?php endif; ?>
          </div>
        </div>
        <div id="pf-cat-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;padding:16px;">
          <div style="padding:20px;text-align:center;color:var(--muted);font-size:.82rem;grid-column:1/-1;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</div>
        </div>
      </div>

      <!-- ── ITEMS TABLE ── -->
      <div class="section-card">
        <div class="section-head" style="flex-wrap:wrap;gap:10px;">
          <h5 id="pf-table-heading">All Portfolio Items</h5>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <div style="position:relative;">
              <i class="fas fa-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.78rem;"></i>
              <input type="text" id="pf-search" placeholder="Search items…" oninput="pfFilter()"
                style="border:1.5px solid var(--border);border-radius:8px;padding:7px 12px 7px 30px;font-size:.82rem;font-family:'DM Sans',sans-serif;outline:none;width:190px;"/>
            </div>
            <select id="pf-type-f" onchange="pfFilter()" style="border:1.5px solid var(--border);border-radius:8px;padding:7px 10px;font-size:.82rem;font-family:'DM Sans',sans-serif;outline:none;">
              <option value="">All Types</option>
              <option value="album">Photos</option>
              <option value="video">Videos</option>
            </select>
            <select id="pf-pub-f" onchange="pfFilter()" style="border:1.5px solid var(--border);border-radius:8px;padding:7px 10px;font-size:.82rem;font-family:'DM Sans',sans-serif;outline:none;">
              <option value="">All Status</option>
              <option value="true">Published</option>
              <option value="false">Draft</option>
            </select>
          </div>
        </div>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;" id="pf-items-table">
            <thead>
              <tr>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Thumb</th>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Title / Client</th>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Category</th>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Type</th>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Status</th>
                <th style="font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);padding:11px 18px;text-align:left;background:#f8fafc;border-bottom:1px solid var(--border);">Actions</th>
              </tr>
            </thead>
            <tbody id="pf-tbody">
              <tr><td colspan="6" style="text-align:center;padding:36px;color:var(--muted);"><i class="fas fa-spinner fa-spin me-2"></i>Loading items from Firebase…</td></tr>
            </tbody>
          </table>
        </div>
        <div style="padding:10px 18px;font-size:.76rem;color:var(--muted);border-top:1px solid var(--border);">
          Showing <span id="pf-showing">0</span> of <span id="pf-total">0</span> items
        </div>
      </div>
    </div>

    <!-- ═══ PORTFOLIO ADD/EDIT MODAL ═══ -->
    <div class="modal-overlay" id="pfAddModal">
      <div class="modal-box" style="max-width:560px;">
        <div class="modal-header">
          <h4 id="pf-modal-title">ADD PORTFOLIO ITEM</h4>
          <button class="modal-close" onclick="closeModal('pfAddModal')"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="pf-edit-id"/>

          <!-- TYPE -->
          <div class="mb-3">
            <label class="form-label">Content Type *</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
              <div id="pf-to-album" onclick="pfSelectType('album')" style="border:2px solid var(--border);border-radius:10px;padding:12px;cursor:pointer;display:flex;align-items:center;gap:10px;transition:all .2s;">
                <div style="width:36px;height:36px;border-radius:8px;background:#dcfce7;color:#15803d;display:flex;align-items:center;justify-content:center;"><i class="fas fa-images"></i></div>
                <div><div style="font-weight:700;font-size:.88rem;color:var(--dark);">Photos</div><div style="font-size:.72rem;color:var(--muted);">Image album</div></div>
              </div>
              <div id="pf-to-video" onclick="pfSelectType('video')" style="border:2px solid var(--border);border-radius:10px;padding:12px;cursor:pointer;display:flex;align-items:center;gap:10px;transition:all .2s;">
                <div style="width:36px;height:36px;border-radius:8px;background:#dbeafe;color:#1d4ed8;display:flex;align-items:center;justify-content:center;"><i class="fas fa-video"></i></div>
                <div><div style="font-weight:700;font-size:.88rem;color:var(--dark);">Video</div><div style="font-size:.72rem;color:var(--muted);">YouTube / Vimeo / URL</div></div>
              </div>
            </div>
          </div>

          <!-- CATEGORY -->
          <div class="mb-3">
            <label class="form-label">Category *</label>
            <select class="form-control" id="pf-f-cat">
              <option value="">Select category…</option>
              <!-- populated dynamically from portfolioTiles collection -->
            </select>
          </div>

          <!-- CLIENT + TITLE -->
          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label">Client Name *</label>
              <input type="text" class="form-control" id="pf-f-client" placeholder="e.g. TechNova Corp"/>
            </div>
            <div class="col-md-6">
              <label class="form-label">Project Title *</label>
              <input type="text" class="form-control" id="pf-f-title" placeholder="e.g. Brand Identity Campaign"/>
            </div>
          </div>

          <!-- DESCRIPTION -->
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" id="pf-f-desc" rows="2" placeholder="Brief description of the project…"></textarea>
          </div>

          <!-- PHOTOS — Drag & Drop + Firebase Storage Upload -->
          <div id="pf-photo-section" style="display:none;">
            <label class="form-label">Photos * <small style="font-weight:400;text-transform:none;font-size:.75rem;">Drag & drop images, click to browse, or paste URLs below</small></label>

            <!-- Drop zone -->
            <div id="pf-drop-zone"
              ondragover="pfDragOver(event)" ondragleave="pfDragLeave(event)" ondrop="pfDrop(event)"
              onclick="document.getElementById('pf-file-inp').click()"
              style="border:2px dashed var(--border);border-radius:10px;padding:28px 16px;text-align:center;cursor:pointer;transition:all .2s;background:#fafafa;margin-bottom:10px;">
              <input type="file" id="pf-file-inp" multiple accept="image/*" style="display:none;" onchange="pfHandleFiles(this.files)"/>
              <i class="fas fa-cloud-upload-alt" style="font-size:1.8rem;color:var(--cyan);margin-bottom:8px;display:block;"></i>
              <div style="font-weight:700;font-size:.88rem;color:var(--dark);">Drop images here or click to browse</div>
              <div style="font-size:.74rem;color:var(--muted);margin-top:4px;">JPG, PNG, WEBP — multiple files supported</div>
              <div id="pf-upload-progress" style="display:none;margin-top:12px;">
                <div style="height:4px;background:#e5e7eb;border-radius:4px;overflow:hidden;">
                  <div id="pf-progress-bar" style="height:100%;background:var(--cyan);width:0%;transition:width .3s;"></div>
                </div>
                <div id="pf-upload-status" style="font-size:.74rem;color:var(--muted);margin-top:6px;">Uploading…</div>
              </div>
            </div>

            <!-- URL fallback textarea -->
            <label style="font-size:.74rem;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--muted);margin-bottom:4px;display:block;">Or paste image URLs (one per line)</label>
            <textarea class="form-control" id="pf-f-photos" rows="3" placeholder="https://firebasestorage.googleapis.com/...&#10;https://images.unsplash.com/..." oninput="pfPhotoPreview()" style="font-size:.8rem;"></textarea>

            <!-- Preview grid -->
            <div id="pf-photo-prev" style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:10px;"></div>
          </div>

          <!-- VIDEO -->
          <div id="pf-video-section" style="display:none;">

            <!-- Drag & Drop zone -->
            <label class="form-label">Upload Video <small style="font-weight:400;text-transform:none;font-size:.75rem;">Drag &amp; drop or click to browse</small></label>
            <div id="pf-video-drop-zone"
              ondragover="pfVideoDragOver(event)" ondragleave="pfVideoDragLeave(event)" ondrop="pfVideoDrop(event)"
              onclick="document.getElementById('pf-video-file-inp').click()"
              style="border:2px dashed var(--border);border-radius:10px;padding:24px 16px;text-align:center;cursor:pointer;transition:all .2s;background:#fafafa;margin-bottom:12px;">
              <input type="file" id="pf-video-file-inp" accept="video/*" style="display:none;" onchange="pfHandleVideoFile(this.files[0])"/>
              <i class="fas fa-film" style="font-size:1.8rem;color:var(--cyan);margin-bottom:8px;display:block;"></i>
              <div style="font-weight:700;font-size:.88rem;color:var(--dark);">Drop video here or click to browse</div>
              <div style="font-size:.74rem;color:var(--muted);margin-top:4px;">MP4, MOV, WEBM supported</div>
              <div id="pf-video-upload-progress" style="display:none;margin-top:12px;">
                <div style="height:4px;background:#e5e7eb;border-radius:4px;overflow:hidden;">
                  <div id="pf-video-progress-bar" style="height:100%;background:var(--cyan);width:0%;transition:width .3s;"></div>
                </div>
                <div id="pf-video-upload-status" style="font-size:.74rem;color:var(--muted);margin-top:6px;">Uploading...</div>
              </div>
            </div>

            <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
              <div style="flex:1;height:1px;background:var(--border);"></div>
              <span style="font-size:.72rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">or paste URL</span>
              <div style="flex:1;height:1px;background:var(--border);"></div>
            </div>

            <div class="mb-3">
              <label class="form-label">Video URL <small style="font-weight:400;text-transform:none;font-size:.75rem;">(YouTube, Vimeo, Cloudinary, or direct link)</small></label>
              <input type="url" class="form-control" id="pf-f-vidurl" placeholder="https://www.youtube.com/watch?v=..." oninput="pfVideoPreview()"/>
            </div>
            <div id="pf-vid-prev-wrap" style="display:none;margin-bottom:12px;">
              <div style="padding-bottom:56.25%;position:relative;background:#000;border-radius:8px;overflow:hidden;">
                <iframe id="pf-vid-prev-frame" src="" style="position:absolute;inset:0;width:100%;height:100%;border:none;" allowfullscreen></iframe>
              </div>
              <video id="pf-vid-prev-video" controls style="display:none;width:100%;border-radius:8px;background:#000;max-height:200px;margin-top:8px;"></video>
            </div>
            <div>
              <label class="form-label">Thumbnail URL <small style="font-weight:400;text-transform:none;">(auto-filled for YouTube)</small></label>
              <input type="url" class="form-control" id="pf-f-thumb" placeholder="https://..."/>
            </div>
          </div>

          <!-- DATE + PUBLISH -->
          <div class="row g-3 mt-1">
            <div class="col-md-6">
              <label class="form-label">Display Date</label>
              <input type="date" class="form-control" id="pf-f-date"/>
            </div>
            <div class="col-md-6" style="display:flex;align-items:flex-end;padding-bottom:2px;">
              <div class="toggle-wrap">
                <label class="toggle"><input type="checkbox" id="pf-f-published" checked/><span class="toggle-slider"></span></label>
                <span style="font-size:.84rem;font-weight:600;color:var(--text);">Published (visible on site)</span>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-outline-cyan" onclick="closeModal('pfAddModal')">Cancel</button>
          <button class="btn-cyan" id="pf-save-btn" onclick="pfSaveItem()"><i class="fas fa-save me-1"></i><span id="pf-save-txt">Save Item</span></button>
        </div>
      </div>
    </div>

    <!-- PORTFOLIO DELETE CONFIRM -->
    <div class="modal-overlay" id="pfDelModal">
      <div class="modal-box" style="max-width:360px;">
        <div class="modal-body" style="text-align:center;padding:30px 24px;">
          <div style="width:60px;height:60px;border-radius:50%;background:#fee2e2;color:var(--danger);font-size:1.5rem;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;"><i class="fas fa-trash"></i></div>
          <div style="font-family:'Bebas Neue',sans-serif;font-size:1.3rem;letter-spacing:1px;margin-bottom:8px;">Delete Item?</div>
          <div style="font-size:.84rem;color:var(--muted);" id="pf-del-msg">This item will be permanently removed.</div>
          <div style="display:flex;gap:10px;justify-content:center;margin-top:20px;">
            <button class="btn-outline-cyan" onclick="closeModal('pfDelModal')">Cancel</button>
            <button style="background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;border:none;border-radius:8px;padding:9px 22px;font-weight:700;font-size:.85rem;cursor:pointer;" onclick="pfDoDelete()"><i class="fas fa-trash me-1"></i>Delete</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── ABOUT US ── -->
    <?php elseif($page === 'aboutus'): ?>
    <div class="page-section active" id="sec-aboutus">
      <div class="row g-3">

        <!-- LEFT: Company Profile + Showreel -->
        <div class="col-12 col-lg-8">

          <!-- Company Profile Text -->
          <div class="section-card mb-3">
            <div class="section-head"><h5>Company Profile Text</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label">About Us Text (shown in overlay)</label>
                  <textarea class="form-control" id="au-text1" rows="3">We create exciting and effective visual communication solutions, customized for your company. A full service design studio providing comprehensive professional services in designing, printing, animations &amp; video production.</textarea>
                </div>
                <div class="col-12">
                  <textarea class="form-control" id="au-text2" rows="3">From brand identity and digital campaigns to video production and large-format print, we handle every touchpoint of your brand's visual journey.</textarea>
                </div>
                <div class="col-12">
                  <textarea class="form-control" id="au-text3" rows="2">Founded in Sri Lanka with a global outlook, Creative 4 has partnered with leading brands across industries.</textarea>
                </div>
                <div class="col-12"><button class="btn-cyan" onclick="auSaveProfileText()"><i class="fas fa-save me-2"></i>Save Profile Text</button></div>
              </div>
            </div>
          </div>

          <!-- Company Profile PDF -->
          <div class="section-card mb-3">
            <div class="section-head"><h5>Company Profile PDF</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label">Current PDF URL</label>
                  <input type="text" class="form-control" id="au-pdf-url" placeholder="No PDF uploaded yet">
                </div>
                <div class="col-12">
                  <label class="form-label">Upload New PDF</label>
                  <input type="file" class="form-control" id="au-pdf-file" accept="application/pdf">
                </div>
                <div class="col-12" id="au-pdf-progress-wrap" style="display:none;">
                  <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="au-pdf-progress-label">Uploading…</div>
                  <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                    <div id="au-pdf-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                  </div>
                </div>
                <div class="col-12"><button class="btn-cyan" onclick="auUploadPDF()"><i class="fas fa-cloud-upload-alt me-2"></i>Upload & Save PDF</button></div>
              </div>
            </div>
          </div>

          <!-- Showreel -->
          <div class="section-card">
            <div class="section-head"><h5>Showreel Video</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label">Current Video URL</label>
                  <input type="text" class="form-control" id="au-showreel-url" placeholder="No showreel uploaded yet">
                </div>
                <div class="col-12">
                  <label class="form-label">Upload New Showreel (MP4)</label>
                  <input type="file" class="form-control" id="au-showreel-file" accept="video/mp4,video/*" onchange="auPreviewShowreel()">
                </div>
                <div class="col-12" id="au-showreel-preview-wrap" style="display:none;">
                  <video id="au-showreel-preview" controls muted style="width:100%;max-height:200px;border-radius:6px;background:#000;"></video>
                </div>
                <div class="col-12" id="au-showreel-progress-wrap" style="display:none;">
                  <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="au-showreel-progress-label">Uploading…</div>
                  <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                    <div id="au-showreel-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                  </div>
                </div>
                <div class="col-12"><button class="btn-cyan" onclick="auUploadShowreel()"><i class="fas fa-cloud-upload-alt me-2"></i>Upload & Save Showreel</button></div>
              </div>
            </div>
          </div>

        </div>

        <!-- RIGHT: Team Members -->
        <div class="col-12 col-lg-4">
          <div class="section-card">
            <div class="section-head"><h5>Team Members</h5><button class="see-all-btn" onclick="auOpenAddMember()">+ Add</button></div>
            <div id="au-team-list">
              <div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0;">Loading…</div>
            </div>
          </div>
        </div>

      </div>

      <!-- Status -->
      <div id="au-status" style="display:none;margin-top:14px;padding:10px 16px;border-radius:6px;font-size:.85rem;font-weight:600;"></div>
    </div>

    <!-- ── ADD/EDIT TEAM MEMBER MODAL ── -->
    <div class="modal-overlay" id="auTeamModal">
      <div class="modal-box" style="max-width:460px;">
        <div class="modal-header">
          <h4 id="au-modal-title">ADD TEAM MEMBER</h4>
          <button class="modal-close" onclick="closeModal('auTeamModal')"><i class="fas fa-times"></i></button>
        </div>
        <div style="padding:24px;">
          <input type="hidden" id="au-member-id">
          <div class="mb-3 text-center">
            <div id="au-photo-preview" style="width:90px;height:90px;border-radius:50%;margin:0 auto 10px;background:linear-gradient(135deg,var(--cyan),var(--cyan-dark));display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:2rem;color:#fff;overflow:hidden;">
              <span id="au-photo-initials">?</span>
              <img id="au-photo-img" src="" style="display:none;width:100%;height:100%;object-fit:cover;">
            </div>
            <input type="file" id="au-member-photo" accept="image/*" style="display:none;" onchange="auPreviewMemberPhoto()">
            <button class="btn-outline-cyan" style="font-size:.78rem;padding:5px 14px;" onclick="document.getElementById('au-member-photo').click()"><i class="fas fa-camera me-1"></i>Browse Photo</button>
          </div>
          <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" id="au-member-name" placeholder="e.g. Ashan K." oninput="auUpdateInitials()">
          </div>
          <div class="mb-3">
            <label class="form-label">Designation / Role</label>
            <input type="text" class="form-control" id="au-member-role" placeholder="e.g. Creative Director">
          </div>
          <div id="au-member-progress-wrap" style="display:none;margin-bottom:12px;">
            <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="au-member-progress-label">Uploading photo…</div>
            <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
              <div id="au-member-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
            </div>
          </div>
          <div class="d-flex gap-2 justify-content-end">
            <button class="btn-outline-cyan" onclick="closeModal('auTeamModal')">Cancel</button>
            <button class="btn-cyan" onclick="auSaveMember()"><i class="fas fa-save me-1"></i>Save Member</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── OUR CLIENTS ── -->
    <?php elseif($page === 'ourclients'): ?>
    <div class="page-section active" id="sec-ourclients">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div style="font-size:.85rem;color:var(--muted);" id="oc-count">Loading…</div>
        <button class="btn-cyan" onclick="ocOpenAdd()"><i class="fas fa-user-plus me-2"></i>Add Client</button>
      </div>
      <div class="section-card">
        <div style="overflow-x:auto;">
        <table class="proj-table">
          <thead><tr><th>Client</th><th>Company</th><th>Email</th><th>Phone</th><th>Address</th><th>Actions</th></tr></thead>
          <tbody id="oc-table-body">
            <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:30px;">Loading…</td></tr>
          </tbody>
        </table>
        </div>
      </div>
      <div id="oc-status" style="display:none;margin-top:14px;padding:10px 16px;border-radius:6px;font-size:.85rem;font-weight:600;"></div>
    </div>

    <!-- OUR CLIENTS MODAL -->
    <div class="modal-overlay" id="ocModal">
      <div class="modal-box" style="max-width:480px;">
        <div class="modal-header">
          <h4 id="oc-modal-title">ADD CLIENT</h4>
          <button class="modal-close" onclick="closeModal('ocModal')"><i class="fas fa-times"></i></button>
        </div>
        <div style="padding:24px;">
          <input type="hidden" id="oc-client-id">
          <div class="row g-3">
            <div class="col-12"><label class="form-label">Full Name</label><input type="text" class="form-control" id="oc-name" placeholder="e.g. Lewis Cunningham"></div>
            <div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" id="oc-email" placeholder="client@example.com"></div>
            <div class="col-md-6"><label class="form-label">Phone</label><input type="text" class="form-control" id="oc-phone" placeholder="+94 77 123 4567"></div>
            <div class="col-12"><label class="form-label">Address</label><input type="text" class="form-control" id="oc-address" placeholder="123 Main St, Colombo"></div>
            <div class="col-12"><label class="form-label">Company / Organisation</label><input type="text" class="form-control" id="oc-company" placeholder="e.g. ABC Corp"></div>
          </div>
          <div class="d-flex gap-2 justify-content-end mt-3">
            <button class="btn-outline-cyan" onclick="closeModal('ocModal')">Cancel</button>
            <button class="btn-cyan" onclick="ocSaveClient()"><i class="fas fa-save me-1"></i>Save Client</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── CLIENT LOGOS ── -->
    <?php elseif($page === 'clientlogos'): ?>
    <div class="page-section active" id="sec-clientlogos">
      <div class="row g-3">
        <div class="col-12 col-lg-5">
          <div class="section-card">
            <div class="section-head"><h5>Add Client Logo</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label">Company Name</label>
                  <input type="text" class="form-control" id="cl-name" placeholder="e.g. Google">
                </div>
                <div class="col-12">
                  <label class="form-label">Logo Image</label>
                  <input type="file" class="form-control" id="cl-logo-file" accept="image/*" onchange="clPreviewLogo()">
                </div>
                <div class="col-12" id="cl-preview-wrap" style="display:none;">
                  <img id="cl-preview-img" src="" style="max-height:80px;max-width:200px;object-fit:contain;border:1px solid var(--border);border-radius:6px;padding:8px;background:#fff;">
                </div>
                <div class="col-12" id="cl-progress-wrap" style="display:none;">
                  <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="cl-progress-label">Uploading…</div>
                  <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                    <div id="cl-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                  </div>
                </div>
                <div class="col-12">
                  <button class="btn-cyan" onclick="clAddLogo()"><i class="fas fa-cloud-upload-alt me-2"></i>Upload & Add</button>
                </div>
                <div id="cl-status" style="display:none;padding:10px 16px;border-radius:6px;font-size:.85rem;font-weight:600;"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-7">
          <div class="section-card">
            <div class="section-head"><h5>Current Client Logos</h5></div>
            <div id="cl-logos-grid" style="padding:16px;display:flex;flex-wrap:wrap;gap:16px;">
              <div style="color:var(--muted);font-size:.85rem;padding:20px 0;">Loading…</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── GENERATE INVOICE ── -->
    <?php elseif($page === 'invoice'): ?>
    <div class="page-section active">
      <div class="row g-3">
        <div class="col-12 col-lg-5">
          <div class="section-card">
            <div class="section-head"><h5>Invoice Details</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Invoice No.</label><input type="text" class="form-control" id="inv_no" value="INV-<?= date('Ymd') ?>-001"/></div>
                <div class="col-md-6"><label class="form-label">Date</label><input type="date" class="form-control" id="inv_date" value="<?= date('Y-m-d') ?>"/></div>
                <div class="col-12"><label class="form-label">Client</label>
                  <select class="form-select" id="inv_client_select" onchange="onInvoiceClientChange()">
                    <option value="">Loading clients…</option>
                  </select>
                </div>
                <div class="col-12" id="inv_client_manual_wrap" style="display:none;"><label class="form-label">Client Name (manual)</label><input type="text" class="form-control" id="inv_client" placeholder="Enter client name" oninput="updateInvoicePreview()"/></div>
                <div class="col-12"><label class="form-label">Client Email</label><input type="email" class="form-control" id="inv_email" placeholder="client@example.com"/></div>
                <div class="col-12">
                  <label class="form-label">Line Items</label>
                  <div id="inv-items"><div class="line-item-row row g-2 mb-2"><div class="col-6"><input type="text" class="form-control item-desc" placeholder="Service description"/></div><div class="col-3"><input type="number" class="form-control item-qty" placeholder="Qty" value="1" min="1"/></div><div class="col-3"><input type="number" class="form-control item-price" placeholder="Price" min="0"/></div></div></div>
                  <button type="button" class="btn-outline-cyan mt-2" style="font-size:.78rem;padding:5px 14px;" onclick="addItem('inv')"><i class="fas fa-plus me-1"></i> Add Line</button>
                </div>
                <div class="col-md-6"><label class="form-label">Discount</label><input type="number" class="form-control" id="inv_discount" placeholder="0" min="0" value="0"/></div>
                <div class="col-md-6"><label class="form-label">Discount Type</label><select class="form-select" id="inv_discount_type"><option value="percent">Percent (%)</option><option value="fixed">Fixed Amount (LKR)</option></select></div>
                <div class="col-md-6"><label class="form-label">Advance Paid (LKR)</label><input type="number" class="form-control" id="inv_advance" placeholder="0" min="0" value="0"/></div>
                <div class="col-12">
                  <label class="form-label">Terms &amp; Conditions <span style="text-transform:none;font-weight:400;">— tick the conditions that apply</span></label>
                  <div class="tc-checklist" id="inv_tc_list"><!-- populated by JS --></div>
                </div>
                <div class="col-12"><label class="form-label">Custom Conditions</label><textarea class="form-control" id="inv_tc_custom" rows="2" placeholder="Add any extra condition not listed above (one per line)…"></textarea></div>
                <div class="col-12"><label class="form-label">Additional Notes</label><textarea class="form-control" id="inv_notes" rows="2" placeholder="Any other note to show on the invoice…"></textarea></div>
                <div class="col-12 d-flex gap-2"><button class="btn-cyan" onclick="generateDoc('invoice')"><i class="fas fa-file-invoice me-2"></i>Generate Invoice</button><button class="btn-outline-cyan" onclick="downloadPDF('invoice')"><i class="fas fa-download me-2"></i>Download PDF</button></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-7">
          <div class="invoice-preview" id="inv-preview">
            <div class="inv-header">
              <div><img src="images/CREATIVE4_LOGO_BW.png" alt="CREATIVE 4" class="doc-logo-img"/><small>The Ultimate Imagination · No.265/6/9, 2nd Lane, Thotupola Road, Delthara, Piliyandala, Sri Lanka<br>Tel: (+94) 77 33 77495 | (+94) 70 33 77495 · Email: ads@creative4.lk</small></div>
              <div class="inv-title">INVOICE</div>
            </div>
            <div class="row mb-3">
              <div class="col-6"><div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Bill To</div><div id="prev-client" style="font-weight:700;margin-top:4px;">—</div><div id="prev-email" style="font-size:.82rem;color:var(--muted);">—</div></div>
              <div class="col-6 text-end"><div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Invoice No.</div><div id="prev-no" style="font-weight:700;margin-top:4px;"><?= date('Ymd') ?>-001</div><div id="prev-date" style="font-size:.82rem;color:var(--muted);"><?= date('d M Y') ?></div></div>
            </div>
            <div style="overflow-x:auto;"><table class="inv-table"><thead><tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead><tbody id="prev-items"><tr><td colspan="4" style="color:var(--muted);text-align:center;padding:20px;">Fill in line items →</td></tr></tbody></table></div>
            <div style="display:flex;justify-content:flex-end;margin-top:10px;">
              <div style="min-width:240px;">
                <div style="display:flex;justify-content:space-between;font-size:.85rem;color:var(--muted);padding:3px 0;"><span>Subtotal</span><span id="prev-subtotal">LKR 0.00</span></div>
                <div style="display:flex;justify-content:space-between;font-size:.85rem;color:var(--muted);padding:3px 0;" id="prev-discount-row"><span id="prev-discount-label">Discount</span><span id="prev-discount">LKR 0.00</span></div>
              </div>
            </div>
            <div class="inv-total-box mt-3"><div class="total-label">Grand Total</div><div class="total-val" id="prev-total">LKR 0.00</div></div>
            <div class="balance-box mt-3">
              <div class="balance-row"><span>Total Amount LKR</span><strong id="prev-balance-total">0.00</strong></div>
              <div class="balance-row"><span>Advance Paid LKR</span><strong id="prev-advance">0.00</strong></div>
              <div class="balance-row balance-due"><span>Balance Due LKR</span><strong id="prev-balance-due">0.00</strong></div>
            </div>
            <div id="prev-notes" style="margin-top:14px;font-size:.8rem;color:var(--muted);"></div>
            <div id="prev-terms"></div>
            <div class="doc-bank-box">
              <div class="doc-bank-title">Bank Deposit Details</div>
              <div>Bank Name: <strong>Sampath Bank</strong> &nbsp; Branch: <strong>Piliyandala</strong></div>
              <div>Account Name: <strong>CREATIVE 4</strong> &nbsp; Account No: <strong>0019 1001 1894</strong></div>
            </div>
            <div class="doc-footer-row">
              <div class="doc-disclaimer">This is a system-generated electronic invoice (E-Invoice) issued by CREATIVE 4. No signature is required, and this document is deemed an official invoice.</div>
              <img src="images/C4_QR_2026.jpg" alt="Scan to verify" class="doc-qr-img"/>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── GENERATE QUOTATION ── -->
    <?php elseif($page === 'quotation'): ?>
    <div class="page-section active">
      <div class="row g-3">
        <div class="col-12 col-lg-5">
          <div class="section-card">
            <div class="section-head"><h5>Quotation Details</h5></div>
            <div class="form-panel">
              <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Quotation No.</label><input type="text" class="form-control" id="qt_no" value="QT-<?= date('Ymd') ?>-001"/></div>
                <div class="col-md-6"><label class="form-label">Valid Until</label><input type="date" class="form-control" id="qt_valid" value="<?= date('Y-m-d', strtotime('+30 days')) ?>"/></div>
                <div class="col-12"><label class="form-label">Client</label>
                  <select class="form-select" id="qt_client_select" onchange="onQuotationClientChange()">
                    <option value="">Loading clients…</option>
                  </select>
                </div>
                <div class="col-12" id="qt_client_manual_wrap" style="display:none;"><label class="form-label">Client Name (manual)</label><input type="text" class="form-control" id="qt_client" placeholder="Enter client name" oninput="updateQuotationPreview()"/></div>
                <div class="col-12"><label class="form-label">Project / Service</label><select class="form-select" id="qt_service"><option>Post-Production &amp; Media</option><option>Design Studio &amp; Branding</option><option>Events, Projects &amp; Advertising</option><option>Social Media &amp; Promo</option><option>2D/3D Motion Graphics</option><option>Logo Design &amp; Concept</option><option>Video Ads &amp; Trailers</option><option>Documentaries &amp; Reels</option><option>Other</option></select></div>
                <div class="col-12"><label class="form-label">Line Items</label><div id="qt-items"><div class="line-item-row row g-2"><div class="col-6"><input type="text" class="form-control item-desc" placeholder="Item description"/></div><div class="col-3"><input type="number" class="form-control item-qty" placeholder="Qty" value="1" min="1"/></div><div class="col-3"><input type="number" class="form-control item-price" placeholder="Rate" min="0"/></div></div></div><button type="button" class="btn-outline-cyan mt-2" style="font-size:.78rem;padding:5px 14px;" onclick="addItem('qt')"><i class="fas fa-plus me-1"></i> Add Line</button></div>
                <div class="col-md-6"><label class="form-label">Discount</label><input type="number" class="form-control" id="qt_discount" placeholder="0" min="0" value="0"/></div>
                <div class="col-md-6"><label class="form-label">Discount Type</label><select class="form-select" id="qt_discount_type"><option value="percent">Percent (%)</option><option value="fixed">Fixed Amount (LKR)</option></select></div>
                <div class="col-12">
                  <label class="form-label">Terms &amp; Conditions <span style="text-transform:none;font-weight:400;">— tick the conditions that apply</span></label>
                  <div class="tc-checklist" id="qt_tc_list"><!-- populated by JS --></div>
                </div>
                <div class="col-12"><label class="form-label">Custom Conditions</label><textarea class="form-control" id="qt_tc_custom" rows="2" placeholder="Add any extra condition not listed above (one per line)…"></textarea></div>
                <div class="col-12 d-flex gap-2"><button class="btn-cyan" onclick="generateDoc('quotation')"><i class="fas fa-file-alt me-2"></i>Generate Quotation</button><button class="btn-outline-cyan" onclick="downloadPDF('quotation')"><i class="fas fa-download me-2"></i>Download PDF</button></div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-7">
          <div class="invoice-preview">
            <div class="inv-header"><div><img src="images/creative4-logo-bw.png" alt="CREATIVE 4" class="doc-logo-img"/><small>The Ultimate Imagination · No.265/6/9, 2nd Lane, Thotupola Road, Delthara, Piliyandala, Sri Lanka<br>Tel: (+94) 77 33 77495 | (+94) 70 33 77495 · Email: ads@creative4.lk</small></div></div><div class="inv-title" style="color:#0284c7;">QUOTATION</div></div>
            <div style="background:var(--cyan-pale);border-radius:10px;padding:14px 18px;margin-bottom:18px;"><div style="font-size:.78rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">Prepared For</div><div id="qt-prev-client" style="font-weight:700;font-size:1rem;margin-top:4px;">—</div><div id="qt-prev-service" style="font-size:.83rem;color:var(--cyan-dark);margin-top:2px;">—</div></div>
            <div style="overflow-x:auto;"><table class="inv-table"><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead><tbody id="qt-prev-items"><tr><td colspan="4" style="color:var(--muted);text-align:center;padding:20px;">Fill in line items →</td></tr></tbody></table></div>
            <div style="display:flex;justify-content:flex-end;margin-top:10px;">
              <div style="min-width:240px;">
                <div style="display:flex;justify-content:space-between;font-size:.85rem;color:var(--muted);padding:3px 0;"><span>Subtotal</span><span id="qt-prev-subtotal">LKR 0.00</span></div>
                <div style="display:flex;justify-content:space-between;font-size:.85rem;color:var(--muted);padding:3px 0;" id="qt-prev-discount-row"><span id="qt-prev-discount-label">Discount</span><span id="qt-prev-discount">LKR 0.00</span></div>
              </div>
            </div>
            <div class="inv-total-box mt-3"><div class="total-label">Estimated Total</div><div class="total-val" id="qt-prev-total">LKR 0.00</div></div>
            <div id="qt-prev-terms"></div>
            <div class="doc-bank-box">
              <div class="doc-bank-title">Wire Transfer / Bank Deposit</div>
              <div>Bank Name: <strong>Sampath Bank</strong> &nbsp; Branch: <strong>Piliyandala</strong></div>
              <div>Account Name: <strong>CREATIVE 4</strong> &nbsp; Account No: <strong>0019 1001 1894</strong></div>
            </div>
            <div class="doc-footer-row">
              <div class="doc-disclaimer">This is an electronically generated quotation issued by CREATIVE 4 and is valid without a signature.</div>
              <img src="images/creative4-qr-2026.jpg" alt="Scan to verify" class="doc-qr-img"/>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════
         ── USER MANAGEMENT ──
    ════════════════════════════════════════════════ -->
    <?php elseif($page === 'usermgmt'): ?>
    <div class="page-section active" id="sec-usermgmt">

      <!-- Summary stats -->
      <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
          <div class="um-stat">
            <div class="um-stat-icon" style="background:#ede9fe;color:#7c3aed;"><i class="fas fa-user-shield"></i></div>
            <div><div class="um-stat-val" id="count-total">—</div><div class="um-stat-lbl">Total Admins</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="um-stat">
            <div class="um-stat-icon" style="background:#dcfce7;color:#15803d;"><i class="fas fa-circle-check"></i></div>
            <div><div class="um-stat-val" id="count-active">—</div><div class="um-stat-lbl">Active</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="um-stat">
            <div class="um-stat-icon" style="background:#dbeafe;color:#1d4ed8;"><i class="fas fa-user-tie"></i></div>
            <div><div class="um-stat-val" id="count-super">—</div><div class="um-stat-lbl">Admins / Super</div></div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="um-stat">
            <div class="um-stat-icon" style="background:#f3f4f6;color:#374151;"><i class="fas fa-user-lock"></i></div>
            <div><div class="um-stat-val" id="count-inactive">—</div><div class="um-stat-lbl">Inactive</div></div>
          </div>
        </div>
      </div>

      <div class="row g-3">

        <!-- ── LEFT: Admin table ── -->
        <div class="col-12 col-lg-8">

          <!-- Filter bar -->
          <div class="filter-bar">
            <div class="fb-search">
              <i class="fas fa-search"></i>
              <input type="text" id="um-search" placeholder="Search by name or email…" oninput="filterAdmins()"/>
            </div>
            <select id="um-role-filter" onchange="filterAdmins()">
              <option value="">All Roles</option>
              <option>Super Admin</option>
              <option>Admin</option>
              <option>Editor</option>
              <option>Viewer</option>
            </select>
            <select id="um-status-filter" onchange="filterAdmins()">
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>

          <div class="section-card">
            <div class="section-head">
              <h5>Admin Accounts</h5>
              <button class="btn-cyan" style="font-size:.78rem;padding:6px 18px;" onclick="openAddModal()">
                <i class="fas fa-user-plus me-2"></i>Add New Admin
              </button>
            </div>
            <div style="overflow-x:auto;">
              <table class="admin-table" id="admin-table">
                <thead>
                  <tr>
                    <th>Admin</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody id="admin-tbody">
                  <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px;"><i class="fas fa-spinner fa-spin me-2"></i>Loading admins…</td></tr>
                </tbody>
              </table>
            </div>
            <div style="padding:12px 20px;font-size:.77rem;color:var(--muted);border-top:1px solid var(--border);">
              Showing <span id="showing-count">—</span> of <span id="total-count">—</span> admin accounts
            </div>
          </div>
        </div>

        <!-- ── RIGHT: Roles & Permissions ── -->
        <div class="col-12 col-lg-4">
          <div class="section-card mb-3">
            <div class="section-head"><h5>Roles &amp; Permissions</h5></div>
            <div style="padding:16px;">
              <?php foreach($role_permissions as $role => $perms):
                $cls = strtolower(str_replace(' ','',$role));
                $colors = ['superadmin'=>'#7c3aed','admin'=>'#0284c7','editor'=>'#d97706','viewer'=>'#475569'];
                $col = $colors[$cls] ?? '#475569';
              ?>
              <div class="role-card mb-2" data-role="<?= htmlspecialchars($role) ?>" onclick="toggleRoleCard(this)">
                <div style="display:flex;align-items:center;justify-content:space-between;">
                  <div>
                    <div class="role-title"><?= $role ?></div>
                    <div class="role-count">— users</div>
                  </div>
                  <i class="fas fa-chevron-down" style="color:var(--muted);font-size:.75rem;transition:transform .2s;"></i>
                </div>
                <ul class="perm-list mt-2" style="display:none;margin-top:8px!important;">
                  <?php foreach($perms as $p): ?>
                  <li><i class="fas fa-check-circle" style="color:<?= $col ?>;"></i> <?= $p ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
              <?php endforeach; ?>
            </div>
          </div>

          <!-- Activity log -->
          <div class="section-card">
            <div class="section-head"><h5>Recent Activity</h5></div>
            <div id="activity-log" style="padding:4px 0;">
              <div style="display:flex;align-items:center;justify-content:center;padding:24px;color:var(--muted);font-size:.85rem;">
                <i class="fas fa-spinner fa-spin me-2"></i>Loading…
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <!-- ── PORTFOLIO TILES ── -->
    <?php elseif($page === 'portfoliotiles'): ?>
    <div class="page-section active" id="sec-portfoliotiles">

      <div class="row g-3">
        <!-- LEFT: Add / Edit tile form — hidden for Editor -->
        <?php if(canAccess('portfoliotiles')): ?>
        <div class="col-12 col-lg-4">
          <div class="section-card">
            <div class="section-head"><h5 id="pt-form-heading">Add New Tile</h5></div>
            <div class="form-panel">
              <input type="hidden" id="pt-edit-id">
              <div class="row g-3">
                <div class="col-12">
                  <label class="form-label">Tile Name <span style="color:var(--muted);font-size:.75rem;">(e.g. "Wedding Photography")</span></label>
                  <input type="text" class="form-control" id="pt-name" placeholder="Category name">
                </div>
                <div class="col-12">
                  <label class="form-label">URL Slug <span style="color:var(--muted);font-size:.75rem;">(auto-generated)</span></label>
                  <input type="text" class="form-control" id="pt-slug" placeholder="e.g. wedding-photography" oninput="ptSlugManual=true">
                </div>
                <div class="col-12">
                  <label class="form-label">Tile Image</label>
                  <input type="file" class="form-control" id="pt-image-file" accept="image/*" onchange="ptPreviewImage()">
                </div>
                <div class="col-12" id="pt-preview-wrap" style="display:none;">
                  <img id="pt-preview-img" src="" style="width:100%;height:120px;object-fit:cover;border-radius:6px;border:1px solid var(--border);">
                </div>
                <div class="col-12">
                  <label class="form-label">Or paste image URL</label>
                  <input type="text" class="form-control" id="pt-image-url" placeholder="https://…">
                </div>
                <div class="col-12" id="pt-upload-progress" style="display:none;">
                  <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="pt-progress-label">Uploading…</div>
                  <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                    <div id="pt-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                  </div>
                </div>
                <div class="col-12 d-flex gap-2">
                  <button class="btn-cyan" onclick="ptSaveTile()"><i class="fas fa-save me-1"></i><span id="pt-save-label">Add Tile</span></button>
                  <button class="btn-outline-cyan" id="pt-cancel-btn" onclick="ptCancelEdit()" style="display:none;">Cancel</button>
                </div>
                <div id="pt-status" style="display:none;padding:10px 16px;border-radius:6px;font-size:.85rem;font-weight:600;"></div>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>

        <!-- RIGHT: Current tiles grid -->
        <div class="col-12 col-lg-8">
          <div class="section-card">
            <div class="section-head">
              <h5>Current Tiles</h5>
              <div style="font-size:.78rem;color:var(--muted);" id="pt-count">Loading…</div>
            </div>
            <div id="pt-tiles-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;padding:16px;">
              <div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px;grid-column:1/-1;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</div>
            </div>
          </div>

          <!-- Static tiles info -->
          <div class="section-card mt-3">
            <div class="section-head"><h5>Default 16 Tiles</h5><span style="font-size:.75rem;color:var(--muted);">Click to edit image</span></div>
            <div id="pt-static-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;padding:16px;">
              <div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px;grid-column:1/-1;"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- PORTFOLIO TILES DELETE CONFIRM -->
    <div class="modal-overlay" id="ptDelModal">
      <div class="modal-box" style="max-width:360px;text-align:center;">
        <div style="padding:28px;">
          <i class="fas fa-trash" style="font-size:2rem;color:#ef4444;margin-bottom:12px;display:block;"></i>
          <h4 style="margin-bottom:8px;">Delete Tile?</h4>
          <p style="font-size:.85rem;color:var(--muted);margin-bottom:20px;">This removes the tile from the portfolio page. Items inside this category are not deleted.</p>
          <div class="d-flex gap-2 justify-content-center">
            <button class="btn-outline-cyan" onclick="closeModal('ptDelModal')">Cancel</button>
            <button class="btn-cyan" style="background:#ef4444;" onclick="ptConfirmDelete()">Delete</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── MAIN WALL ── -->
    <?php elseif($page === 'mainwall'): ?>
    <div class="page-section active" id="sec-mainwall">

      <div class="row g-3">
        <div class="col-12 col-lg-8">
          <div class="section-card">
            <div class="section-head"><h5>Main Wall Settings</h5></div>
            <div class="form-panel">

              <!-- Mode selector row -->
              <div class="d-flex align-items-center gap-4 mb-4" style="border-bottom:1px solid var(--border);padding-bottom:18px;">
                <label class="form-label mb-0" style="font-weight:700;min-width:100px;">Display Mode</label>
                <div class="form-check form-switch mb-0 d-flex align-items-center gap-2">
                  <input class="form-check-input" type="checkbox" id="mw-slider-toggle" onchange="mwModeChange()">
                  <label class="form-check-label" for="mw-slider-toggle">Image Slider</label>
                </div>
                <div class="form-check form-switch mb-0 d-flex align-items-center gap-2">
                  <input class="form-check-input" type="checkbox" id="mw-video-toggle" onchange="mwModeChange()">
                  <label class="form-check-label" for="mw-video-toggle">Video</label>
                </div>
              </div>

              <!-- Hero Title toggle -->
              <div class="d-flex align-items-center gap-3 mb-4" style="border-bottom:1px solid var(--border);padding-bottom:18px;">
                <label class="form-label mb-0" style="font-weight:700;min-width:100px;">Hero Title</label>
                <div class="form-check form-switch mb-0 d-flex align-items-center gap-2">
                  <input class="form-check-input" type="checkbox" id="mw-title-toggle" onchange="mwSaveTitleToggle()" checked>
                  <label class="form-check-label" for="mw-title-toggle">Show <strong>"THE ULTIMATE IMAGINATION"</strong> text on homepage</label>
                </div>
              </div>

              <!-- VIDEO PANEL -->
              <div id="mw-video-panel" style="display:none;">
                <div class="row g-3">
                  <div class="col-12">
                    <label class="form-label">Video URL <span style="color:var(--muted);font-size:.78rem;">(MP4 direct link or Cloudinary URL)</span></label>
                    <input type="text" class="form-control" id="mw-video-url" placeholder="https://res.cloudinary.com/…/video/upload/…/video.mp4">
                  </div>
                  <div class="col-12">
                    <label class="form-label">— or Upload Video File —</label>
                    <input type="file" class="form-control" id="mw-video-file" accept="video/mp4,video/*" onchange="mwPreviewVideo()">
                  </div>
                  <div class="col-12" id="mw-video-preview-wrap" style="display:none;">
                    <video id="mw-video-preview" controls muted style="width:100%;max-height:220px;border-radius:6px;background:#000;"></video>
                  </div>
                  <div class="col-12">
                    <div id="mw-video-upload-progress" style="display:none;">
                      <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="mw-video-progress-label">Uploading to Cloudinary…</div>
                      <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                        <div id="mw-video-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <button class="btn-cyan" onclick="mwSaveVideo()"><i class="fas fa-save me-2"></i>Save Video to Main Wall</button>
                    <button class="btn-outline-cyan ms-2" onclick="mwUploadAndSaveVideo()" id="mw-video-upload-btn" style="display:none;"><i class="fas fa-cloud-upload-alt me-2"></i>Upload & Save</button>
                  </div>
                </div>
              </div>

              <!-- IMAGE SLIDER PANEL -->
              <div id="mw-slider-panel" style="display:none;">
                <div class="row g-3">
                  <div class="col-12">
                    <label class="form-label">Add Slide Images</label>
                    <input type="file" class="form-control" id="mw-slider-files" accept="image/*" multiple onchange="mwPreviewSlides()">
                    <div style="font-size:.75rem;color:var(--muted);margin-top:4px;">Select one or more images. They will be uploaded to Cloudinary.</div>
                  </div>
                  <div class="col-12" id="mw-slide-previews" style="display:flex;flex-wrap:wrap;gap:10px;"></div>
                  <div class="col-12">
                    <div id="mw-slider-upload-progress" style="display:none;">
                      <div style="font-size:.8rem;font-weight:700;margin-bottom:6px;color:var(--cyan-dark);" id="mw-slider-progress-label">Uploading…</div>
                      <div style="background:#e5e7eb;border-radius:99px;height:8px;overflow:hidden;">
                        <div id="mw-slider-progress-bar" style="height:100%;width:0%;background:var(--cyan);transition:width .3s;border-radius:99px;"></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <button class="btn-cyan" onclick="mwUploadSlides()"><i class="fas fa-cloud-upload-alt me-2"></i>Upload Slides &amp; Save</button>
                  </div>
                  <!-- Existing slides list -->
                  <div class="col-12" id="mw-existing-slides-wrap" style="display:none;">
                    <label class="form-label" style="font-weight:700;">Current Slides</label>
                    <div id="mw-existing-slides" style="display:flex;flex-wrap:wrap;gap:10px;"></div>
                  </div>
                </div>
              </div>

              <!-- Placeholder when nothing selected -->
              <div id="mw-no-mode" class="text-center" style="padding:40px 0;color:var(--muted);">
                <i class="fas fa-display" style="font-size:2.5rem;opacity:.3;display:block;margin-bottom:12px;"></i>
                Enable <strong>Image Slider</strong> or <strong>Video</strong> above to configure the Main Wall.
              </div>

              <!-- Status message -->
              <div id="mw-status-msg" style="display:none;margin-top:14px;padding:10px 16px;border-radius:6px;font-size:.85rem;font-weight:600;"></div>

            </div>
          </div>
        </div>

        <!-- RIGHT: live preview + current config -->
        <div class="col-12 col-lg-4">
          <div class="section-card mb-3">
            <div class="section-head"><h5>Current Config</h5></div>
            <div style="padding:14px;" id="mw-current-config">
              <div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0;">Loading…</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php endif; ?>

  </div><!-- /content-area -->
</div><!-- /main-wrap -->


<!-- ════════════════════════════════════════════════
     MODALS
════════════════════════════════════════════════ -->

<!-- ── ADD / EDIT ADMIN MODAL ── -->
<div class="modal-overlay" id="addAdminModal">
  <div class="modal-box">
    <div class="modal-header">
      <h4 id="modal-title">ADD NEW ADMIN</h4>
      <button class="modal-close" onclick="closeModal('addAdminModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">

      <!-- Step indicator -->
      <div style="display:flex;gap:0;margin-bottom:22px;border-radius:8px;overflow:hidden;border:1px solid var(--border);">
        <div class="step-tab active" id="step-tab-1" style="flex:1;padding:9px;text-align:center;font-size:.78rem;font-weight:700;cursor:pointer;background:var(--cyan);color:#fff;transition:all .2s;" onclick="goStep(1)"><i class="fas fa-user me-1"></i>Details</div>
        <div class="step-tab" id="step-tab-2" style="flex:1;padding:9px;text-align:center;font-size:.78rem;font-weight:700;cursor:pointer;background:#f8fafc;color:var(--muted);transition:all .2s;" onclick="goStep(2)"><i class="fas fa-shield-halved me-1"></i>Role</div>
        <div class="step-tab" id="step-tab-3" style="flex:1;padding:9px;text-align:center;font-size:.78rem;font-weight:700;cursor:pointer;background:#f8fafc;color:var(--muted);transition:all .2s;" onclick="goStep(3)"><i class="fas fa-lock me-1"></i>Security</div>
      </div>

      <!-- Step 1: Personal Details -->
      <div id="step-1">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label-um">First Name <span style="color:var(--danger)">*</span></label>
            <input type="text" class="form-ctrl" id="f-fname" placeholder="e.g. Ashan" oninput="clearErr('e-fname')"/>
            <div class="field-error" id="e-fname">First name is required</div>
          </div>
          <div class="col-md-6">
            <label class="form-label-um">Last Name <span style="color:var(--danger)">*</span></label>
            <input type="text" class="form-ctrl" id="f-lname" placeholder="e.g. Kumara" oninput="clearErr('e-lname')"/>
            <div class="field-error" id="e-lname">Last name is required</div>
          </div>
          <div class="col-12">
            <label class="form-label-um">Email Address <span style="color:var(--danger)">*</span></label>
            <input type="email" class="form-ctrl" id="f-email" placeholder="user@creative4.lk" oninput="clearErr('e-email')"/>
            <div class="field-error" id="e-email">Valid email required</div>
          </div>
          <div class="col-md-6">
            <label class="form-label-um">Phone</label>
            <input type="text" class="form-ctrl" id="f-phone" placeholder="+94 77 000 0000"/>
          </div>
          <div class="col-md-6">
            <label class="form-label-um">Department</label>
            <select class="form-ctrl" id="f-dept">
              <option value="">Select dept…</option>
              <option>Management</option>
              <option>Design Studio</option>
              <option>Post-Production</option>
              <option>Social Media</option>
              <option>Events</option>
              <option>Finance</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Step 2: Role Selection -->
      <div id="step-2" style="display:none;">
        <label class="form-label-um" style="margin-bottom:10px;">Select Role <span style="color:var(--danger)">*</span></label>
        <div class="role-selector">
          <label class="role-opt" id="ro-superadmin">
            <input type="radio" name="f-role" value="Super Admin"/>
            <div class="ro-icon" style="background:#ede9fe;color:#7c3aed;"><i class="fas fa-crown"></i></div>
            <div><div class="ro-name">Super Admin</div><div class="ro-desc">Full system access</div></div>
          </label>
          <label class="role-opt" id="ro-admin">
            <input type="radio" name="f-role" value="Admin"/>
            <div class="ro-icon" style="background:#dbeafe;color:#1d4ed8;"><i class="fas fa-user-tie"></i></div>
            <div><div class="ro-name">Admin</div><div class="ro-desc">Content & clients</div></div>
          </label>
          <label class="role-opt" id="ro-editor">
            <input type="radio" name="f-role" value="Editor"/>
            <div class="ro-icon" style="background:#fef3c7;color:#b45309;"><i class="fas fa-pen-nib"></i></div>
            <div><div class="ro-name">Editor</div><div class="ro-desc">Edit & manage</div></div>
          </label>
          <label class="role-opt" id="ro-viewer">
            <input type="radio" name="f-role" value="Viewer"/>
            <div class="ro-icon" style="background:#f3f4f6;color:#475569;"><i class="fas fa-eye"></i></div>
            <div><div class="ro-name">Viewer</div><div class="ro-desc">View only</div></div>
          </label>
        </div>
        <div class="field-error" id="e-role" style="margin-top:8px;">Please select a role</div>

        <!-- Permission preview -->
        <div id="role-perm-preview" style="display:none;margin-top:16px;background:#f8fafc;border-radius:10px;padding:14px 16px;border:1px solid var(--border);">
          <div style="font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:8px;">Permissions for this role</div>
          <div id="role-perm-list" style="display:flex;flex-wrap:wrap;gap:6px;"></div>
        </div>
      </div>

      <!-- Step 3: Security -->
      <div id="step-3" style="display:none;">
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label-um">Password <span style="color:var(--danger)">*</span></label>
            <div style="position:relative;">
              <input type="password" class="form-ctrl" id="f-pwd" placeholder="Min. 8 characters" oninput="checkPwd();clearErr('e-pwd')"/>
              <button type="button" onclick="togglePwd('f-pwd','eye1')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.9rem;"><i class="fas fa-eye" id="eye1"></i></button>
            </div>
            <div class="pw-strength"><div class="pw-strength-bar" id="pw-bar"></div></div>
            <div class="pw-hint" id="pw-hint">Enter a password</div>
            <div class="field-error" id="e-pwd">Password must be at least 8 characters</div>
          </div>
          <div class="col-12">
            <label class="form-label-um">Confirm Password <span style="color:var(--danger)">*</span></label>
            <div style="position:relative;">
              <input type="password" class="form-ctrl" id="f-pwd2" placeholder="Repeat password" oninput="clearErr('e-pwd2')"/>
              <button type="button" onclick="togglePwd('f-pwd2','eye2')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.9rem;"><i class="fas fa-eye" id="eye2"></i></button>
            </div>
            <div class="field-error" id="e-pwd2">Passwords do not match</div>
          </div>
          <div class="col-12">
            <div style="background:var(--cyan-pale);border-radius:10px;padding:14px 16px;display:flex;flex-direction:column;gap:10px;">
              <div class="toggle-wrap">
                <label class="toggle"><input type="checkbox" id="f-active" checked/><span class="toggle-slider"></span></label>
                <span class="toggle-label">Account Active</span>
              </div>
              <div class="toggle-wrap">
                <label class="toggle"><input type="checkbox" id="f-send-email" checked/><span class="toggle-slider"></span></label>
                <span class="toggle-label">Send welcome email with credentials</span>
              </div>
              <div class="toggle-wrap">
                <label class="toggle"><input type="checkbox" id="f-force-pwd"/><span class="toggle-slider"></span></label>
                <span class="toggle-label">Force password change on first login</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <div class="modal-footer" style="justify-content:space-between;">
      <button class="btn-outline-cyan" id="btn-prev" style="display:none;" onclick="goStep(currentStep-1)"><i class="fas fa-arrow-left me-1"></i> Back</button>
      <div style="display:flex;gap:8px;margin-left:auto;">
        <button class="btn-outline-cyan" onclick="closeModal('addAdminModal')">Cancel</button>
        <button class="btn-cyan" id="btn-next" onclick="nextStep()">Next <i class="fas fa-arrow-right ms-1"></i></button>
        <button class="btn-cyan" id="btn-submit" style="display:none;" onclick="submitAdmin()"><i class="fas fa-user-plus me-2"></i>Create Admin</button>
      </div>
    </div>
  </div>
</div>

<!-- ── VIEW PROFILE MODAL ── -->
<div class="modal-overlay" id="viewAdminModal">
  <div class="modal-box">
    <div class="modal-header">
      <h4>ADMIN PROFILE</h4>
      <button class="modal-close" onclick="closeModal('viewAdminModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body" id="view-modal-body">
      <!-- filled by JS -->
    </div>
    <div class="modal-footer">
      <button class="btn-outline-cyan" onclick="closeModal('viewAdminModal')">Close</button>
    </div>
  </div>
</div>

<!-- ── DELETE CONFIRM MODAL ── -->
<div class="modal-overlay" id="deleteModal">
  <div class="modal-box" style="max-width:380px;">
    <div class="modal-body del-modal">
      <div class="del-icon"><i class="fas fa-user-xmark"></i></div>
      <div class="del-title">Delete Admin Account?</div>
      <div class="del-msg" id="del-msg">This action cannot be undone. The admin account will be permanently removed.</div>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:22px;">
        <button class="btn-outline-cyan" onclick="closeModal('deleteModal')">Cancel</button>
        <button class="btn-danger" onclick="doDelete()"><i class="fas fa-trash me-2"></i>Delete Account</button>
      </div>
    </div>
  </div>
</div>

<!-- ── RESET PASSWORD MODAL ── -->
<div class="modal-overlay" id="resetPwdModal">
  <div class="modal-box" style="max-width:400px;">
    <div class="modal-header"><h4>RESET PASSWORD</h4><button class="modal-close" onclick="closeModal('resetPwdModal')"><i class="fas fa-times"></i></button></div>
    <div class="modal-body">
      <div style="background:var(--cyan-pale);border-radius:10px;padding:14px;margin-bottom:16px;font-size:.84rem;color:var(--cyan-dark);">
        <i class="fas fa-info-circle me-2"></i>A new temporary password will be sent to the admin's email.
      </div>
      <label class="form-label-um">New Password <span style="color:var(--danger)">*</span></label>
      <div style="position:relative;">
        <input type="password" class="form-ctrl" id="rp-pwd" placeholder="Min. 8 characters" oninput="checkRpPwd()"/>
        <button type="button" onclick="togglePwd('rp-pwd','eye3')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.9rem;"><i class="fas fa-eye" id="eye3"></i></button>
      </div>
      <div class="pw-strength mt-2"><div class="pw-strength-bar" id="rp-bar"></div></div>
      <div class="pw-hint" id="rp-hint">Enter a new password</div>
      <div class="toggle-wrap mt-3">
        <label class="toggle"><input type="checkbox" checked/><span class="toggle-slider"></span></label>
        <span class="toggle-label">Email new credentials to admin</span>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline-cyan" onclick="closeModal('resetPwdModal')">Cancel</button>
      <button class="btn-cyan" onclick="doResetPwd()"><i class="fas fa-key me-2"></i>Reset Password</button>
    </div>
  </div>
</div>

<!-- Toast container -->
<div class="toast-wrap" id="toast-wrap"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Current admin role — used by JS for client-side permission checks
const ADMIN_ROLE = <?= json_encode($role) ?>;
const CAN_DELETE_PORTFOLIO  = <?= json_encode(canAccess('portfolio_delete')) ?>;
const CAN_ADD_PORTFOLIO     = <?= json_encode(canAccess('portfolio_add')) ?>;
const CAN_MANAGE_TILES      = <?= json_encode(canAccess('portfoliotiles')) ?>;
// ══════════════════════════════════════════════════
// EXISTING FUNCTIONALITY
// ══════════════════════════════════════════════════
document.getElementById('sidebarToggle').addEventListener('click', function(){
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarBackdrop').classList.toggle('show');
});
document.getElementById('sidebarBackdrop').addEventListener('click', function(){
  document.getElementById('sidebar').classList.remove('open');
  this.classList.remove('show');
});
// Auto-close the mobile sidebar once a nav link is tapped, so people
// don't have to manually close it after every navigation
document.querySelectorAll('.sidebar-link').forEach(link => {
  link.addEventListener('click', function(){
    if (window.innerWidth <= 768) {
      document.getElementById('sidebar').classList.remove('open');
      document.getElementById('sidebarBackdrop').classList.remove('show');
    }
  });
});

// ══════════════════════════════════════════════════
// TERMS & CONDITIONS — ticklist source data (from CREATIVE 4 Service Terms & Conditions)
// ══════════════════════════════════════════════════
const TC_DATA = {
  'Audio Production': {
    terms: [
      'This quotation is valid for 14 days from the date of issue.',
      'Final scripts must be approved before recording begins.',
      'Recording will be carried out by the selected voice artist.',
      'Audio editing and delivery will follow the approved script and sequence.',
      'Any revisions, re-recordings, or changes after approval or delivery may incur additional charges.'
    ],
    payment: [
      '50% advance payment is required to commence the project.',
      'The remaining 50% is payable upon completion and before delivery of final audio files.',
      'All payments shall be made to CREATIVE 4.'
    ]
  },
  'Event Backdrop Installation': {
    terms: [
      'This quotation is valid for 7 days from the date of issue.',
      'Installation will be carried out on the agreed date, time, and venue.',
      'Backdrop framework is provided on a returnable basis.',
      'Installation, dismantling, and transportation are included unless otherwise specified.',
      'Any changes after confirmation may incur additional charges.'
    ],
    payment: [
      'Full payment shall be made immediately after installation, unless otherwise agreed in writing.',
      'All payments shall be made to CREATIVE 4.'
    ]
  },
  'Website Design & Development': {
    terms: [
      'This quotation is valid for 7 days from the date of issue.',
      'The quotation covers only the services specified herein.',
      'Domain, hosting, SSL, and third-party services are included only if stated.',
      'The client must provide all required content before development begins.',
      'Additional features, revisions, or changes beyond the agreed scope may incur extra charges.'
    ],
    payment: [
      '50% advance payment is required before project commencement.',
      'The remaining 50% is payable before website launch or final file delivery.',
      'Additional work outside the approved scope will be quoted separately.'
    ]
  },
  'Video Production': {
    terms: [
      'This quotation is valid for 7 days from the date of issue.',
      'One revision session is included after the first preview.',
      'Additional concepts, effects, animation styles, or duration changes will incur extra charges.',
      'Final video files will be delivered after approval and full payment.'
    ],
    payment: [
      '50% advance payment is required before production begins.',
      'The remaining 50% is payable before delivery of the final video.',
      'All payments shall be made to CREATIVE 4.'
    ]
  },
  'Design Studio Works': {
    terms: [
      'This quotation is valid for 7 days from the date of issue.',
      'The quotation covers only the items and services specified.',
      'Reasonable revisions are included unless otherwise stated.',
      'Additional design work or revisions beyond scope will be charged separately.',
      'Final editable files will be provided only if included in the quotation.'
    ],
    payment: [
      '50% advance payment is required to commence the project.',
      'The remaining 50% is payable before delivery of final artwork or print-ready files.',
      'Printing and delivery charges are excluded unless specifically mentioned.'
    ]
  },
  'Other Services': {
    terms: [
      'This quotation is valid for 7 days from the date of issue.',
      'The quotation applies only to the specified services.',
      'Any additional work beyond scope will incur separate charges.',
      'Project timelines depend on timely client approvals and required inputs.'
    ],
    payment: [
      'Payment terms will be specified in the quotation.',
      'Unless otherwise stated, 50% advance payment is required before work begins.',
      'The remaining balance is payable upon completion.',
      'All payments shall be made to CREATIVE 4.'
    ]
  }
};

// Draw the tick-box list for a given prefix ('inv' or 'qt') into its container
function renderTCChecklist(prefix) {
  const el = document.getElementById(prefix + '_tc_list');
  if (!el) return;
  el.innerHTML = Object.keys(TC_DATA).map((cat, i) => {
    const id = prefix + '_tc_' + i;
    return `<div class="form-check tc-check-item"><input class="form-check-input tc-check" type="checkbox" id="${id}" data-cat="${cat.replace(/"/g,'&quot;')}"><label class="form-check-label" for="${id}">${cat}</label></div>`;
  }).join('');
  el.querySelectorAll('.tc-check').forEach(cb => {
    cb.addEventListener('change', prefix === 'inv' ? updateInvoicePreview : updateQuotationPreview);
  });
}

// Read the ticked categories + custom text for a given prefix
function getSelectedTerms(prefix) {
  const checks = document.querySelectorAll('#' + prefix + '_tc_list .tc-check:checked');
  const custom = (document.getElementById(prefix + '_tc_custom')?.value || '').trim();
  const blocks = [];
  checks.forEach(c => {
    const cat = c.dataset.cat;
    if (TC_DATA[cat]) blocks.push({ title: cat, terms: TC_DATA[cat].terms, payment: TC_DATA[cat].payment });
  });
  return { blocks, custom };
}

// Build the HTML shown in the live preview for the selected terms + custom conditions
function renderTermsHTML(prefix) {
  const { blocks, custom } = getSelectedTerms(prefix);
  if (!blocks.length && !custom) return '';
  let html = '<div class="doc-terms-block"><div class="doc-terms-title">Terms &amp; Conditions</div>';
  blocks.forEach(b => {
    html += `<div class="doc-terms-cat">${b.title}</div><ul class="doc-terms-list">` + b.terms.map(t => `<li>${t}</li>`).join('') + '</ul>';
    if (b.payment && b.payment.length) {
      html += `<div class="doc-terms-subhead">Conditions of Payment</div><ul class="doc-terms-list">` + b.payment.map(t => `<li>${t}</li>`).join('') + '</ul>';
    }
  });
  if (custom) {
    html += '<div class="doc-terms-cat">Additional Conditions</div><ul class="doc-terms-list">' + custom.split('\n').filter(l => l.trim()).map(l => `<li>${l.trim()}</li>`).join('') + '</ul>';
  }
  html += '</div>';
  return html;
}

// ── Preload logo & QR code so they're ready when a PDF is generated ──
const DOC_LOGO_IMG = new Image();
DOC_LOGO_IMG.src = 'images/creative4-logo-bw.png';
const DOC_QR_IMG = new Image();
DOC_QR_IMG.src = 'images/creative4-qr-2026.jpg';

function addItem(prefix) {
  const container = document.getElementById(prefix + '-items');
  const row = document.createElement('div');
  row.className = 'line-item-row row g-2 mt-1';
  row.innerHTML = `<div class="col-6"><input type="text" class="form-control item-desc" placeholder="Service description"/></div><div class="col-3"><input type="number" class="form-control item-qty" placeholder="Qty" value="1" min="1"/></div><div class="col-3"><input type="number" class="form-control item-price" placeholder="Price" min="0"/></div>`;
  container.appendChild(row);
  attachListeners();
}

function attachListeners() {
  document.querySelectorAll('#inv-items .item-desc, #inv-items .item-qty, #inv-items .item-price').forEach(el => el.addEventListener('input', updateInvoicePreview));
  document.querySelectorAll('#qt-items .item-desc, #qt-items .item-qty, #qt-items .item-price').forEach(el => el.addEventListener('input', updateQuotationPreview));
}

function updateInvoicePreview() {
  const client=document.getElementById('inv_client')?.value||'—';const email=document.getElementById('inv_email')?.value||'—';const no=document.getElementById('inv_no')?.value||'—';const date=document.getElementById('inv_date')?.value||'—';const notes=document.getElementById('inv_notes')?.value||'';
  if(document.getElementById('prev-client'))document.getElementById('prev-client').textContent=client||'—';
  if(document.getElementById('prev-email'))document.getElementById('prev-email').textContent=email||'—';
  if(document.getElementById('prev-no'))document.getElementById('prev-no').textContent=no;
  if(document.getElementById('prev-date'))document.getElementById('prev-date').textContent=date;
  if(document.getElementById('prev-notes'))document.getElementById('prev-notes').textContent=notes;
  const { total } = computeTotals('inv-items','inv_discount','inv_discount_type');
  buildItemTable('inv-items','prev-items','prev-total','inv_discount','inv_discount_type','prev-subtotal','prev-discount','prev-discount-label');
  const advance = parseFloat(document.getElementById('inv_advance')?.value)||0;
  const balanceDue = Math.max(total - advance, 0);
  if(document.getElementById('prev-balance-total'))document.getElementById('prev-balance-total').textContent=total.toLocaleString('en-LK',{minimumFractionDigits:2});
  if(document.getElementById('prev-advance'))document.getElementById('prev-advance').textContent=advance.toLocaleString('en-LK',{minimumFractionDigits:2});
  if(document.getElementById('prev-balance-due'))document.getElementById('prev-balance-due').textContent=balanceDue.toLocaleString('en-LK',{minimumFractionDigits:2});
  if(document.getElementById('prev-terms'))document.getElementById('prev-terms').innerHTML=renderTermsHTML('inv');
}

function updateQuotationPreview() {
  const client=document.getElementById('qt_client')?.value||'—';const service=document.getElementById('qt_service')?.value||'—';
  if(document.getElementById('qt-prev-client'))document.getElementById('qt-prev-client').textContent=client;
  if(document.getElementById('qt-prev-service'))document.getElementById('qt-prev-service').textContent=service;
  buildItemTable('qt-items','qt-prev-items','qt-prev-total','qt_discount','qt_discount_type','qt-prev-subtotal','qt-prev-discount','qt-prev-discount-label');
  if(document.getElementById('qt-prev-terms'))document.getElementById('qt-prev-terms').innerHTML=renderTermsHTML('qt');
}

// Returns {subtotal, discountAmount, total, items:[{desc,qty,price,line}]}
function computeTotals(sourceId, discountInputId, discountTypeId) {
  const rows=document.querySelectorAll('#'+sourceId+' .line-item-row');
  let subtotal=0; const items=[];
  rows.forEach(r=>{
    const desc=r.querySelector('.item-desc')?.value||'';
    const qty=parseFloat(r.querySelector('.item-qty')?.value)||0;
    const price=parseFloat(r.querySelector('.item-price')?.value)||0;
    const line=qty*price; subtotal+=line;
    if(desc) items.push({desc,qty,price,line});
  });
  const discountVal = parseFloat(document.getElementById(discountInputId)?.value)||0;
  const discountType = document.getElementById(discountTypeId)?.value || 'percent';
  const discountAmount = discountType==='percent' ? subtotal*(discountVal/100) : Math.min(discountVal, subtotal);
  const total = Math.max(subtotal - discountAmount, 0);
  return {subtotal, discountAmount, discountVal, discountType, total, items};
}

function buildItemTable(sourceId, targetId, totalId, discountInputId, discountTypeId, subtotalId, discountDisplayId, discountLabelId) {
  const tbody=document.getElementById(targetId);const totalEl=document.getElementById(totalId);if(!tbody)return;
  const {subtotal, discountAmount, discountVal, discountType, total, items} = computeTotals(sourceId, discountInputId, discountTypeId);
  let html='';
  items.forEach(i=>{html+=`<tr><td>${i.desc}</td><td>${i.qty}</td><td>LKR ${i.price.toFixed(2)}</td><td><strong>LKR ${i.line.toFixed(2)}</strong></td></tr>`;});
  tbody.innerHTML=html||'<tr><td colspan="4" style="color:#94a3b8;text-align:center;padding:16px;">Fill in line items →</td></tr>';
  if(document.getElementById(subtotalId)) document.getElementById(subtotalId).textContent='LKR '+subtotal.toLocaleString('en-LK',{minimumFractionDigits:2});
  const discountRow=document.getElementById((discountDisplayId||'').replace('-discount','-discount-row'));
  if(document.getElementById(discountDisplayId)){
    document.getElementById(discountDisplayId).textContent='- LKR '+discountAmount.toLocaleString('en-LK',{minimumFractionDigits:2});
  }
  if(document.getElementById(discountLabelId)){
    document.getElementById(discountLabelId).textContent = discountVal>0 ? `Discount (${discountType==='percent'?discountVal+'%':'Fixed'})` : 'Discount';
  }
  if(discountRow) discountRow.style.display = discountVal>0 ? 'flex' : 'none';
  if(totalEl)totalEl.textContent='LKR '+total.toLocaleString('en-LK',{minimumFractionDigits:2});
}

document.addEventListener('DOMContentLoaded', function(){
  attachListeners();
  renderTCChecklist('inv');
  renderTCChecklist('qt');
  ['inv_client','inv_email','inv_no','inv_date','inv_notes','inv_discount','inv_discount_type','inv_advance','inv_tc_custom'].forEach(id=>{const el=document.getElementById(id);if(el){el.addEventListener('input',updateInvoicePreview);if(el.tagName==='SELECT')el.addEventListener('change',updateInvoicePreview);}});
  ['qt_client','qt_service','qt_discount','qt_discount_type','qt_tc_custom'].forEach(id=>{const el=document.getElementById(id);if(el){el.addEventListener('input',updateQuotationPreview);if(el.tagName==='SELECT')el.addEventListener('change',updateQuotationPreview);}});
  loadClientsIntoDropdowns();
});

// ── Load real clients from Firestore into both dropdowns ──
function loadClientsIntoDropdowns() {
  // no-op placeholder; module script triggers population once data is ready
}

window.populateClientDropdowns = function(clientsArray) {
  const invSel = document.getElementById('inv_client_select');
  const qtSel  = document.getElementById('qt_client_select');
  if(!invSel && !qtSel) return;
  const opts = ['<option value="">Select client…</option>'];
  clientsArray.forEach(c=>{
    const label = c.company ? `${c.name} — ${c.company}` : c.name;
    opts.push(`<option value="${c.id}" data-name="${(c.name||'').replace(/"/g,'&quot;')}" data-email="${(c.email||'').replace(/"/g,'&quot;')}" data-phone="${(c.phone||'').replace(/"/g,'&quot;')}" data-address="${(c.address||'').replace(/"/g,'&quot;')}">${label}</option>`);
  });
  opts.push('<option value="__manual__">Other (enter manually)</option>');
  if(invSel) invSel.innerHTML = opts.join('');
  if(qtSel)  qtSel.innerHTML  = opts.join('');
};

window.onInvoiceClientChange = function() {
  const sel = document.getElementById('inv_client_select');
  const opt = sel.options[sel.selectedIndex];
  const manualWrap = document.getElementById('inv_client_manual_wrap');
  if(sel.value === '__manual__') {
    manualWrap.style.display = '';
    document.getElementById('inv_client').value = '';
    document.getElementById('inv_email').value = '';
    document.getElementById('inv_client').focus();
  } else {
    manualWrap.style.display = 'none';
    document.getElementById('inv_client').value = opt?.dataset.name || '';
    document.getElementById('inv_email').value = opt?.dataset.email || '';
  }
  updateInvoicePreview();
};

window.onQuotationClientChange = function() {
  const sel = document.getElementById('qt_client_select');
  const opt = sel.options[sel.selectedIndex];
  const manualWrap = document.getElementById('qt_client_manual_wrap');
  if(sel.value === '__manual__') {
    manualWrap.style.display = '';
    document.getElementById('qt_client').value = '';
    document.getElementById('qt_client').focus();
  } else {
    manualWrap.style.display = 'none';
    document.getElementById('qt_client').value = opt?.dataset.name || '';
  }
  updateQuotationPreview();
};

// ── PDF Download (no print dialog) ──
window.downloadPDF = function(type) {
  const { jsPDF } = window.jspdf;
  const docPdf = new jsPDF({ unit:'pt', format:'a4' });
  const isInv = type === 'invoice';
  const sourceId = isInv ? 'inv-items' : 'qt-items';
  const discountInputId = isInv ? 'inv_discount' : 'qt_discount';
  const discountTypeId  = isInv ? 'inv_discount_type' : 'qt_discount_type';
  const { subtotal, discountAmount, discountVal, discountType, total, items } = computeTotals(sourceId, discountInputId, discountTypeId);

  const client = document.getElementById(isInv?'inv_client':'qt_client')?.value || '—';
  const email  = isInv ? (document.getElementById('inv_email')?.value || '') : '';
  const docNo  = isInv ? (document.getElementById('inv_no')?.value || '') : (document.getElementById('qt_no')?.value || '');
  const dateStr= isInv ? (document.getElementById('inv_date')?.value || '') : (document.getElementById('qt_valid')?.value || '');
  const notes  = isInv ? (document.getElementById('inv_notes')?.value || '') : '';
  const service= !isInv ? (document.getElementById('qt_service')?.value || '') : '';
  const advance = isInv ? (parseFloat(document.getElementById('inv_advance')?.value)||0) : 0;
  const balanceDue = isInv ? Math.max(total - advance, 0) : 0;
  const { blocks: tcBlocks, custom: tcCustom } = getSelectedTerms(isInv ? 'inv' : 'qt');

  let y = 50;
  if (DOC_LOGO_IMG.complete && DOC_LOGO_IMG.naturalWidth) {
    const logoH = 26;
    const logoW = logoH * (DOC_LOGO_IMG.naturalWidth / DOC_LOGO_IMG.naturalHeight);
    docPdf.addImage(DOC_LOGO_IMG, 'PNG', 40, y-18, logoW, logoH);
  } else {
    docPdf.setFont('helvetica','bold'); docPdf.setFontSize(20);
    docPdf.text('CREATIVE 4', 40, y);
  }
  docPdf.setFontSize(9); docPdf.setFont('helvetica','normal'); docPdf.setTextColor(120);
  docPdf.text('The Ultimate Imagination', 40, y+14);
  docPdf.text('No.265/6/9, 2nd Lane, Thotupola Road, Delthara, Piliyandala, Sri Lanka', 40, y+26);
  docPdf.text('Tel: (+94) 77 33 77495 | (+94) 70 33 77495 · Email: ads@creative4.lk', 40, y+38);
  docPdf.setTextColor(0); docPdf.setFontSize(18); docPdf.setFont('helvetica','bold');
  docPdf.text(isInv ? 'INVOICE' : 'QUOTATION', 555, y, {align:'right'});

  y += 62;
  docPdf.setFontSize(9); docPdf.setTextColor(120);
  docPdf.text(isInv ? 'Bill To' : 'Prepared For', 40, y);
  docPdf.setFontSize(11); docPdf.setTextColor(0); docPdf.setFont('helvetica','bold');
  docPdf.text(client || '—', 40, y+14);
  if(email){ docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(120); docPdf.text(email, 40, y+28); }
  if(service){ docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(120); docPdf.text(service, 40, y+28); }

  docPdf.setFontSize(9); docPdf.setTextColor(120); docPdf.setFont('helvetica','normal');
  docPdf.text((isInv?'Invoice No.':'Quotation No.'), 555, y, {align:'right'});
  docPdf.setFontSize(11); docPdf.setTextColor(0); docPdf.setFont('helvetica','bold');
  docPdf.text(docNo || '—', 555, y+14, {align:'right'});
  docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(120);
  docPdf.text((isInv?'Date: ':'Valid Until: ') + (dateStr||'—'), 555, y+28, {align:'right'});

  y += 50;
  const body = items.map(i=>[i.desc, String(i.qty), 'LKR '+i.price.toFixed(2), 'LKR '+i.line.toFixed(2)]);
  docPdf.autoTable({
    startY: y,
    head: [[isInv?'Description':'Description', 'Qty', isInv?'Unit Price':'Rate', isInv?'Total':'Amount']],
    body: body.length ? body : [['—','','','']],
    theme: 'striped',
    headStyles: { fillColor: [14,165,233] },
    styles: { fontSize: 9 },
    margin: { left: 40, right: 40 }
  });

  let finalY = docPdf.lastAutoTable.finalY + 20;
  const totalsX = 350; // start label further left so long labels never collide with the right-aligned value
  docPdf.setFontSize(10); docPdf.setTextColor(80);
  docPdf.text('Subtotal', totalsX, finalY);
  docPdf.text('LKR '+subtotal.toFixed(2), 555, finalY, {align:'right'});
  if(discountVal > 0) {
    finalY += 16;
    const label = discountType==='percent' ? `Discount (${discountVal}%)` : 'Discount';
    docPdf.text(label, totalsX, finalY);
    docPdf.text('- LKR '+discountAmount.toFixed(2), 555, finalY, {align:'right'});
  }
  finalY += 22;
  docPdf.setDrawColor(220); docPdf.line(totalsX, finalY-14, 555, finalY-14);
  docPdf.setFont('helvetica','bold'); docPdf.setFontSize(12); docPdf.setTextColor(14,116,144);
  docPdf.text(isInv?'Grand Total':'Estimated Total', totalsX, finalY);
  docPdf.text('LKR '+total.toFixed(2), 555, finalY, {align:'right'});

  // ── Advance / Balance box (invoice only) ──
  if (isInv) {
    finalY += 22;
    docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(80);
    docPdf.text('Advance Paid', totalsX, finalY);
    docPdf.text('LKR '+advance.toFixed(2), 555, finalY, {align:'right'});
    finalY += 16;
    docPdf.setFont('helvetica','bold'); docPdf.setTextColor(14,116,144);
    docPdf.text('Balance Due', totalsX, finalY);
    docPdf.text('LKR '+balanceDue.toFixed(2), 555, finalY, {align:'right'});
  }

  if(notes) {
    finalY += 26;
    docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(120);
    const split = docPdf.splitTextToSize(notes, 515);
    docPdf.text(split, 40, finalY);
    finalY += split.length * 11;
  }

  // ── Helper to avoid running off the page ──
  function ensureSpace(needed) {
    if (finalY + needed > 780) { docPdf.addPage(); finalY = 50; }
  }

  // ── Terms & Conditions (ticked categories + custom) ──
  if (tcBlocks.length || tcCustom) {
    finalY += 22;
    ensureSpace(30);
    docPdf.setFont('helvetica','bold'); docPdf.setFontSize(10); docPdf.setTextColor(2,132,199);
    docPdf.text('Terms & Conditions', 40, finalY);
    finalY += 14;
    tcBlocks.forEach(b => {
      ensureSpace(16);
      docPdf.setFont('helvetica','bold'); docPdf.setFontSize(9); docPdf.setTextColor(15,23,42);
      docPdf.text(b.title, 40, finalY);
      finalY += 12;
      docPdf.setFont('helvetica','normal'); docPdf.setTextColor(80);
      b.terms.forEach(t => {
        const lines = docPdf.splitTextToSize('• ' + t, 515);
        ensureSpace(lines.length * 11);
        docPdf.text(lines, 44, finalY);
        finalY += lines.length * 11;
      });
      if (b.payment && b.payment.length) {
        ensureSpace(12);
        docPdf.setFont('helvetica','bold'); docPdf.setFontSize(8.5); docPdf.setTextColor(2,132,199);
        docPdf.text('Conditions of Payment', 44, finalY);
        finalY += 11;
        docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(80);
        b.payment.forEach(t => {
          const lines = docPdf.splitTextToSize('• ' + t, 511);
          ensureSpace(lines.length * 11);
          docPdf.text(lines, 44, finalY);
          finalY += lines.length * 11;
        });
      }
      finalY += 6;
    });
    if (tcCustom) {
      ensureSpace(16);
      docPdf.setFont('helvetica','bold'); docPdf.setFontSize(9); docPdf.setTextColor(15,23,42);
      docPdf.text('Additional Conditions', 40, finalY);
      finalY += 12;
      docPdf.setFont('helvetica','normal'); docPdf.setTextColor(80);
      tcCustom.split('\n').filter(l=>l.trim()).forEach(t => {
        const lines = docPdf.splitTextToSize('• ' + t.trim(), 515);
        ensureSpace(lines.length * 11);
        docPdf.text(lines, 44, finalY);
        finalY += lines.length * 11;
      });
    }
  }

  // ── Bank Deposit Details ──
  finalY += 16;
  ensureSpace(50);
  docPdf.setFillColor(224,242,254);
  docPdf.roundedRect(40, finalY, 515, 42, 4, 4, 'F');
  docPdf.setFont('helvetica','bold'); docPdf.setFontSize(8.5); docPdf.setTextColor(2,132,199);
  docPdf.text('BANK DEPOSIT DETAILS', 50, finalY+14);
  docPdf.setFont('helvetica','normal'); docPdf.setFontSize(9); docPdf.setTextColor(15,23,42);
  docPdf.text('Bank: Sampath Bank   Branch: Piliyandala', 50, finalY+27);
  docPdf.text('Account Name: CREATIVE 4   Account No: 0019 1001 1894', 50, finalY+38);
  finalY += 58;

  // ── Disclaimer footer + QR code ──
  ensureSpace(60);
  docPdf.setFont('helvetica','italic'); docPdf.setFontSize(8); docPdf.setTextColor(120);
  const disclaimer = isInv
    ? 'This is a system-generated electronic invoice (E-Invoice) issued by CREATIVE 4. No signature is required, and this document is deemed an official invoice.'
    : 'This is an electronically generated quotation issued by CREATIVE 4 and is valid without a signature.';
  docPdf.text(docPdf.splitTextToSize(disclaimer, 460), 40, finalY);
  if (DOC_QR_IMG.complete && DOC_QR_IMG.naturalWidth) {
    docPdf.addImage(DOC_QR_IMG, 'JPEG', 515, finalY-30, 40, 40);
  }

  const filename = `${isInv?'Invoice':'Quotation'}-${(docNo||'doc').replace(/[^a-zA-Z0-9-]/g,'_')}.pdf`;
  docPdf.save(filename);
};

function generateDoc(type){/* overridden below by window.generateDoc */}



// ══════════════════════════════════════════════════
// USER MANAGEMENT
// ══════════════════════════════════════════════════

// ── Toast ──
function showToast(msg, type='success') {
  const wrap = document.getElementById('toast-wrap');
  const icons = {success:'fa-circle-check', danger:'fa-circle-xmark', info:'fa-circle-info'};
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fas ${icons[type]||icons.info} ti"></i><span class="tm">${msg}</span>`;
  wrap.appendChild(t);
  setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateX(40px)'; t.style.transition='all .4s'; setTimeout(()=>t.remove(),400); }, 3500);
}

// ── Modals ──
function openModal(id){ document.getElementById(id).classList.add('show'); }
function closeModal(id){ document.getElementById(id).classList.remove('show'); }

// Close on backdrop click
document.querySelectorAll('.modal-overlay').forEach(o=>{
  o.addEventListener('click', function(e){ if(e.target===this) closeModal(this.id); });
});

// ── Role card toggle ──
function toggleRoleCard(card) {
  const list = card.querySelector('.perm-list');
  const icon = card.querySelector('.fa-chevron-down');
  const open = list.style.display !== 'none';
  list.style.display = open ? 'none' : 'block';
  icon.style.transform = open ? '' : 'rotate(180deg)';
}

// ── Filter admins ──
function filterAdmins() {
  const q   = document.getElementById('um-search').value.toLowerCase();
  const rol = document.getElementById('um-role-filter').value;
  const sts = document.getElementById('um-status-filter').value;
  const rows = document.querySelectorAll('#admin-tbody tr');
  let visible = 0;
  rows.forEach(r=>{
    const name   = r.dataset.name;
    const email  = r.dataset.email;
    const role   = r.dataset.role;
    const status = r.dataset.status;
    const matchQ = !q || name.includes(q) || email.includes(q);
    const matchR = !rol || role === rol;
    const matchS = !sts || status === sts;
    const show = matchQ && matchR && matchS;
    r.style.display = show ? '' : 'none';
    if(show) visible++;
  });
  const sc = document.getElementById('showing-count');
  if(sc) sc.textContent = visible;
}

// ── Add Admin Modal (multi-step) ──
let currentStep = 1;
let editingId   = null;

const rolePerms = {
  'Super Admin': ['Full system access','Manage all admins','Delete records','Financial data','Settings'],
  'Admin':       ['Manage content','Manage clients','Generate invoices','View reports'],
  'Editor':      ['Edit portfolio','Edit client info','View invoices'],
  'Viewer':      ['View-only access','Export reports'],
};

function openAddModal() {
  editingId = null;
  document.getElementById('modal-title').textContent = 'ADD NEW ADMIN';
  document.getElementById('btn-submit').innerHTML = '<i class="fas fa-user-plus me-2"></i>Create Admin';
  // Reset form
  ['f-fname','f-lname','f-email','f-phone','f-pwd','f-pwd2'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  document.getElementById('f-dept').value='';
  document.querySelectorAll('[name="f-role"]').forEach(r=>r.checked=false);
  document.querySelectorAll('.role-opt').forEach(o=>o.classList.remove('selected'));
  document.getElementById('f-active').checked=true;
  document.getElementById('f-send-email').checked=true;
  document.getElementById('f-force-pwd').checked=false;
  document.getElementById('role-perm-preview').style.display='none';
  document.getElementById('pw-bar').style.width='0';
  document.getElementById('pw-hint').textContent='Enter a password';
  ['e-fname','e-lname','e-email','e-role','e-pwd','e-pwd2'].forEach(id=>{ const el=document.getElementById(id); if(el){ el.classList.remove('show'); const f=document.getElementById(id.replace('e-','f-')); if(f) f.classList.remove('error'); } });
  goStep(1);
  openModal('addAdminModal');
}

function goStep(n) {
  for(let i=1;i<=3;i++){
    document.getElementById(`step-${i}`).style.display = i===n ? '' : 'none';
    const tab = document.getElementById(`step-tab-${i}`);
    tab.style.background = i===n ? 'var(--cyan)' : '#f8fafc';
    tab.style.color = i===n ? '#fff' : 'var(--muted)';
  }
  currentStep = n;
  document.getElementById('btn-prev').style.display = n>1 ? '' : 'none';
  document.getElementById('btn-next').style.display = n<3 ? '' : 'none';
  document.getElementById('btn-submit').style.display = n===3 ? '' : 'none';
}

function nextStep() {
  if(currentStep===1 && !validateStep1()) return;
  if(currentStep===2 && !validateStep2()) return;
  goStep(currentStep+1);
}

function validateStep1() {
  let ok=true;
  if(!document.getElementById('f-fname').value.trim()){ showErr('f-fname','e-fname'); ok=false; }
  if(!document.getElementById('f-lname').value.trim()){ showErr('f-lname','e-lname'); ok=false; }
  const email=document.getElementById('f-email').value.trim();
  if(!email || !/\S+@\S+\.\S+/.test(email)){ showErr('f-email','e-email'); ok=false; }
  return ok;
}

function validateStep2() {
  const sel=document.querySelector('[name="f-role"]:checked');
  if(!sel){ document.getElementById('e-role').classList.add('show'); return false; }
  return true;
}

function showErr(fieldId, errId) {
  document.getElementById(fieldId).classList.add('error');
  document.getElementById(errId).classList.add('show');
}

function clearErr(errId) {
  const el=document.getElementById(errId);
  if(el) el.classList.remove('show');
  const fid=errId.replace('e-','f-');
  const f=document.getElementById(fid);
  if(f) f.classList.remove('error');
}

// Role option selection
document.querySelectorAll('.role-opt').forEach(opt=>{
  opt.addEventListener('click',()=>{
    document.querySelectorAll('.role-opt').forEach(o=>o.classList.remove('selected'));
    opt.classList.add('selected');
    document.getElementById('e-role').classList.remove('show');
    const role = opt.querySelector('input').value;
    const perms = rolePerms[role]||[];
    const prev = document.getElementById('role-perm-preview');
    const list = document.getElementById('role-perm-list');
    list.innerHTML = perms.map(p=>`<span style="background:#fff;border:1px solid var(--border);border-radius:50px;padding:3px 10px;font-size:.73rem;font-weight:600;color:var(--text);">${p}</span>`).join('');
    prev.style.display='block';
  });
});

// Password strength
function checkPwd() {
  const pwd=document.getElementById('f-pwd').value;
  updatePwStrength(pwd,'pw-bar','pw-hint');
}
function checkRpPwd() {
  const pwd=document.getElementById('rp-pwd').value;
  updatePwStrength(pwd,'rp-bar','rp-hint');
}
function updatePwStrength(pwd, barId, hintId) {
  let score=0;
  if(pwd.length>=8) score++;
  if(/[A-Z]/.test(pwd)) score++;
  if(/[0-9]/.test(pwd)) score++;
  if(/[^a-zA-Z0-9]/.test(pwd)) score++;
  const bar=document.getElementById(barId);
  const hint=document.getElementById(hintId);
  const colors=['#ef4444','#f59e0b','#22c55e','#0ea5e9'];
  const labels=['Too weak','Could be stronger','Good password','Strong password'];
  const pct=[25,50,75,100];
  bar.style.width = pwd.length?pct[score-1]+'%':'0';
  bar.style.background = pwd.length?colors[score-1]:'transparent';
  hint.textContent = pwd.length?labels[score-1]:'Enter a password';
  hint.style.color = pwd.length?colors[score-1]:'var(--muted)';
}

function togglePwd(fieldId, iconId) {
  const f=document.getElementById(fieldId);
  const i=document.getElementById(iconId);
  if(f.type==='password'){ f.type='text'; i.classList.replace('fa-eye','fa-eye-slash'); }
  else { f.type='password'; i.classList.replace('fa-eye-slash','fa-eye'); }
}

function submitAdmin() {
  const pwd=document.getElementById('f-pwd').value;
  const pwd2=document.getElementById('f-pwd2').value;
  if(pwd.length<8){ showErr('f-pwd','e-pwd'); return; }
  if(pwd!==pwd2){ showErr('f-pwd2','e-pwd2'); document.getElementById('e-pwd2').textContent='Passwords do not match'; return; }

  const fname=document.getElementById('f-fname').value.trim();
  const lname=document.getElementById('f-lname').value.trim();
  const email=document.getElementById('f-email').value.trim();
  const role=document.querySelector('[name="f-role"]:checked')?.value||'Viewer';
  const dept=document.getElementById('f-dept').value||'—';
  const active=document.getElementById('f-active').checked;
  const cls=role.toLowerCase().replace(' ','');

  if(!editingId) {
    // Add new row to table
    const tbody=document.getElementById('admin-tbody');
    const newId=Date.now();
    const initials=(fname[0]+(lname[0]||'')).toUpperCase();
    const tr=document.createElement('tr');
    tr.dataset.name=(fname+' '+lname).toLowerCase();
    tr.dataset.email=email.toLowerCase();
    tr.dataset.role=role;
    tr.dataset.status=active?'active':'inactive';
    tr.dataset.id=newId;
    tr.innerHTML=`
      <td><div style="display:flex;align-items:center;gap:11px;"><div class="admin-av ${cls}">${initials}</div><div><div class="admin-name">${fname} ${lname}</div><div class="admin-email">${email}</div></div></div></td>
      <td>${roleBadgeJS(role)}</td>
      <td style="font-size:.82rem;color:var(--muted);">${dept}</td>
      <td>${statusBadgeJS(active?'active':'inactive')}</td>
      <td style="font-size:.78rem;color:var(--muted);">Just now</td>
      <td><div style="display:flex;gap:5px;"><button class="act-btn" onclick="viewAdmin(${newId})"><i class="fas fa-eye"></i></button><button class="act-btn" onclick="editAdmin(${newId})"><i class="fas fa-pen"></i></button><button class="act-btn" onclick="resetPwd(${newId})"><i class="fas fa-key"></i></button><button class="act-btn danger" onclick="confirmDelete(${newId},'${fname} ${lname}')"><i class="fas fa-trash"></i></button></div></td>`;
    tbody.appendChild(tr);

    // Store data for view
    window._adminData = window._adminData || {};
    window._adminData[newId] = {id:newId,name:fname+' '+lname,email,role,dept,status:active?'active':'inactive',phone:document.getElementById('f-phone').value,last_login:'—',avatar:initials};

    updateStatCounts();
    showToast(`Admin account for ${fname} ${lname} created successfully!`);
  }

  closeModal('addAdminModal');
}

function roleBadgeJS(role) {
  const map={'Super Admin':['#ede9fe','#6d28d9'],'Admin':['#dbeafe','#1d4ed8'],'Editor':['#fef3c7','#b45309'],'Viewer':['#f3f4f6','#374151']};
  const c=map[role]||map['Viewer'];
  return `<span style="background:${c[0]};color:${c[1]};padding:3px 11px;border-radius:50px;font-size:.73rem;font-weight:700;">${role}</span>`;
}

function statusBadgeJS(s) {
  const map={active:['#dcfce7','#15803d','#22c55e'],inactive:['#f3f4f6','#374151','#9ca3af']};
  const c=map[s]||map.inactive;
  return `<span style="background:${c[0]};color:${c[1]};padding:3px 10px;border-radius:50px;font-size:.73rem;font-weight:700;display:inline-flex;align-items:center;gap:5px;"><span style="width:7px;height:7px;border-radius:50%;background:${c[2]};display:inline-block;"></span>${s.charAt(0).toUpperCase()+s.slice(1)}</span>`;
}

function updateStatCounts() {
  const rows=[...document.querySelectorAll('#admin-tbody tr[data-id]')];
  document.getElementById('count-total').textContent=rows.length;
  document.getElementById('count-active').textContent=rows.filter(r=>r.dataset.status==='active').length;
  document.getElementById('count-inactive').textContent=rows.filter(r=>r.dataset.status==='inactive').length;
  const showingEl = document.getElementById('showing-count');
  const totalEl = document.getElementById('total-count');
  if (showingEl) showingEl.textContent = rows.length;
  if (totalEl) totalEl.textContent = rows.length;
  // Update per-role counts in the Roles & Permissions sidebar
  document.querySelectorAll('.role-card[data-role]').forEach(card => {
    const role = card.dataset.role;
    const cnt = rows.filter(r => r.dataset.role === role).length;
    const countEl = card.querySelector('.role-count');
    if (countEl) countEl.textContent = `${cnt} user${cnt!==1?'s':''}`;
  });
}

// ── View profile ──
window._adminData = {};

async function umLoadAdmins() {
  const tbody = document.getElementById('admin-tbody');
  if (!tbody) return;
  try {
    const fd = new FormData();
    fd.append('action', 'list_admins');
    const r = await fetch('signin.php', {method:'POST', body:fd});
    const data = await r.json();
    if (!data.success) throw new Error(data.message || 'Failed to load admins');

    const admins = data.admins || [];
    window._adminData = {};
    admins.forEach(u => { window._adminData[u.id] = u; });

    if (!admins.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px;">No admin accounts yet.</td></tr>';
    } else {
      tbody.innerHTML = admins.map(u => {
        const cls = (u.role||'').toLowerCase().replace(/\s+/g,'');
        const ini = u.avatar || ((u.name||'').split(' ').map(s=>s[0]||'').join('').slice(0,2).toUpperCase());
        const safeName = (u.name||'').replace(/"/g,'&quot;');
        return `<tr data-name="${(u.name||'').toLowerCase()}" data-email="${(u.email||'').toLowerCase()}" data-role="${u.role}" data-status="${u.status}" data-id="${u.id}">
          <td><div style="display:flex;align-items:center;gap:11px;">
            <div class="admin-av ${cls}">${ini}</div>
            <div><div class="admin-name">${safeName}</div><div class="admin-email">${u.email||''}</div></div>
          </div></td>
          <td>${roleBadgeJS(u.role||'Viewer')}</td>
          <td style="font-size:.82rem;color:var(--muted);">${u.dept||'—'}</td>
          <td>${statusBadgeJS(u.status||'active')}</td>
          <td style="font-size:.78rem;color:var(--muted);">${u.last_login||'—'}</td>
          <td><div style="display:flex;gap:5px;flex-wrap:nowrap;">
            <button class="act-btn" title="View Profile" onclick="viewAdmin('${u.id}')"><i class="fas fa-eye"></i></button>
            <button class="act-btn" title="Edit" onclick="editAdmin('${u.id}')"><i class="fas fa-pen"></i></button>
            <button class="act-btn" title="Reset Password" onclick="resetPwd('${u.id}')"><i class="fas fa-key"></i></button>
            <button class="act-btn danger" title="Delete" onclick="confirmDelete('${u.id}', '${safeName.replace(/'/g,"\\'")}')"><i class="fas fa-trash"></i></button>
          </div></td>
        </tr>`;
      }).join('');
    }

    updateStatCounts();
    const superCount = admins.filter(u => u.role==='Super Admin' || u.role==='Admin').length;
    const elSuper = document.getElementById('count-super');
    if (elSuper) elSuper.textContent = superCount;
    const sidebarBadge = document.getElementById('sidebar-admin-count');
    if (sidebarBadge) sidebarBadge.textContent = admins.length;
  } catch(e) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#dc2626;padding:24px;">Failed to load admins: ${e.message}</td></tr>`;
    console.error('umLoadAdmins error:', e);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('admin-tbody')) umLoadAdmins();
  if (document.getElementById('activity-log')) loadActivityLog();
});

// ── Real Activity Log from Firebase ──────────────────────────────
async function loadActivityLog() {
  const el = document.getElementById('activity-log');
  if (!el) return;
  try {
    const { initializeApp, getApps } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js');
    const { getFirestore, collection, getDocs, query, orderBy, limit } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');

    const fbConfig = {
      apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
      authDomain: "creative4-beddb.firebaseapp.com",
      projectId: "creative4-beddb",
      storageBucket: "creative4-beddb.firebasestorage.app",
      messagingSenderId: "234978805664",
      appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
    };
    const fbApp = getApps().find(a=>a.name==='activity') || initializeApp(fbConfig, 'activity');
    const db = getFirestore(fbApp);

    // Pull from activityLog collection, newest first, max 10
    const q = query(collection(db, 'activityLog'), orderBy('createdAt','desc'), limit(10));
    const snap = await getDocs(q);

    if (snap.empty) {
      el.innerHTML = '<div style="text-align:center;color:var(--muted);padding:24px;font-size:.85rem;">No activity recorded yet.</div>';
      return;
    }

    const iconMap = {
      'login':     ['fa-sign-in-alt',  '#0ea5e9'],
      'portfolio': ['fa-images',        '#22c55e'],
      'invoice':   ['fa-file-invoice',  '#f59e0b'],
      'client':    ['fa-user-edit',     '#8b5cf6'],
      'admin':     ['fa-user-shield',   '#ef4444'],
      'upload':    ['fa-cloud-upload-alt','#06b6d4'],
      'delete':    ['fa-trash',         '#ef4444'],
      'default':   ['fa-circle-dot',    '#94a3b8'],
    };

    el.innerHTML = snap.docs.map(d => {
      const a = d.data();
      const initials = (a.actor||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
      const type = (a.type||'default').toLowerCase();
      const [icon, color] = iconMap[type] || iconMap['default'];
      // Format timestamp
      let timeStr = '';
      if (a.createdAt) {
        const dt = a.createdAt.toDate ? a.createdAt.toDate() : new Date(a.createdAt);
        const now = new Date();
        const diff = Math.floor((now - dt) / 1000);
        if (diff < 60)         timeStr = 'Just now';
        else if (diff < 3600)  timeStr = Math.floor(diff/60) + 'm ago';
        else if (diff < 86400) timeStr = Math.floor(diff/3600) + 'h ago';
        else if (diff < 172800) timeStr = 'Yesterday';
        else                   timeStr = dt.toLocaleDateString('en-GB',{day:'numeric',month:'short'});
      }
      return `<div style="display:flex;align-items:center;gap:11px;padding:10px 18px;border-bottom:1px solid #f1f5f9;">
        <div style="width:34px;height:34px;border-radius:50%;background:var(--cyan-pale);color:var(--cyan-dark);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;flex-shrink:0;">${initials}</div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:.82rem;font-weight:600;color:var(--dark);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${a.description||'Activity'}</div>
          <div style="font-size:.72rem;color:var(--muted);">${timeStr}</div>
        </div>
        <i class="fas ${icon}" style="color:${color};font-size:.82rem;flex-shrink:0;"></i>
      </div>`;
    }).join('');

  } catch(e) {
    // If activityLog collection doesn't exist yet, just show empty state
    el.innerHTML = '<div style="text-align:center;color:var(--muted);padding:24px;font-size:.85rem;">No activity recorded yet.</div>';
    console.warn('Activity log:', e.message);
  }
}

function viewAdmin(id) {
  const u=window._adminData[id];
  if(!u){ showToast('Admin data not found','danger'); return; }
  const cls=(u.role||'').toLowerCase().replace(' ','');
  document.getElementById('view-modal-body').innerHTML=`
    <div style="text-align:center;padding:10px 0 20px;">
      <div class="admin-av ${cls}" style="width:64px;height:64px;font-size:1.2rem;margin:0 auto 12px;">${u.avatar||u.name.slice(0,2).toUpperCase()}</div>
      <div style="font-size:1.1rem;font-weight:700;color:var(--dark);">${u.name}</div>
      <div style="font-size:.82rem;color:var(--muted);margin-top:3px;">${u.email}</div>
      <div style="margin-top:10px;">${roleBadgeJS(u.role)} &nbsp; ${statusBadgeJS(u.status)}</div>
    </div>
    <div style="background:#f8fafc;border-radius:12px;padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div><div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Department</div><div style="font-size:.88rem;font-weight:600;margin-top:3px;">${u.dept||'—'}</div></div>
      <div><div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Phone</div><div style="font-size:.88rem;font-weight:600;margin-top:3px;">${u.phone||'—'}</div></div>
      <div><div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Last Login</div><div style="font-size:.88rem;font-weight:600;margin-top:3px;">${u.last_login||'—'}</div></div>
      <div><div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Role</div><div style="font-size:.88rem;font-weight:600;margin-top:3px;">${u.role}</div></div>
    </div>
    <div style="margin-top:14px;">
      <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:8px;">Permissions</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">${(rolePerms[u.role]||[]).map(p=>`<span style="background:var(--cyan-pale);color:var(--cyan-dark);border-radius:50px;padding:4px 12px;font-size:.75rem;font-weight:600;">${p}</span>`).join('')}</div>
    </div>`;
  openModal('viewAdminModal');
}

// ── Edit ──
function editAdmin(id) {
  const u = window._adminData[id];
  if (!u) { showToast('Admin data not found','danger'); return; }
  editingId = id;
  document.getElementById('modal-title').textContent = 'EDIT ADMIN';
  document.getElementById('btn-submit').innerHTML = '<i class="fas fa-save me-2"></i>Update Admin';
  document.getElementById('f-fname').value = u.name.split(' ')[0] || '';
  document.getElementById('f-lname').value = u.name.split(' ').slice(1).join(' ') || '';
  document.getElementById('f-email').value = u.email || '';
  document.getElementById('f-phone').value = u.phone || '';
  document.getElementById('f-dept').value = u.dept || '';
  document.querySelectorAll('[name="f-role"]').forEach(r => r.checked = false);
  document.querySelectorAll('.role-opt').forEach(o => o.classList.remove('selected'));
  const matchRole = document.querySelector(`[name="f-role"][value="${u.role}"]`);
  if (matchRole) { matchRole.checked = true; matchRole.closest('.role-opt').classList.add('selected'); }
  goStep(1);
  openModal('addAdminModal');
}

// ── Delete ──
let deleteTargetId = null;
function confirmDelete(id, name) {
  deleteTargetId=id;
  document.getElementById('del-msg').innerHTML=`This will permanently remove <strong>${name}</strong>'s admin account. This action cannot be undone.`;
  openModal('deleteModal');
}
function doDelete() {
  const row=document.querySelector(`#admin-tbody tr[data-id="${deleteTargetId}"]`);
  const name=row ? row.dataset.name : 'Admin';
  if(row){ row.style.opacity='0'; row.style.transform='translateX(20px)'; row.style.transition='all .3s'; setTimeout(()=>{ row.remove(); updateStatCounts(); },300); }
  delete window._adminData[deleteTargetId];
  closeModal('deleteModal');
  showToast(`Admin account removed successfully`,'danger');
}

// ── Reset password ──
let resetTargetId=null;
function resetPwd(id) { resetTargetId=id; openModal('resetPwdModal'); }
function doResetPwd() {
  const pwd=document.getElementById('rp-pwd').value;
  if(pwd.length<8){ showToast('Password must be at least 8 characters','danger'); return; }
  closeModal('resetPwdModal');
  showToast('Password reset successfully. Email sent to admin.','success');
}
</script>

<!-- ═══ PORTFOLIO FIREBASE JS ═══ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, updateDoc, deleteDoc, doc, getDocs, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage, ref as storageRef, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};

// CAT_NAMES and CAT_ICONS are populated dynamically from portfolioTiles
// Fallback to empty until loaded
let CAT_NAMES = {};
const CAT_ICONS = {
  'post-production-media':'fa-film','design-studio-branding':'fa-palette','events-projects-advertising':'fa-calendar-star',
  'social-media-promo':'fa-hashtag','motion-graphics':'fa-vector-square','logo-design':'fa-pen-nib',
  'backdrops-set-designs':'fa-image','vertical-video':'fa-mobile-screen','video-ads-trailers':'fa-clapperboard',
  'leaflets-booklets':'fa-book-open','signboards-banners':'fa-sign','thumbnails-web-banners':'fa-globe',
  'documentaries-reels':'fa-circle-play','business-cards':'fa-id-card','cd-dvd-printing':'fa-compact-disc',
  'audio-production':'fa-music'
};

let db, pfAllItems = [], pfSelectedType = '', pfEditingId = null, pfDeleteId = null, pfActiveCat = null;

let pfStorage = null;
try {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  pfStorage = getStorage(app);
  pfSetStatus(true);
  pfLoadAll();
  if (document.getElementById('inv_client_select') || document.getElementById('qt_client_select')) {
    loadRealClients();
  }
} catch(e) { pfSetStatus(false); }

async function loadRealClients() {
  try {
    const snap = await getDocs(collection(db, 'clients'));
    const clients = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (window.populateClientDropdowns) window.populateClientDropdowns(clients);
  } catch(e) {
    console.error('Failed to load clients:', e);
    const fallback = '<option value="">No clients found</option><option value="__manual__">Other (enter manually)</option>';
    const invSel = document.getElementById('inv_client_select');
    const qtSel  = document.getElementById('qt_client_select');
    if(invSel) invSel.innerHTML = fallback;
    if(qtSel)  qtSel.innerHTML  = fallback;
  }
}

function pfSetStatus(ok) {
  const el = document.getElementById('pf-firebase-status');
  if (!el) return;
  el.style.background = ok ? '#dcfce7' : '#fee2e2';
  el.style.color = ok ? '#15803d' : '#b91c1c';
  el.innerHTML = `<i class="fas fa-circle" style="font-size:.5rem;margin-right:4px;"></i>${ok ? 'Firebase Connected' : 'Connection Error'}`;
}

async function pfLoadAll() {
  try {
    // Load portfolio tiles first to populate CAT_NAMES dynamically
    const tilesSnap = await getDocs(query(collection(db,'portfolioTiles'), orderBy('order','asc')));
    CAT_NAMES = {};
    tilesSnap.docs.forEach(d => {
      const t = d.data();
      if (t.slug && t.name) CAT_NAMES[t.slug] = t.name;
    });
    // Populate category dropdown in add/edit modal
    pfPopulateCatSelect();

    const snap = await getDocs(query(collection(db,'portfolio_items'), orderBy('createdAt','desc')));
    pfAllItems = snap.docs.map(d => ({id:d.id,...d.data()}));
    pfBuildCatTiles();
    pfRenderTable(pfAllItems);
  } catch(e) { console.error('pfLoadAll error:',e); }
}

function pfPopulateCatSelect() {
  const sel = document.getElementById('pf-f-cat');
  if (!sel) return;
  sel.innerHTML = '<option value="">Select category…</option>' +
    Object.entries(CAT_NAMES).map(([slug, name]) =>
      `<option value="${slug}">${name}</option>`
    ).join('');
}

function pfBuildCatTiles() {
  const grid = document.getElementById('pf-cat-grid');
  if (!grid) return;
  const counts = {};
  pfAllItems.forEach(i => { counts[i.category] = (counts[i.category]||0)+1; });

  // "All" tile
  let html = `<div onclick="pfSelectCat(null,this)" id="pf-tile-all"
    style="border:2px solid var(--cyan);background:var(--cyan-pale);border-radius:10px;padding:12px;cursor:pointer;transition:all .2s;">
    <div style="width:36px;height:36px;border-radius:8px;background:var(--cyan-pale);color:var(--cyan-dark);display:flex;align-items:center;justify-content:center;margin-bottom:8px;"><i class="fas fa-th-large"></i></div>
    <div style="font-weight:700;font-size:.82rem;color:var(--dark);">All Categories</div>
    <div style="font-size:.72rem;color:var(--muted);">${pfAllItems.length} items total</div>
  </div>`;

  Object.entries(CAT_NAMES).forEach(([id,name]) => {
    const cnt = counts[id]||0;
    const icon = CAT_ICONS[id]||'fa-folder';
    html += `<div onclick="pfSelectCat('${id}',this)" id="pf-tile-${id}"
      style="border:2px solid var(--border);border-radius:10px;padding:12px;cursor:pointer;transition:all .2s;position:relative;">
      ${cnt>0?`<div style="position:absolute;top:8px;right:8px;background:var(--cyan);color:#fff;font-size:.62rem;font-weight:700;padding:1px 8px;border-radius:20px;">${cnt}</div>`:''}
      <div style="width:36px;height:36px;border-radius:8px;background:var(--cyan-pale);color:var(--cyan-dark);display:flex;align-items:center;justify-content:center;margin-bottom:8px;"><i class="fas ${icon}"></i></div>
      <div style="font-weight:700;font-size:.78rem;color:var(--dark);line-height:1.3;margin-bottom:2px;">${name}</div>
      <div style="font-size:.7rem;color:var(--muted);">${cnt} item${cnt!==1?'s':''}</div>
    </div>`;
  });
  grid.innerHTML = html;
  document.getElementById('pf-total').textContent = pfAllItems.length;
}

window.pfSelectCat = function(catId, tile) {
  pfActiveCat = catId;
  document.querySelectorAll('[id^="pf-tile-"]').forEach(t => {
    t.style.border = '2px solid var(--border)'; t.style.background = '';
  });
  tile.style.border = '2px solid var(--cyan)'; tile.style.background = 'var(--cyan-pale)';
  document.getElementById('pf-table-heading').textContent = catId ? (CAT_NAMES[catId] || catId) : 'All Portfolio Items';
  if (catId) document.getElementById('pf-f-cat').value = catId;
  pfFilter();
}

window.pfFilter = function() {
  const q = (document.getElementById('pf-search')?.value||'').toLowerCase();
  const type = document.getElementById('pf-type-f')?.value||'';
  const pub = document.getElementById('pf-pub-f')?.value||'';
  const filtered = pfAllItems.filter(i => {
    return (!pfActiveCat || i.category===pfActiveCat)
      && (!type || i.type===type)
      && (pub==='' || String(i.published)===pub)
      && (!q || (i.title||'').toLowerCase().includes(q) || (i.client||'').toLowerCase().includes(q));
  });
  pfRenderTable(filtered);
}

function pfRenderTable(items) {
  const tbody = document.getElementById('pf-tbody');
  if (!tbody) return;
  document.getElementById('pf-showing').textContent = items.length;
  if (!items.length) {
    tbody.innerHTML='<tr><td colspan="6" style="text-align:center;padding:36px;color:var(--muted);">No items found</td></tr>';
    return;
  }
  tbody.innerHTML = items.map(item => {
    const thumb = item.type==='album'?(item.photos?.[0]||''):(item.thumbnail||'');
    const thumbHtml = thumb
      ? `<div style="width:52px;height:38px;border-radius:6px;overflow:hidden;"><img src="${thumb}" style="width:100%;height:100%;object-fit:cover;" onerror="this.parentElement.innerHTML='<div style=\'width:52px;height:38px;border-radius:6px;background:#e0f2fe;display:flex;align-items:center;justify-content:center;color:#0284c7;\'><i class=\'fas fa-image\'></i></div>'"/></div>`
      : `<div style="width:52px;height:38px;border-radius:6px;background:#e0f2fe;display:flex;align-items:center;justify-content:center;color:#0284c7;"><i class="fas ${item.type==='video'?'fa-video':'fa-image'}"></i></div>`;
    const typeHtml = item.type==='album'
      ? `<span style="background:#dcfce7;color:#15803d;font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:20px;"><i class="fas fa-images me-1"></i>Photos</span>`
      : `<span style="background:#dbeafe;color:#1d4ed8;font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:20px;"><i class="fas fa-video me-1"></i>Video</span>`;
    const pubHtml = item.published
      ? `<span style="background:#dcfce7;color:#15803d;font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:20px;">Published</span>`
      : `<span style="background:#f3f4f6;color:#374151;font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:20px;">Draft</span>`;
    return `<tr>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;">${thumbHtml}</td>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;">
        <div style="font-weight:700;font-size:.86rem;color:var(--dark);">${item.title||'Untitled'}</div>
        <div style="font-size:.74rem;color:var(--muted);">${item.client||'—'}</div>
      </td>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;font-size:.8rem;color:var(--muted);max-width:140px;">${CAT_NAMES[item.category]||item.category||'—'}</td>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;">${typeHtml}</td>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;">${pubHtml}</td>
      <td style="padding:12px 18px;border-bottom:1px solid #f1f5f9;">
        <div style="display:flex;gap:5px;">
          <a href="portfoliocategory.html?cat=${item.category}" target="_blank" class="act-btn" title="View on site"><i class="fas fa-external-link-alt"></i></a>
          ${CAN_ADD_PORTFOLIO ? `<button class="act-btn" title="Edit" onclick="pfEditItem('${item.id}')"><i class="fas fa-pen"></i></button>` : ''}
          ${CAN_DELETE_PORTFOLIO ? `<button class="act-btn" title="Delete" style="color:var(--danger);" onclick="pfConfirmDelete('${item.id}','${(item.title||'').replace(/'/g,"\\'")}')"><i class="fas fa-trash"></i></button>` : ''}
        </div>
      </td>
    </tr>`;
  }).join('');
}

// ── ADD MODAL ──
window.pfOpenAddModal = function() {
  pfEditingId = null; pfSelectedType = '';
  document.getElementById('pf-modal-title').textContent = 'ADD PORTFOLIO ITEM';
  document.getElementById('pf-save-txt').textContent = 'Save Item';
  document.getElementById('pf-edit-id').value = '';
  ['pf-f-cat','pf-f-client','pf-f-title','pf-f-desc','pf-f-photos','pf-f-vidurl','pf-f-thumb'].forEach(id => {
    const el=document.getElementById(id); if(el) el.value='';
  });
  document.getElementById('pf-f-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('pf-f-published').checked = true;
  if(pfActiveCat) document.getElementById('pf-f-cat').value = pfActiveCat;
  document.getElementById('pf-photo-section').style.display='none';
  document.getElementById('pf-video-section').style.display='none';
  document.getElementById('pf-vid-prev-wrap').style.display='none';
  document.getElementById('pf-photo-prev').innerHTML='';
  document.getElementById('pf-upload-progress').style.display='none';
  document.getElementById('pf-progress-bar').style.width='0%';
  // Reset video drop zone
  const vidPrevVideo = document.getElementById('pf-vid-prev-video');
  if (vidPrevVideo) { vidPrevVideo.src=''; vidPrevVideo.style.display='none'; }
  const vidProg = document.getElementById('pf-video-upload-progress');
  if (vidProg) vidProg.style.display='none';
  const vidBar = document.getElementById('pf-video-progress-bar');
  if (vidBar) vidBar.style.width='0%';
  const vidFileInp = document.getElementById('pf-video-file-inp');
  if (vidFileInp) vidFileInp.value='';
  ['pf-to-album','pf-to-video'].forEach(id => document.getElementById(id).style.border='2px solid var(--border)');
  openModal('pfAddModal');
}

window.pfEditItem = function(id) {
  const item = pfAllItems.find(i=>i.id===id);
  if (!item) return;
  pfEditingId = id;
  document.getElementById('pf-modal-title').textContent = 'EDIT PORTFOLIO ITEM';
  document.getElementById('pf-save-txt').textContent = 'Update Item';
  document.getElementById('pf-edit-id').value = id;
  document.getElementById('pf-f-cat').value = item.category||'';
  document.getElementById('pf-f-client').value = item.client||'';
  document.getElementById('pf-f-title').value = item.title||'';
  document.getElementById('pf-f-desc').value = item.description||'';
  document.getElementById('pf-f-published').checked = item.published!==false;
  pfSelectType(item.type==='video'?'video':'album');
  if(item.type==='album') {
    document.getElementById('pf-f-photos').value=(item.photos||[]).join('\n');
    pfPhotoPreview();
  } else {
    document.getElementById('pf-f-vidurl').value=item.videoUrl||'';
    document.getElementById('pf-f-thumb').value=item.thumbnail||'';
    pfVideoPreview();
  }
  openModal('pfAddModal');
}

window.pfSelectType = function(type) {
  pfSelectedType = type;
  document.getElementById('pf-photo-section').style.display = type==='album'?'':'none';
  document.getElementById('pf-video-section').style.display = type==='video'?'':'none';
  document.getElementById('pf-to-album').style.border = type==='album'?'2px solid var(--cyan)':'2px solid var(--border)';
  document.getElementById('pf-to-album').style.background = type==='album'?'var(--cyan-pale)':'';
  document.getElementById('pf-to-video').style.border = type==='video'?'2px solid var(--cyan)':'2px solid var(--border)';
  document.getElementById('pf-to-video').style.background = type==='video'?'var(--cyan-pale)':'';
}

window.pfPhotoPreview = function() {
  const urls = (document.getElementById('pf-f-photos')?.value||'').split('\n').map(u=>u.trim()).filter(Boolean);
  const prev = document.getElementById('pf-photo-prev');
  if(!prev) return;
  prev.innerHTML = urls.map((u,i)=>`
    <div style="aspect-ratio:1;border-radius:6px;overflow:hidden;background:#f1f5f9;position:relative;group">
      <img src="${u}" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'"/>
      <button onclick="pfRemovePhoto(${i})" title="Remove"
        style="position:absolute;top:3px;right:3px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.6);border:none;color:#fff;font-size:.6rem;cursor:pointer;display:flex;align-items:center;justify-content:center;">
        <i class="fas fa-times"></i>
      </button>
    </div>`).join('');
}

window.pfRemovePhoto = function(idx) {
  const ta = document.getElementById('pf-f-photos');
  const urls = (ta.value||'').split('\n').map(u=>u.trim()).filter(Boolean);
  urls.splice(idx,1);
  ta.value = urls.join('\n');
  pfPhotoPreview();
}

// ── Drag & Drop handlers ──────────────────────────────────────────
window.pfDragOver = function(e) {
  e.preventDefault();
  const z = document.getElementById('pf-drop-zone');
  z.style.borderColor = 'var(--cyan)';
  z.style.background  = '#f0fdfe';
}
window.pfDragLeave = function(e) {
  const z = document.getElementById('pf-drop-zone');
  z.style.borderColor = 'var(--border)';
  z.style.background  = '#fafafa';
}
window.pfDrop = function(e) {
  e.preventDefault();
  window.pfDragLeave(e);
  const files = e.dataTransfer.files;
  if(files.length) pfHandleFiles(files);
}

// ── Video drag & drop ────────────────────────────────────────
window.pfVideoDragOver = function(e) {
  e.preventDefault();
  const z = document.getElementById('pf-video-drop-zone');
  z.style.borderColor = 'var(--cyan)';
  z.style.background  = '#f0fdfe';
};
window.pfVideoDragLeave = function(e) {
  const z = document.getElementById('pf-video-drop-zone');
  z.style.borderColor = 'var(--border)';
  z.style.background  = '#fafafa';
};
window.pfVideoDrop = function(e) {
  e.preventDefault();
  window.pfVideoDragLeave(e);
  const files = e.dataTransfer.files;
  const video = Array.from(files).find(f => f.type.startsWith('video/'));
  if (video) pfHandleVideoFile(video);
  else showToast('Please drop a video file (MP4, MOV, WEBM)', 'danger');
};

window.pfHandleVideoFile = async function(file) {
  if (!file || !file.type.startsWith('video/')) {
    showToast('Please select a video file', 'danger');
    return;
  }

  // Show local preview immediately
  const wrap     = document.getElementById('pf-vid-prev-wrap');
  const vidEl    = document.getElementById('pf-vid-prev-video');
  const frameEl  = document.getElementById('pf-vid-prev-frame');
  if (vidEl && wrap) {
    vidEl.src = URL.createObjectURL(file);
    vidEl.style.display = '';
    frameEl.style.display = 'none';
    wrap.style.display = '';
  }

  // Upload to Cloudinary
  const prog = document.getElementById('pf-video-upload-progress');
  const bar  = document.getElementById('pf-video-progress-bar');
  const stat = document.getElementById('pf-video-upload-status');
  if (prog) prog.style.display = 'block';

  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
    formData.append('folder', 'portfolio_videos');

    const xhr = new XMLHttpRequest();
    xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/video/upload`);

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        const pct = Math.round(e.loaded / e.total * 100);
        if (bar) bar.style.width = pct + '%';
        if (stat) stat.textContent = `Uploading… ${pct}%`;
      }
    };

    xhr.onload = () => {
      const json = JSON.parse(xhr.responseText);
      if (xhr.status === 200 && json.secure_url) {
        // Set the URL field so it gets saved
        const urlField = document.getElementById('pf-f-vidurl');
        if (urlField) urlField.value = json.secure_url;
        // Update preview to use Cloudinary URL
        if (vidEl) vidEl.src = json.secure_url;
        if (stat) stat.textContent = 'Upload complete!';
        setTimeout(() => { if (prog) prog.style.display = 'none'; if (bar) bar.style.width = '0%'; }, 2500);
        showToast('Video uploaded successfully', 'success');
      } else {
        throw new Error(json.error?.message || 'Upload failed');
      }
    };

    xhr.onerror = () => { throw new Error('Network error'); };
    xhr.send(formData);

  } catch(err) {
    if (stat) stat.textContent = 'Upload failed: ' + err.message;
    showToast('Video upload failed: ' + err.message, 'danger');
    setTimeout(() => { if (prog) prog.style.display = 'none'; }, 3000);
  }
};

// ── File handler — uploads to Cloudinary ────────────────────
const CLOUDINARY_CLOUD_NAME = 'djkxcailk';
const CLOUDINARY_UPLOAD_PRESET = 'Portfolio';

window.pfHandleFiles = async function(files) {
  const imageFiles = Array.from(files).filter(f => f.type.startsWith('image/'));
  if(!imageFiles.length) { showToast('Only image files are supported','danger'); return; }

  const prog = document.getElementById('pf-upload-progress');
  const bar  = document.getElementById('pf-progress-bar');
  const stat = document.getElementById('pf-upload-status');
  prog.style.display = 'block';

  const total = imageFiles.length;
  let done = 0;
  const newUrls = [];

  for(const file of imageFiles) {
    stat.textContent = `Uploading ${done+1} of ${total}: ${file.name}`;
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
      formData.append('folder', 'portfolio');

      const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`, {
        method: 'POST',
        body: formData
      });
      const json = await res.json();
      if(!res.ok || !json.secure_url) {
        throw new Error(json.error?.message || 'Upload failed');
      }
      newUrls.push(json.secure_url);
      done++;
      bar.style.width = Math.round(done/total*100) + '%';
    } catch(err) {
      showToast('Upload failed: ' + err.message, 'danger');
      done++;
    }
  }

  // Append new URLs to textarea and refresh preview
  const ta = document.getElementById('pf-f-photos');
  const existing = (ta.value||'').split('\n').map(u=>u.trim()).filter(Boolean);
  ta.value = [...existing, ...newUrls].join('\n');
  pfPhotoPreview();

  stat.textContent = `${newUrls.length} of ${total} uploaded successfully`;
  setTimeout(() => { prog.style.display = 'none'; bar.style.width='0%'; }, 2500);
}

window.pfVideoPreview = function() {
  const url      = document.getElementById('pf-f-vidurl')?.value.trim()||'';
  const wrap     = document.getElementById('pf-vid-prev-wrap');
  const frameEl  = document.getElementById('pf-vid-prev-frame');
  const vidEl    = document.getElementById('pf-vid-prev-video');
  const yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
  const vi = url.match(/vimeo\.com\/(\d+)/);
  let embed = '';

  if (yt) {
    embed = `https://www.youtube.com/embed/${yt[1]}?rel=0`;
    const th = document.getElementById('pf-f-thumb');
    if (th && !th.value) th.value = `https://img.youtube.com/vi/${yt[1]}/maxresdefault.jpg`;
  } else if (vi) {
    embed = `https://player.vimeo.com/video/${vi[1]}`;
  }

  if (embed && wrap) {
    frameEl.src = embed; frameEl.style.display = '';
    if (vidEl) { vidEl.style.display = 'none'; vidEl.src = ''; }
    wrap.style.display = '';
  } else if (url && wrap) {
    // Direct video URL (MP4, Cloudinary, etc.)
    if (vidEl) { vidEl.src = url; vidEl.style.display = ''; }
    frameEl.style.display = 'none'; frameEl.src = '';
    wrap.style.display = '';
  } else if (wrap) {
    wrap.style.display = 'none';
    frameEl.src = '';
    if (vidEl) { vidEl.style.display = 'none'; vidEl.src = ''; }
  }
}

window.pfSaveItem = async function() {
  const cat = document.getElementById('pf-f-cat').value;
  const client = document.getElementById('pf-f-client').value.trim();
  const title = document.getElementById('pf-f-title').value.trim();
  if(!cat||!client||!title||!pfSelectedType) { showToast('Fill in all required fields','danger'); return; }

  const btn = document.getElementById('pf-save-btn');
  btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin me-1"></i>Saving…';

  const data = {
    category:cat, client, title,
    description: document.getElementById('pf-f-desc').value.trim(),
    published: document.getElementById('pf-f-published').checked,
    type: pfSelectedType,
    date: (() => {
      const d=document.getElementById('pf-f-date').value;
      return d ? new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}) : '';
    })()
  };

  if(pfSelectedType==='album') {
    data.photos = (document.getElementById('pf-f-photos').value||'').split('\n').map(u=>u.trim()).filter(Boolean);
    if(!data.photos.length) { showToast('Add at least one photo URL','danger'); btn.disabled=false; btn.innerHTML='<i class="fas fa-save me-1"></i><span id="pf-save-txt">Save Item</span>'; return; }
  } else {
    const vidUrl = document.getElementById('pf-f-vidurl').value.trim();
    if(!vidUrl) { showToast('Enter a video URL','danger'); btn.disabled=false; btn.innerHTML='<i class="fas fa-save me-1"></i><span id="pf-save-txt">Save Item</span>'; return; }
    data.videoUrl = vidUrl;
    data.thumbnail = document.getElementById('pf-f-thumb').value.trim();
  }

  try {
    if(pfEditingId) {
      await updateDoc(doc(db,'portfolio_items',pfEditingId), data);
      const idx = pfAllItems.findIndex(i=>i.id===pfEditingId);
      if(idx>=0) pfAllItems[idx]={...pfAllItems[idx],...data};
      showToast('Item updated!','success');
    } else {
      data.createdAt = serverTimestamp();
      const ref = await addDoc(collection(db,'portfolio_items'), data);
      data.id=ref.id; data.createdAt={toDate:()=>new Date()};
      pfAllItems.unshift(data);
      showToast('Portfolio item added!','success');
    }
    pfBuildCatTiles(); pfFilter(); closeModal('pfAddModal');
  } catch(e) { showToast('Firebase error: '+e.message,'danger'); }
  btn.disabled=false; btn.innerHTML='<i class="fas fa-save me-1"></i><span id="pf-save-txt">'+(pfEditingId?'Update':'Save')+' Item</span>';
}

window.pfConfirmDelete = function(id, title) {
  pfDeleteId=id;
  document.getElementById('pf-del-msg').innerHTML=`Remove <strong>"${title}"</strong> from the portfolio?`;
  openModal('pfDelModal');
}
window.pfDoDelete = async function() {
  if(!pfDeleteId) return;
  try {
    await deleteDoc(doc(db,'portfolio_items',pfDeleteId));
    pfAllItems = pfAllItems.filter(i=>i.id!==pfDeleteId);
    pfBuildCatTiles(); pfFilter(); closeModal('pfDelModal');
    showToast('Item deleted','danger');
  } catch(e) { showToast('Delete failed: '+e.message,'danger'); }
}
</script>


<!-- ══ ALL BUTTONS WIRED ══════════════════════════════════════════ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, updateDoc, deleteDoc, doc,
         getDocs, query, orderBy, serverTimestamp, setDoc }
  from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey:"AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain:"creative4-beddb.firebaseapp.com",
  projectId:"creative4-beddb",
  storageBucket:"creative4-beddb.firebasestorage.app",
  messagingSenderId:"234978805664",
  appId:"1:234978805664:web:ff19daaf53a70ed0f986c5"
};
const app = initializeApp(firebaseConfig);
const db  = getFirestore(app);

/* ══════════════════════════════════════════════════
   ABOUT US — Save to Firestore
══════════════════════════════════════════════════ */
window.saveAboutUs = async function() {
  const data = {
    companyName : document.querySelector('[value="Creative 4"]')?.value       || 'Creative 4',
    tagline     : document.querySelector('[value="The Ultimate Imagination"]')?.value || '',
    founded     : document.querySelector('[value="2015"]')?.value             || '',
    aboutText   : document.querySelector('textarea.form-control')?.value      || '',
    address     : document.querySelector('[value="Moratuwa Road, Piliyandala, Sri Lanka"]')?.value || '',
    phone       : document.querySelector('[value="(+94) 11 4 348 244"]')?.value || '',
    email       : document.querySelector('[value="info@creative4.lk"]')?.value  || '',
    website     : document.querySelector('[value="www.creative4.lk"]')?.value   || '',
    updatedAt   : serverTimestamp()
  };
  try {
    await setDoc(doc(db,'settings','aboutus'), data, {merge:true});
    showToast('About Us saved successfully!','success');
  } catch(e) { showToast('Save failed: '+e.message,'danger'); }
};

/* ══════════════════════════════════════════════════
   CLIENTS — Add/Edit/Delete/View modals
══════════════════════════════════════════════════ */
let clientEditId = null;

window.openAddClientModal = function() {
  clientEditId = null;
  document.getElementById('cl-modal-title').textContent = 'ADD NEW CLIENT';
  document.getElementById('cl-save-txt').textContent = 'Add Client';
  ['cl-name','cl-role','cl-email','cl-phone','cl-company'].forEach(id => {
    const el = document.getElementById(id); if(el) el.value = '';
  });
  document.getElementById('cl-status').value = 'active';
  openModal('clientModal');
};

window.editClient = function(name,role,email,phone,status) {
  clientEditId = email; // use email as unique key
  document.getElementById('cl-modal-title').textContent = 'EDIT CLIENT';
  document.getElementById('cl-save-txt').textContent = 'Update Client';
  document.getElementById('cl-name').value  = name;
  document.getElementById('cl-role').value  = role;
  document.getElementById('cl-email').value = email;
  document.getElementById('cl-phone').value = phone;
  document.getElementById('cl-status').value= status;
  openModal('clientModal');
};

window.viewClient = function(name,role,email,phone,status) {
  const dot = status==='active'?'#22c55e':'#9ca3af';
  document.getElementById('cl-view-body').innerHTML = `
    <div style="text-align:center;padding:10px 0 20px;">
      <div style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#0284c7,#0ea5e9);display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:700;color:#fff;margin:0 auto 12px;">${name.split(' ').map(n=>n[0]).slice(0,2).join('')}</div>
      <div style="font-size:1.1rem;font-weight:700;color:var(--dark);">${name}</div>
      <div style="font-size:.82rem;color:var(--muted);">${role}</div>
      <span style="display:inline-flex;align-items:center;gap:5px;background:${status==='active'?'#dcfce7':'#f3f4f6'};color:${status==='active'?'#15803d':'#374151'};border-radius:20px;padding:3px 12px;font-size:.73rem;font-weight:700;margin-top:8px;">
        <span style="width:7px;height:7px;border-radius:50%;background:${dot};display:inline-block;"></span>${status.charAt(0).toUpperCase()+status.slice(1)}
      </span>
    </div>
    <div style="background:#f8fafc;border-radius:10px;padding:14px 16px;display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div><div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Email</div><div style="font-size:.85rem;font-weight:600;margin-top:2px;">${email}</div></div>
      <div><div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);">Phone</div><div style="font-size:.85rem;font-weight:600;margin-top:2px;">${phone}</div></div>
    </div>`;
  openModal('clientViewModal');
};

window.deleteClient = function(name) {
  if (!confirm(`Delete client "${name}"? This cannot be undone.`)) return;
  showToast(`Client "${name}" removed`,'danger');
  // In production: await deleteDoc(doc(db,'clients',id))
};

window.saveClient = async function() {
  const name    = document.getElementById('cl-name').value.trim();
  const role    = document.getElementById('cl-role').value.trim();
  const email   = document.getElementById('cl-email').value.trim();
  const phone   = document.getElementById('cl-phone').value.trim();
  const company = document.getElementById('cl-company').value.trim();
  const status  = document.getElementById('cl-status').value;
  if (!name || !email) { showToast('Name and email are required','danger'); return; }
  const data = { name,role,email,phone,company,status,updatedAt:serverTimestamp() };
  try {
    if (clientEditId) {
      const snap = await getDocs(query(collection(db,'clients')));
      const existing = snap.docs.find(d=>d.data().email===clientEditId);
      if(existing) await updateDoc(doc(db,'clients',existing.id), data);
      showToast('Client updated!','success');
    } else {
      data.createdAt = serverTimestamp();
      await addDoc(collection(db,'clients'), data);
      showToast('Client added!','success');
    }
    closeModal('clientModal');
    setTimeout(()=>window.location.reload(), 1000);
  } catch(e) { showToast('Error: '+e.message,'danger'); }
};

/* ══════════════════════════════════════════════════
   INVOICE & QUOTATION — Save to Firestore
══════════════════════════════════════════════════ */
window.generateDoc = async function(type) {
  const isInv = type === 'invoice';
  const { blocks: tcBlocks, custom: tcCustom } = getSelectedTerms(isInv ? 'inv' : 'qt');
  const selectedConditions = tcBlocks.map(b => b.title);
  const data = isInv ? {
    type:'invoice',
    invoiceNo : document.getElementById('inv_no')?.value,
    date      : document.getElementById('inv_date')?.value,
    client    : document.getElementById('inv_client')?.value,
    email     : document.getElementById('inv_email')?.value,
    notes     : document.getElementById('inv_notes')?.value,
    discount     : parseFloat(document.getElementById('inv_discount')?.value)||0,
    discountType : document.getElementById('inv_discount_type')?.value || 'percent',
    advancePaid  : parseFloat(document.getElementById('inv_advance')?.value)||0,
    conditions   : selectedConditions,
    customConditions : tcCustom,
    items     : getLineItems('inv'),
    createdAt : serverTimestamp()
  } : {
    type:'quotation',
    quotationNo : document.getElementById('qt_no')?.value,
    validUntil  : document.getElementById('qt_valid')?.value,
    service   : document.getElementById('qt_service')?.value,
    client    : document.getElementById('qt_client')?.value,
    conditions   : selectedConditions,
    customConditions : tcCustom,
    discount     : parseFloat(document.getElementById('qt_discount')?.value)||0,
    discountType : document.getElementById('qt_discount_type')?.value || 'percent',
    items     : getLineItems('qt'),
    createdAt : serverTimestamp()
  };

  const clientName = (isInv ? document.getElementById('inv_client')?.value : document.getElementById('qt_client')?.value || '').trim();
  if (!clientName) { showToast('Please select or enter a client first', 'danger'); return; }

  try {
    const ref = await addDoc(collection(db, isInv?'invoices':'quotations'), data);
    showToast(`${isInv?'Invoice':'Quotation'} saved! ID: ${ref.id.slice(0,8)}…`, 'success');
    setTimeout(()=>window.downloadPDF(type), 400);
  } catch(e) {
    showToast(`Saved locally. Firebase: ${e.message}`, 'info');
    setTimeout(()=>window.downloadPDF(type), 400);
  }
};

function getLineItems(prefix) {
  const rows = document.querySelectorAll(`#${prefix}-items .line-item-row`);
  return Array.from(rows).map(r => ({
    desc  : r.querySelector('.item-desc')?.value||'',
    qty   : parseFloat(r.querySelector('.item-qty')?.value)||0,
    price : parseFloat(r.querySelector('.item-price')?.value)||0
  })).filter(i=>i.desc);
}

/* ══════════════════════════════════════════════════
   USER MANAGEMENT — Wire Add/Edit/Delete/Reset to signin.php
══════════════════════════════════════════════════ */

// Override submitAdmin to POST to signin.php via AdminManager
const _origSubmitAdmin = window.submitAdmin;
window.submitAdmin = async function() {
  const fname = document.getElementById('f-fname')?.value.trim();
  const lname = document.getElementById('f-lname')?.value.trim();
  const email = document.getElementById('f-email')?.value.trim();
  const phone = document.getElementById('f-phone')?.value||'';
  const dept  = document.getElementById('f-dept')?.value||'';
  const role  = document.querySelector('[name="f-role"]:checked')?.value||'Viewer';
  const pwd   = document.getElementById('f-pwd')?.value||'';
  const pwd2  = document.getElementById('f-pwd2')?.value||'';
  const active= document.getElementById('f-active')?.checked;

  if (!fname||!lname) { showToast('First and last name required','danger'); return; }
  if (!email||!/\S+@\S+\.\S+/.test(email)) { showToast('Valid email required','danger'); return; }
  if (!editingId && pwd.length < 8) { showToast('Password must be at least 8 characters','danger'); return; }
  if (!editingId && pwd !== pwd2)   { showToast('Passwords do not match','danger'); return; }

  const btn = document.getElementById('btn-submit');
  btn.disabled=true;
  btn.innerHTML='<i class="fas fa-spinner fa-spin me-2"></i>Saving…';

  const fd = new FormData();
  fd.append('action', editingId ? 'update_admin' : 'create_admin');
  fd.append('name',     fname+' '+lname);
  fd.append('username', email.split('@')[0]);
  fd.append('email',    email);
  fd.append('phone',    phone);
  fd.append('dept',     dept);
  fd.append('role',     role);
  fd.append('status',   active?'active':'inactive');
  if (!editingId) { fd.append('password', pwd); }
  if (editingId)  { fd.append('doc_id', editingId); }

  try {
    const r = await fetch('signin.php', {method:'POST',body:fd});
    const data = await r.json();
    if (data.success) {
      showToast(editingId?'Admin updated!':'Admin account created!','success');
      closeModal('addAdminModal');
      setTimeout(()=>window.location.reload(),1200);
    } else {
      showToast(data.message||'Error saving admin','danger');
    }
  } catch(e) {
    showToast('Request failed: '+e.message,'danger');
  }
  btn.disabled=false;
  btn.innerHTML='<i class="fas fa-user-plus me-2"></i>'+(editingId?'Update Admin':'Create Admin');
};

// Override doDelete to call PHP
const _origDoDelete = window.doDelete;
window.doDelete = async function() {
  if (!deleteTargetId) return;
  const fd = new FormData();
  fd.append('action', 'delete_admin');
  fd.append('doc_id', deleteTargetId);
  try {
    const r = await fetch('signin.php', {method:'POST',body:fd});
    const data = await r.json();
    if (data.success) {
      const row = document.querySelector(`#admin-tbody tr[data-id="${deleteTargetId}"]`);
      if(row){ row.style.opacity='0'; row.style.transition='opacity .3s'; setTimeout(()=>{row.remove();updateStatCounts();},300); }
      delete window._adminData[deleteTargetId];
      closeModal('deleteModal');
      showToast('Admin account removed','danger');
    } else {
      showToast(data.message||'Delete failed','danger');
    }
  } catch(e) { showToast('Request failed','danger'); }
};

// Override doResetPwd to call PHP
const _origDoResetPwd = window.doResetPwd;
window.doResetPwd = async function() {
  const pwd = document.getElementById('rp-pwd')?.value||'';
  if (pwd.length < 8) { showToast('Password must be at least 8 characters','danger'); return; }
  if (!resetTargetId) return;
  const fd = new FormData();
  fd.append('action','reset_password');
  fd.append('doc_id', resetTargetId);
  fd.append('password', pwd);
  try {
    const r = await fetch('signin.php', {method:'POST',body:fd});
    const data = await r.json();
    if (data.success) {
      closeModal('resetPwdModal');
      showToast('Password reset successfully!','success');
    } else {
      showToast(data.message||'Reset failed','danger');
    }
  } catch(e) { showToast('Request failed','danger'); }
};

/* ══════════════════════════════════════════════════
   TEAM MEMBERS modal (About Us)
══════════════════════════════════════════════════ */
window.openAddTeamModal = function() {
  document.getElementById('team-name').value='';
  document.getElementById('team-role').value='';
  openModal('teamModal');
};
window.saveTeamMember = async function() {
  const name = document.getElementById('team-name').value.trim();
  const role = document.getElementById('team-role').value.trim();
  if(!name||!role){showToast('Name and role required','danger');return;}
  try {
    await addDoc(collection(db,'team_members'),{name,role,createdAt:serverTimestamp()});
    showToast('Team member added!','success');
    closeModal('teamModal');
  } catch(e){showToast('Error: '+e.message,'danger');}
};
</script>

<!-- ══ EXTRA MODALS ════════════════════════════════════════════════ -->

<!-- CLIENT ADD/EDIT MODAL -->
<div class="modal-overlay" id="clientModal">
  <div class="modal-box" style="max-width:480px;">
    <div class="modal-header">
      <h4 id="cl-modal-title">ADD NEW CLIENT</h4>
      <button class="modal-close" onclick="closeModal('clientModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="row g-3">
        <div class="col-12">
          <label class="form-label-um">Full Name *</label>
          <input type="text" class="form-ctrl" id="cl-name" placeholder="e.g. Lewis S. Cunningham"/>
        </div>
        <div class="col-md-6">
          <label class="form-label-um">Role / Position</label>
          <input type="text" class="form-ctrl" id="cl-role" placeholder="e.g. CEO"/>
        </div>
        <div class="col-md-6">
          <label class="form-label-um">Company</label>
          <input type="text" class="form-ctrl" id="cl-company" placeholder="e.g. TechNova Corp"/>
        </div>
        <div class="col-md-6">
          <label class="form-label-um">Email *</label>
          <input type="email" class="form-ctrl" id="cl-email" placeholder="client@example.com"/>
        </div>
        <div class="col-md-6">
          <label class="form-label-um">Phone</label>
          <input type="text" class="form-ctrl" id="cl-phone" placeholder="+94 77 000 0000"/>
        </div>
        <div class="col-12">
          <label class="form-label-um">Status</label>
          <select class="form-ctrl" id="cl-status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline-cyan" onclick="closeModal('clientModal')">Cancel</button>
      <button class="btn-cyan" onclick="saveClient()"><i class="fas fa-save me-1"></i><span id="cl-save-txt">Add Client</span></button>
    </div>
  </div>
</div>

<!-- CLIENT VIEW MODAL -->
<div class="modal-overlay" id="clientViewModal">
  <div class="modal-box" style="max-width:420px;">
    <div class="modal-header">
      <h4>CLIENT PROFILE</h4>
      <button class="modal-close" onclick="closeModal('clientViewModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body" id="cl-view-body"></div>
    <div class="modal-footer">
      <button class="btn-outline-cyan" onclick="closeModal('clientViewModal')">Close</button>
    </div>
  </div>
</div>

<!-- TEAM MEMBER MODAL -->
<div class="modal-overlay" id="teamModal">
  <div class="modal-box" style="max-width:400px;">
    <div class="modal-header">
      <h4>ADD TEAM MEMBER</h4>
      <button class="modal-close" onclick="closeModal('teamModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="row g-3">
        <div class="col-12">
          <label class="form-label-um">Full Name *</label>
          <input type="text" class="form-ctrl" id="team-name" placeholder="e.g. Ashan Kumara"/>
        </div>
        <div class="col-12">
          <label class="form-label-um">Role / Title *</label>
          <input type="text" class="form-ctrl" id="team-role" placeholder="e.g. Creative Director"/>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-outline-cyan" onclick="closeModal('teamModal')">Cancel</button>
      <button class="btn-cyan" onclick="saveTeamMember()"><i class="fas fa-save me-1"></i>Add Member</button>
    </div>
  </div>
</div>

<!-- ═══ MAIN WALL JS ═══ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, doc, setDoc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};

// ── Cloudinary config (unsigned upload preset) ──
// Set your Cloudinary cloud name and an unsigned upload preset here
const CLOUDINARY_CLOUD = "djkxcailk";
const CLOUDINARY_PRESET = "MainWall";

let mwDb;
try {
  const app = initializeApp(firebaseConfig, "mainwall-app");
  mwDb = getFirestore(app);
} catch(e) { console.error("Main Wall Firebase init failed", e); }

// ══ HELPERS ══════════════════════════════════

function mwStatus(msg, ok) {
  const el = document.getElementById('mw-status-msg');
  if (!el) return;
  el.style.display = 'block';
  el.style.background = ok ? '#dcfce7' : '#fee2e2';
  el.style.color = ok ? '#15803d' : '#b91c1c';
  el.textContent = msg;
  if (ok) setTimeout(() => { el.style.display = 'none'; }, 4000);
}

async function cloudinaryUpload(file, onProgress) {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', CLOUDINARY_PRESET);
  const type = file.type.startsWith('video') ? 'video' : 'image';
  const url = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/${type}/upload`;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = e => { if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded/e.total*100)); };
    xhr.onload = () => {
      const res = JSON.parse(xhr.responseText);
      if (xhr.status === 200) resolve(res.secure_url);
      else reject(new Error(res.error?.message || 'Upload failed'));
    };
    xhr.onerror = () => reject(new Error('Network error'));
    xhr.send(fd);
  });
}

async function mwSaveToFirestore(data) {
  await setDoc(doc(mwDb, 'siteConfig', 'mainwall'), { ...data, updatedAt: new Date().toISOString() });
}

window.mwSaveTitleToggle = async function() {
  const show = document.getElementById('mw-title-toggle').checked;
  try {
    const snap = await getDoc(doc(mwDb, 'siteConfig', 'mainwall'));
    const existing = snap.exists() ? snap.data() : {};
    await setDoc(doc(mwDb, 'siteConfig', 'mainwall'), { ...existing, showTitle: show, updatedAt: new Date().toISOString() });
    const el = document.getElementById('mw-status-msg');
    if (el) { el.style.display='block'; el.style.background='#dcfce7'; el.style.color='#15803d'; el.textContent = show ? 'Hero title is now visible.' : 'Hero title is now hidden.'; setTimeout(()=>el.style.display='none',3000); }
  } catch(e) { console.error('Title toggle save failed:', e); }
};

// ══ MODE TOGGLE ══════════════════════════════

window.mwModeChange = function() {
  const sliderOn = document.getElementById('mw-slider-toggle').checked;
  const videoOn  = document.getElementById('mw-video-toggle').checked;
  // Mutually exclusive
  if (sliderOn) document.getElementById('mw-video-toggle').checked = false;
  if (videoOn)  document.getElementById('mw-slider-toggle').checked = false;
  document.getElementById('mw-slider-panel').style.display  = sliderOn ? '' : 'none';
  document.getElementById('mw-video-panel').style.display   = videoOn  ? '' : 'none';
  document.getElementById('mw-no-mode').style.display       = (!sliderOn && !videoOn) ? '' : 'none';
};

// ══ VIDEO ════════════════════════════════════

window.mwPreviewVideo = function() {
  const file = document.getElementById('mw-video-file').files[0];
  if (!file) return;
  const wrap = document.getElementById('mw-video-preview-wrap');
  const vid  = document.getElementById('mw-video-preview');
  vid.src = URL.createObjectURL(file);
  wrap.style.display = '';
  // Show upload btn, hide url-only save
  document.getElementById('mw-video-upload-btn').style.display = '';
};

window.mwSaveVideo = async function() {
  const url = document.getElementById('mw-video-url').value.trim();
  if (!url) { mwStatus('Please enter a video URL or upload a file.', false); return; }
  try {
    await mwSaveToFirestore({ mode: 'video', videoUrl: url });
    mwStatus('Video URL saved!', true);
    mwLoadCurrentConfig();
  } catch(e) { mwStatus('Error saving: ' + e.message, false); }
};

window.mwUploadAndSaveVideo = async function() {
  const file = document.getElementById('mw-video-file').files[0];
  if (!file) { mwStatus('No file selected.', false); return; }
  const progressWrap = document.getElementById('mw-video-upload-progress');
  const progressBar  = document.getElementById('mw-video-progress-bar');
  const progressLbl  = document.getElementById('mw-video-progress-label');
  progressWrap.style.display = '';
  try {
    const cloudUrl = await cloudinaryUpload(file, pct => {
      progressBar.style.width = pct + '%';
      progressLbl.textContent = `Uploading… ${pct}%`;
    });
    document.getElementById('mw-video-url').value = cloudUrl;
    progressLbl.textContent = 'Upload complete!';
    await mwSaveToFirestore({ mode: 'video', videoUrl: cloudUrl });
    mwStatus('Video uploaded to Cloudinary and saved!', true);
    mwLoadCurrentConfig();
  } catch(e) {
    mwStatus('Upload failed: ' + e.message, false);
  } finally {
    setTimeout(() => { progressWrap.style.display = 'none'; progressBar.style.width = '0%'; }, 3000);
  }
};

// ══ IMAGE SLIDER ════════════════════════════

window.mwPreviewSlides = function() {
  const files = Array.from(document.getElementById('mw-slider-files').files);
  const wrap  = document.getElementById('mw-slide-previews');
  wrap.innerHTML = '';
  files.forEach(f => {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(f);
    img.style.cssText = 'width:80px;height:60px;object-fit:cover;border-radius:5px;border:2px solid var(--border);';
    wrap.appendChild(img);
  });
};

window.mwUploadSlides = async function() {
  const files = Array.from(document.getElementById('mw-slider-files').files);
  if (!files.length) { mwStatus('Please select at least one image.', false); return; }
  const progressWrap = document.getElementById('mw-slider-upload-progress');
  const progressBar  = document.getElementById('mw-slider-progress-bar');
  const progressLbl  = document.getElementById('mw-slider-progress-label');
  progressWrap.style.display = '';
  const urls = [];
  try {
    for (let i = 0; i < files.length; i++) {
      progressLbl.textContent = `Uploading image ${i+1} of ${files.length}…`;
      const url = await cloudinaryUpload(files[i], pct => {
        const overall = Math.round(((i + pct/100) / files.length) * 100);
        progressBar.style.width = overall + '%';
      });
      urls.push(url);
    }
    progressLbl.textContent = 'All uploaded!';
    // Merge with existing slides
    let existing = [];
    try {
      const snap = await getDoc(doc(mwDb, 'siteConfig', 'mainwall'));
      if (snap.exists() && snap.data().mode === 'slider') existing = snap.data().slides || [];
    } catch {}
    const merged = [...existing, ...urls];
    await mwSaveToFirestore({ mode: 'slider', slides: merged });
    mwStatus(`${urls.length} image(s) uploaded and saved!`, true);
    document.getElementById('mw-slide-previews').innerHTML = '';
    document.getElementById('mw-slider-files').value = '';
    mwLoadCurrentConfig();
  } catch(e) {
    mwStatus('Upload failed: ' + e.message, false);
  } finally {
    setTimeout(() => { progressWrap.style.display = 'none'; progressBar.style.width = '0%'; }, 3000);
  }
};

window.mwDeleteSlide = async function(idx) {
  if (!confirm('Remove this slide?')) return;
  try {
    const snap = await getDoc(doc(mwDb, 'siteConfig', 'mainwall'));
    if (!snap.exists()) return;
    const slides = snap.data().slides || [];
    slides.splice(idx, 1);
    await mwSaveToFirestore({ mode: 'slider', slides });
    mwStatus('Slide removed.', true);
    mwLoadCurrentConfig();
  } catch(e) { mwStatus('Error: ' + e.message, false); }
};

// ══ LOAD CURRENT CONFIG ══════════════════════

async function mwLoadCurrentConfig() {
  const el = document.getElementById('mw-current-config');
  if (!el) return;
  try {
    const snap = await getDoc(doc(mwDb, 'siteConfig', 'mainwall'));
    if (!snap.exists()) {
      el.innerHTML = '<div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0;">No config saved yet.</div>';
      return;
    }
    const d = snap.data();
    // Sync title toggle
    const titleToggle = document.getElementById('mw-title-toggle');
    if (titleToggle) titleToggle.checked = d.showTitle !== false; // default true
    if (d.mode === 'video') {
      el.innerHTML = `
        <div style="font-size:.8rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.6px;margin-bottom:8px;">Mode: Video</div>
        <video src="${d.videoUrl}" muted controls style="width:100%;border-radius:6px;max-height:160px;background:#000;"></video>
        <div style="font-size:.72rem;color:var(--muted);margin-top:6px;word-break:break-all;">${d.videoUrl}</div>
        <div style="font-size:.72rem;color:var(--muted);margin-top:4px;">Updated: ${d.updatedAt?.slice(0,10)||''}</div>`;
    } else if (d.mode === 'slider') {
      const slides = d.slides || [];
      const existWrap = document.getElementById('mw-existing-slides-wrap');
      const existSlides = document.getElementById('mw-existing-slides');
      if (existWrap) existWrap.style.display = slides.length ? '' : 'none';
      if (existSlides) {
        existSlides.innerHTML = slides.map((url,i) => `
          <div style="position:relative;">
            <img src="${url}" style="width:80px;height:60px;object-fit:cover;border-radius:5px;border:2px solid var(--border);">
            <button onclick="mwDeleteSlide(${i})" title="Remove" style="position:absolute;top:-6px;right:-6px;background:#ef4444;color:#fff;border:none;border-radius:50%;width:18px;height:18px;font-size:.6rem;cursor:pointer;display:flex;align-items:center;justify-content:center;"><i class="fas fa-times"></i></button>
          </div>`).join('');
      }
      el.innerHTML = `
        <div style="font-size:.8rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.6px;margin-bottom:8px;">Mode: Image Slider</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${slides.slice(0,6).map(url=>`<img src="${url}" style="width:60px;height:45px;object-fit:cover;border-radius:4px;">`).join('')}
          ${slides.length > 6 ? `<div style="width:60px;height:45px;background:#f1f5f9;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;color:var(--muted);">+${slides.length-6}</div>` : ''}
        </div>
        <div style="font-size:.8rem;color:var(--muted);margin-top:8px;">${slides.length} slide(s) active</div>
        <div style="font-size:.72rem;color:var(--muted);margin-top:4px;">Updated: ${d.updatedAt?.slice(0,10)||''}</div>`;
      // Sync toggles
      document.getElementById('mw-slider-toggle').checked = true;
      document.getElementById('mw-slider-panel').style.display = '';
      document.getElementById('mw-no-mode').style.display = 'none';
    }
  } catch(e) {
    el.innerHTML = `<div style="color:#ef4444;font-size:.82rem;">Could not load config: ${e.message}</div>`;
  }
}

// Init on page load if we're on mainwall page
if (document.getElementById('sec-mainwall')) {
  mwLoadCurrentConfig();
}
</script>

<!-- ═══ ABOUT US JS ═══ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, updateDoc, deleteDoc, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};

const CLOUDINARY_CLOUD  = "djkxcailk";
const CLOUDINARY_PRESET = "MainWall";

let auDb;
try {
  const app = initializeApp(firebaseConfig, "aboutus-app");
  auDb = getFirestore(app);
} catch(e) { console.error("About Us Firebase init failed", e); }

if (!document.getElementById('sec-aboutus')) {
  // Not on aboutus page, skip
} else {
  auLoadAll();
}

async function auLoadAll() {
  await auLoadProfileText();
  await auLoadShowreel();
  await auLoadTeam();
}

// ══ CLOUDINARY UPLOAD ══════════════════════════════
async function auCloudinaryUpload(file, onProgress) {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', CLOUDINARY_PRESET);
  const type = file.type.startsWith('video') ? 'video' : file.type === 'application/pdf' ? 'raw' : 'image';
  // Force public access so PDFs can be downloaded without auth
  if (type === 'raw') fd.append('access_mode', 'public');
  const url = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/${type}/upload`;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = e => { if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded/e.total*100)); };
    xhr.onload = () => {
      const res = JSON.parse(xhr.responseText);
      if (xhr.status === 200) resolve(res.secure_url);
      else reject(new Error(res.error?.message || 'Upload failed'));
    };
    xhr.onerror = () => reject(new Error('Network error'));
    xhr.send(fd);
  });
}

function auStatus(msg, ok) {
  const el = document.getElementById('au-status');
  if (!el) return;
  el.style.display = 'block';
  el.style.background = ok ? '#dcfce7' : '#fee2e2';
  el.style.color = ok ? '#15803d' : '#b91c1c';
  el.textContent = msg;
  if (ok) setTimeout(() => { el.style.display = 'none'; }, 4000);
}

// ══ PROFILE TEXT ════════════════════════════════════
async function auLoadProfileText() {
  try {
    const snap = await getDoc(doc(auDb, 'siteConfig', 'aboutus'));
    if (!snap.exists()) return;
    const d = snap.data();
    if (d.text1) document.getElementById('au-text1').value = d.text1;
    if (d.text2) document.getElementById('au-text2').value = d.text2;
    if (d.text3) document.getElementById('au-text3').value = d.text3;
    if (d.pdfUrl) document.getElementById('au-pdf-url').value = d.pdfUrl;
  } catch(e) {}
}

window.auSaveProfileText = async function() {
  try {
    const data = {
      text1: document.getElementById('au-text1').value,
      text2: document.getElementById('au-text2').value,
      text3: document.getElementById('au-text3').value,
      updatedAt: new Date().toISOString()
    };
    // preserve existing fields
    const snap = await getDoc(doc(auDb, 'siteConfig', 'aboutus'));
    const existing = snap.exists() ? snap.data() : {};
    await setDoc(doc(auDb, 'siteConfig', 'aboutus'), { ...existing, ...data });
    auStatus('Profile text saved!', true);
  } catch(e) { auStatus('Error: ' + e.message, false); }
};

// ══ PDF — Base64 saved directly to Firestore ════════
window.auUploadPDF = async function() {
  const file = document.getElementById('au-pdf-file').files[0];
  if (!file) { auStatus('Please select a PDF file.', false); return; }
  if (file.size > 750000) {
    auStatus('PDF must be under 750KB. Please compress it first.', false);
    return;
  }
  const wrap = document.getElementById('au-pdf-progress-wrap');
  const bar  = document.getElementById('au-pdf-progress-bar');
  const lbl  = document.getElementById('au-pdf-progress-label');
  wrap.style.display = '';
  bar.style.width = '20%';
  lbl.textContent = 'Reading file…';
  try {
    const base64 = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('Could not read file'));
      reader.readAsDataURL(file);
    });
    bar.style.width = '60%';
    lbl.textContent = 'Saving to Firestore…';
    const snap = await getDoc(doc(auDb, 'siteConfig', 'aboutus'));
    const existing = snap.exists() ? snap.data() : {};
    await setDoc(doc(auDb, 'siteConfig', 'aboutus'), {
      ...existing,
      pdfBase64: base64,
      pdfName: file.name,
      pdfUrl: null,
      updatedAt: new Date().toISOString()
    });
    bar.style.width = '100%';
    lbl.textContent = 'Saved!';
    document.getElementById('au-pdf-url').value = '✓ ' + file.name + ' saved';
    auStatus('PDF saved successfully!', true);
  } catch(e) { auStatus('Save failed: ' + e.message, false); }
  finally { setTimeout(() => { wrap.style.display='none'; bar.style.width='0%'; }, 3000); }
};

// ══ SHOWREEL ════════════════════════════════════════
async function auLoadShowreel() {
  try {
    const snap = await getDoc(doc(auDb, 'siteConfig', 'aboutus'));
    if (snap.exists() && snap.data().showreelUrl) {
      document.getElementById('au-showreel-url').value = snap.data().showreelUrl;
    }
  } catch(e) {}
}

window.auPreviewShowreel = function() {
  const file = document.getElementById('au-showreel-file').files[0];
  if (!file) return;
  const vid = document.getElementById('au-showreel-preview');
  vid.src = URL.createObjectURL(file);
  document.getElementById('au-showreel-preview-wrap').style.display = '';
};

window.auUploadShowreel = async function() {
  const file = document.getElementById('au-showreel-file').files[0];
  if (!file) { auStatus('Please select a video file.', false); return; }
  const wrap = document.getElementById('au-showreel-progress-wrap');
  const bar  = document.getElementById('au-showreel-progress-bar');
  const lbl  = document.getElementById('au-showreel-progress-label');
  wrap.style.display = '';
  try {
    const url = await auCloudinaryUpload(file, pct => { bar.style.width = pct+'%'; lbl.textContent = `Uploading… ${pct}%`; });
    document.getElementById('au-showreel-url').value = url;
    const snap = await getDoc(doc(auDb, 'siteConfig', 'aboutus'));
    const existing = snap.exists() ? snap.data() : {};
    await setDoc(doc(auDb, 'siteConfig', 'aboutus'), { ...existing, showreelUrl: url, updatedAt: new Date().toISOString() });
    auStatus('Showreel uploaded and saved!', true);
  } catch(e) { auStatus('Upload failed: ' + e.message, false); }
  finally { setTimeout(() => { wrap.style.display='none'; bar.style.width='0%'; }, 3000); }
};

// ══ TEAM MEMBERS ════════════════════════════════════
async function auLoadTeam() {
  const list = document.getElementById('au-team-list');
  if (!list) return;
  try {
    const snap = await getDocs(collection(auDb, 'team_members'));
    const members = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (!members.length) { list.innerHTML = '<div style="color:var(--muted);font-size:.85rem;text-align:center;padding:20px 0;">No team members yet.</div>'; return; }
    list.innerHTML = members.map(m => `
      <div class="client-item" id="au-member-row-${m.id}">
        <div style="width:38px;height:38px;border-radius:50%;overflow:hidden;flex-shrink:0;background:linear-gradient(135deg,var(--cyan),var(--cyan-dark));display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:1rem;color:#fff;">
          ${m.photoUrl ? `<img src="${m.photoUrl}" style="width:100%;height:100%;object-fit:cover;">` : (m.name||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}
        </div>
        <div class="client-info"><div class="name">${m.name||''}</div><div class="role">${m.role||''}</div></div>
        <div class="client-actions">
          <button class="act-btn" onclick="auEditMember('${m.id}','${(m.name||'').replace(/'/g,"\\'")}','${(m.role||'').replace(/'/g,"\\'")}','${m.photoUrl||''}')"><i class="fas fa-pen"></i></button>
          <button class="act-btn danger" onclick="auDeleteMember('${m.id}')"><i class="fas fa-trash"></i></button>
        </div>
      </div>`).join('');
  } catch(e) { list.innerHTML = `<div style="color:#ef4444;font-size:.82rem;padding:12px;">Could not load team: ${e.message}</div>`; }
}

window.auOpenAddMember = function() {
  document.getElementById('au-member-id').value = '';
  document.getElementById('au-member-name').value = '';
  document.getElementById('au-member-role').value = '';
  document.getElementById('au-member-photo').value = '';
  document.getElementById('au-photo-initials').textContent = '?';
  document.getElementById('au-photo-initials').style.display = '';
  document.getElementById('au-photo-img').style.display = 'none';
  document.getElementById('au-photo-img').src = '';
  document.getElementById('au-modal-title').textContent = 'ADD TEAM MEMBER';
  document.getElementById('auTeamModal').classList.add('show');
};

window.auEditMember = function(id, name, role, photoUrl) {
  document.getElementById('au-member-id').value = id;
  document.getElementById('au-member-name').value = name;
  document.getElementById('au-member-role').value = role;
  document.getElementById('au-modal-title').textContent = 'EDIT TEAM MEMBER';
  const initials = name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  if (photoUrl) {
    document.getElementById('au-photo-img').src = photoUrl;
    document.getElementById('au-photo-img').style.display = 'block';
    document.getElementById('au-photo-initials').style.display = 'none';
  } else {
    document.getElementById('au-photo-initials').textContent = initials || '?';
    document.getElementById('au-photo-initials').style.display = '';
    document.getElementById('au-photo-img').style.display = 'none';
  }
  document.getElementById('auTeamModal').classList.add('show');
};

window.auUpdateInitials = function() {
  const name = document.getElementById('au-member-name').value;
  const initials = name.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase() || '?';
  document.getElementById('au-photo-initials').textContent = initials;
};

window.auPreviewMemberPhoto = function() {
  const file = document.getElementById('au-member-photo').files[0];
  if (!file) return;
  const img = document.getElementById('au-photo-img');
  img.src = URL.createObjectURL(file);
  img.style.display = 'block';
  document.getElementById('au-photo-initials').style.display = 'none';
};

window.auSaveMember = async function() {
  const id    = document.getElementById('au-member-id').value;
  const name  = document.getElementById('au-member-name').value.trim();
  const role  = document.getElementById('au-member-role').value.trim();
  const file  = document.getElementById('au-member-photo').files[0];
  if (!name) { auStatus('Please enter a name.', false); return; }

  const wrap = document.getElementById('au-member-progress-wrap');
  const bar  = document.getElementById('au-member-progress-bar');
  const lbl  = document.getElementById('au-member-progress-label');

  let photoUrl = document.getElementById('au-photo-img').src || '';
  if (photoUrl.startsWith('blob:')) photoUrl = ''; // don't save blob URLs

  if (file) {
    wrap.style.display = '';
    try {
      photoUrl = await auCloudinaryUpload(file, pct => { bar.style.width=pct+'%'; lbl.textContent=`Uploading photo… ${pct}%`; });
    } catch(e) { auStatus('Photo upload failed: ' + e.message, false); wrap.style.display='none'; return; }
    wrap.style.display = 'none'; bar.style.width = '0%';
  }

  try {
    const data = { name, role, photoUrl, updatedAt: new Date().toISOString() };
    if (id) {
      await updateDoc(doc(auDb, 'team_members', id), data);
      auStatus('Member updated!', true);
    } else {
      await addDoc(collection(auDb, 'team_members'), data);
      auStatus('Member added!', true);
    }
    closeModal('auTeamModal');
    auLoadTeam();
  } catch(e) { auStatus('Error: ' + e.message, false); }
};

window.auDeleteMember = async function(id) {
  if (!confirm('Delete this team member?')) return;
  try {
    await deleteDoc(doc(auDb, 'team_members', id));
    auStatus('Member deleted.', true);
    auLoadTeam();
  } catch(e) { auStatus('Error: ' + e.message, false); }
};
</script>

<!-- ═══ CLIENT LOGOS JS ═══ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};
const CLOUDINARY_CLOUD  = "djkxcailk";
const CLOUDINARY_PRESET = "MainWall";

let db;
try {
  const app = initializeApp(firebaseConfig, "cl-oc-app");
  db = getFirestore(app);
} catch(e) { console.error(e); }

async function cloudinaryUpload(file, onProgress) {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', CLOUDINARY_PRESET);
  const url = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/image/upload`;
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = e => { if (e.lengthComputable && onProgress) onProgress(Math.round(e.loaded/e.total*100)); };
    xhr.onload = () => { const r = JSON.parse(xhr.responseText); xhr.status===200 ? resolve(r.secure_url) : reject(new Error(r.error?.message||'Upload failed')); };
    xhr.onerror = () => reject(new Error('Network error'));
    xhr.send(fd);
  });
}

// ══ CLIENT LOGOS ═════════════════════════════════════
if (document.getElementById('sec-clientlogos')) {

  function clStatus(msg, ok) {
    const el = document.getElementById('cl-status');
    if (!el) return;
    el.style.display = 'block';
    el.style.background = ok ? '#dcfce7' : '#fee2e2';
    el.style.color = ok ? '#15803d' : '#b91c1c';
    el.textContent = msg;
    if (ok) setTimeout(() => el.style.display = 'none', 4000);
  }

  window.clPreviewLogo = function() {
    const file = document.getElementById('cl-logo-file').files[0];
    if (!file) return;
    document.getElementById('cl-preview-img').src = URL.createObjectURL(file);
    document.getElementById('cl-preview-wrap').style.display = '';
  };

  window.clAddLogo = async function() {
    const name = document.getElementById('cl-name').value.trim();
    const file = document.getElementById('cl-logo-file').files[0];
    if (!name) { clStatus('Please enter a company name.', false); return; }
    if (!file) { clStatus('Please select a logo image.', false); return; }
    const wrap = document.getElementById('cl-progress-wrap');
    const bar  = document.getElementById('cl-progress-bar');
    const lbl  = document.getElementById('cl-progress-label');
    wrap.style.display = '';
    try {
      const logoUrl = await cloudinaryUpload(file, pct => { bar.style.width=pct+'%'; lbl.textContent=`Uploading… ${pct}%`; });
      await addDoc(collection(db, 'clientLogos'), { name, logoUrl, createdAt: new Date().toISOString() });
      clStatus('Logo added!', true);
      document.getElementById('cl-name').value = '';
      document.getElementById('cl-logo-file').value = '';
      document.getElementById('cl-preview-wrap').style.display = 'none';
      clLoadLogos();
    } catch(e) { clStatus('Error: ' + e.message, false); }
    finally { setTimeout(() => { wrap.style.display='none'; bar.style.width='0%'; }, 3000); }
  };

  async function clLoadLogos() {
    const grid = document.getElementById('cl-logos-grid');
    if (!grid) return;
    try {
      const snap = await getDocs(collection(db, 'clientLogos'));
      const logos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (!logos.length) { grid.innerHTML = '<div style="color:var(--muted);font-size:.85rem;padding:20px 0;">No logos added yet.</div>'; return; }
      grid.innerHTML = logos.map(l => `
        <div style="display:flex;flex-direction:column;align-items:center;gap:8px;padding:12px;border:1px solid var(--border);border-radius:8px;background:#fff;min-width:120px;max-width:140px;position:relative;">
          <button onclick="clDeleteLogo('${l.id}')" title="Remove" style="position:absolute;top:-8px;right:-8px;background:#ef4444;color:#fff;border:none;border-radius:50%;width:20px;height:20px;font-size:.6rem;cursor:pointer;display:flex;align-items:center;justify-content:center;"><i class="fas fa-times"></i></button>
          <img src="${l.logoUrl}" style="max-height:50px;max-width:110px;object-fit:contain;">
          <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);text-align:center;">${l.name}</div>
        </div>`).join('');
    } catch(e) { grid.innerHTML = `<div style="color:#ef4444;font-size:.82rem;">${e.message}</div>`; }
  }

  window.clDeleteLogo = async function(id) {
    if (!confirm('Remove this logo?')) return;
    try {
      await deleteDoc(doc(db, 'clientLogos', id));
      clStatus('Logo removed.', true);
      clLoadLogos();
    } catch(e) { clStatus('Error: ' + e.message, false); }
  };

  clLoadLogos();
}

// ══ OUR CLIENTS ══════════════════════════════════════
if (document.getElementById('sec-ourclients')) {

  function ocStatus(msg, ok) {
    const el = document.getElementById('oc-status');
    if (!el) return;
    el.style.display = 'block';
    el.style.background = ok ? '#dcfce7' : '#fee2e2';
    el.style.color = ok ? '#15803d' : '#b91c1c';
    el.textContent = msg;
    if (ok) setTimeout(() => el.style.display = 'none', 4000);
  }

  async function ocLoadClients() {
    const tbody = document.getElementById('oc-table-body');
    const count = document.getElementById('oc-count');
    if (!tbody) return;
    try {
      const snap = await getDocs(collection(db, 'clients'));
      const clients = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (count) count.textContent = `${clients.length} client${clients.length!==1?'s':''}`;
      if (!clients.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:30px;">No clients yet. Click Add Client to get started.</td></tr>';
        return;
      }
      tbody.innerHTML = clients.map(c => {
        const initials = (c.name||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
        const safe = v => (v||'').replace(/'/g,"\\'");
        return `<tr>
          <td><div style="display:flex;align-items:center;gap:10px;">
            <div class="client-av" style="width:32px;height:32px;font-size:.7rem;">${initials}</div>
            <div><div style="font-weight:600;">${c.name||''}</div><div style="font-size:.75rem;color:var(--muted);">${c.company||''}</div></div>
          </div></td>
          <td style="font-size:.82rem;color:var(--muted);">${c.company||'—'}</td>
          <td style="font-size:.82rem;color:var(--muted);">${c.email||'—'}</td>
          <td style="font-size:.82rem;color:var(--muted);">${c.phone||'—'}</td>
          <td style="font-size:.82rem;color:var(--muted);">${c.address||'—'}</td>
          <td><div style="display:flex;gap:5px;">
            <button class="act-btn" onclick="ocOpenEdit('${c.id}','${safe(c.name)}','${safe(c.email)}','${safe(c.phone)}','${safe(c.address)}','${safe(c.company)}')"><i class="fas fa-pen"></i></button>
            <button class="act-btn danger" onclick="ocDeleteClient('${c.id}')"><i class="fas fa-trash"></i></button>
          </div></td>
        </tr>`;
      }).join('');
    } catch(e) {
      tbody.innerHTML = `<tr><td colspan="6" style="color:#ef4444;padding:20px;">${e.message}</td></tr>`;
    }
  }

  window.ocOpenAdd = function() {
    document.getElementById('oc-client-id').value = '';
    document.getElementById('oc-name').value = '';
    document.getElementById('oc-email').value = '';
    document.getElementById('oc-phone').value = '';
    document.getElementById('oc-address').value = '';
    document.getElementById('oc-company').value = '';
    document.getElementById('oc-modal-title').textContent = 'ADD CLIENT';
    document.getElementById('ocModal').classList.add('show');
  };

  window.ocOpenEdit = function(id, name, email, phone, address, company) {
    document.getElementById('oc-client-id').value = id;
    document.getElementById('oc-name').value = name;
    document.getElementById('oc-email').value = email;
    document.getElementById('oc-phone').value = phone;
    document.getElementById('oc-address').value = address;
    document.getElementById('oc-company').value = company;
    document.getElementById('oc-modal-title').textContent = 'EDIT CLIENT';
    document.getElementById('ocModal').classList.add('show');
  };

  window.ocSaveClient = async function() {
    const id      = document.getElementById('oc-client-id').value;
    const name    = document.getElementById('oc-name').value.trim();
    const email   = document.getElementById('oc-email').value.trim();
    const phone   = document.getElementById('oc-phone').value.trim();
    const address = document.getElementById('oc-address').value.trim();
    const company = document.getElementById('oc-company').value.trim();
    if (!name) { ocStatus('Please enter a client name.', false); return; }
    try {
      const data = { name, email, phone, address, company, updatedAt: new Date().toISOString() };
      if (id) {
        await updateDoc(doc(db, 'clients', id), data);
        ocStatus('Client updated!', true);
      } else {
        await addDoc(collection(db, 'clients'), data);
        ocStatus('Client added!', true);
      }
      closeModal('ocModal');
      ocLoadClients();
      // Refresh invoice/quotation dropdowns if they exist
      try {
        const snap = await getDocs(collection(db, 'clients'));
        const all = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        if (window.populateClientDropdowns) window.populateClientDropdowns(all);
      } catch(_) {}
    } catch(e) { ocStatus('Error: ' + e.message, false); }
  };

  window.ocDeleteClient = async function(id) {
    if (!confirm('Delete this client?')) return;
    try {
      await deleteDoc(doc(db, 'clients', id));
      ocStatus('Client deleted.', true);
      ocLoadClients();
    } catch(e) { ocStatus('Error: ' + e.message, false); }
  };

  ocLoadClients();
}
</script>

<!-- ══ INVOICE / QUOTATION: standalone client loader ══ -->
<script type="module">
// Only runs when invoice or quotation dropdowns are present
const invSel = document.getElementById('inv_client_select');
const qtSel  = document.getElementById('qt_client_select');
if (invSel || qtSel) {
  import('https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js').then(async ({ initializeApp, getApps }) => {
    const { getFirestore, collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js');
    const cfg = {
      apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
      authDomain: "creative4-beddb.firebaseapp.com",
      projectId: "creative4-beddb",
      storageBucket: "creative4-beddb.firebasestorage.app",
      messagingSenderId: "234978805664",
      appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
    };
    const app = getApps().find(a => a.name === 'inv-client') || initializeApp(cfg, 'inv-client');
    const db  = getFirestore(app);
    try {
      const snap = await getDocs(collection(db, 'clients'));
      const clients = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (window.populateClientDropdowns) window.populateClientDropdowns(clients);
    } catch(e) {
      const fallback = '<option value="">Could not load clients</option><option value="__manual__">Other (enter manually)</option>';
      if (invSel) invSel.innerHTML = fallback;
      if (qtSel)  qtSel.innerHTML  = fallback;
      console.error('Client dropdown load failed:', e);
    }
  });
}
</script>

<!-- ══ GLOBAL: notifications, messages, live dashboard stats ══ -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, getDocs, doc, updateDoc, deleteDoc, query, orderBy, limit } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};

const gApp = initializeApp(firebaseConfig, "global-topbar-app");
const gDb  = getFirestore(gApp);

let gMessages = [];

function timeAgo(ts) {
  if (!ts) return '';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  const diffMs = Date.now() - d.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  const days = Math.floor(hrs / 24);
  if (days < 7) return days + 'd ago';
  return d.toLocaleDateString();
}

async function loadContactMessages() {
  try {
    const q = query(collection(gDb, 'contact_messages'), orderBy('createdAt', 'desc'), limit(30));
    const snap = await getDocs(q);
    gMessages = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch(e) {
    console.error('Failed to load contact messages:', e);
    gMessages = [];
  }
  renderBellPanel();
  renderEnvPanel();
  updateBadges();
  renderMessagesPage();
}

function updateBadges() {
  const unread = gMessages.filter(m => !m.read).length;
  const bellDot = document.getElementById('bellDot');
  const envDot  = document.getElementById('envDot');
  const sidebarMsg = document.getElementById('sidebar-msg-count');
  if (bellDot) bellDot.style.display = unread > 0 ? 'block' : 'none';
  if (envDot)  envDot.style.display  = unread > 0 ? 'block' : 'none';
  if (sidebarMsg) {
    sidebarMsg.style.display = unread > 0 ? 'inline-block' : 'none';
    sidebarMsg.textContent = unread;
  }
}

function renderBellPanel() {
  const body = document.getElementById('bellPanelBody');
  if (!body) return;
  const unread = gMessages.filter(m => !m.read);
  if (!unread.length) {
    body.innerHTML = '<div class="topbar-panel-empty">No new notifications</div>';
    return;
  }
  body.innerHTML = unread.slice(0, 8).map(m => `
    <div class="topbar-panel-item unread" onclick="window.location.href='?page=messages'">
      <div class="tpi-top"><span class="tpi-name">New message from ${escHtml(m.name||'Someone')}</span><span class="tpi-time">${timeAgo(m.createdAt)}</span></div>
      <div class="tpi-msg">${escHtml(m.message||'')}</div>
    </div>
  `).join('');
}

function renderEnvPanel() {
  const body = document.getElementById('envPanelBody');
  if (!body) return;
  if (!gMessages.length) {
    body.innerHTML = '<div class="topbar-panel-empty">No messages yet</div>';
    return;
  }
  body.innerHTML = gMessages.slice(0, 8).map(m => `
    <div class="topbar-panel-item ${m.read ? '' : 'unread'}" onclick="window.markMessageReadAndGo('${m.id}')">
      <div class="tpi-top"><span class="tpi-name">${escHtml(m.name||'Someone')}</span><span class="tpi-time">${timeAgo(m.createdAt)}</span></div>
      <div class="tpi-msg">${escHtml(m.message||'')}</div>
    </div>
  `).join('');
}

function escHtml(s) {
  return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

window.toggleTopbarPanel = function(which) {
  const bellPanel = document.getElementById('bellPanel');
  const envPanel  = document.getElementById('envPanel');
  if (which === 'bell') {
    envPanel.classList.remove('show');
    bellPanel.classList.toggle('show');
  } else {
    bellPanel.classList.remove('show');
    envPanel.classList.toggle('show');
  }
};

document.addEventListener('click', (e) => {
  const bellWrap = document.getElementById('bellBtn')?.closest('.icon-btn-wrap');
  const envWrap  = document.getElementById('envBtn')?.closest('.icon-btn-wrap');
  if (bellWrap && !bellWrap.contains(e.target)) document.getElementById('bellPanel')?.classList.remove('show');
  if (envWrap  && !envWrap.contains(e.target))  document.getElementById('envPanel')?.classList.remove('show');
});

window.markMessageReadAndGo = async function(id) {
  try { await updateDoc(doc(gDb, 'contact_messages', id), { read: true }); } catch(e) { console.error(e); }
  window.location.href = '?page=messages';
};

// ── Full Messages admin page ──
function renderMessagesPage() {
  const tbody = document.getElementById('msg-table-body');
  if (!tbody) return;
  if (!gMessages.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px;">No messages yet.</td></tr>';
    return;
  }
  tbody.innerHTML = gMessages.map(m => `
    <tr style="${m.read ? '' : 'background:#f0f9ff;'}">
      <td>
        <div style="font-weight:700;font-size:.85rem;">${escHtml(m.name||'—')}</div>
        <div style="font-size:.76rem;color:var(--muted);">${escHtml(m.email||'')}${m.phone ? ' · '+escHtml(m.phone) : ''}</div>
      </td>
      <td style="max-width:320px;font-size:.82rem;color:var(--dark);">${escHtml(m.message||'')}</td>
      <td style="font-size:.78rem;color:var(--muted);text-transform:capitalize;">${escHtml(m.preferredReply||'email')}</td>
      <td style="font-size:.78rem;color:var(--muted);">${timeAgo(m.createdAt)}</td>
      <td>
        <div style="display:flex;gap:5px;">
          ${m.read ? '' : `<button class="act-btn" title="Mark as read" onclick="window.gMarkRead('${m.id}')"><i class="fas fa-envelope-open"></i></button>`}
          <button class="act-btn danger" title="Delete" onclick="window.gDeleteMessage('${m.id}')"><i class="fas fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join('');
}

window.gMarkRead = async function(id) {
  try {
    await updateDoc(doc(gDb, 'contact_messages', id), { read: true });
    const m = gMessages.find(x => x.id === id);
    if (m) m.read = true;
    renderMessagesPage(); renderBellPanel(); renderEnvPanel(); updateBadges();
  } catch(e) { showToast('Failed to update: ' + e.message, 'danger'); }
};

window.gDeleteMessage = async function(id) {
  if (!confirm('Delete this message?')) return;
  try {
    await deleteDoc(doc(gDb, 'contact_messages', id));
    gMessages = gMessages.filter(x => x.id !== id);
    renderMessagesPage(); renderBellPanel(); renderEnvPanel(); updateBadges();
    showToast('Message deleted', 'success');
  } catch(e) { showToast('Failed to delete: ' + e.message, 'danger'); }
};

// ── Dashboard overview stats (only on dashboard page) ──
async function loadDashboardStats() {
  if (!document.getElementById('dash-stat-portfolio')) return;
  try {
    const [pfSnap, clientsSnap, invSnap] = await Promise.all([
      getDocs(collection(gDb, 'portfolio_items')),
      getDocs(collection(gDb, 'clients')),
      getDocs(collection(gDb, 'invoices')),
    ]);

    document.getElementById('dash-stat-portfolio').textContent = pfSnap.size;
    document.getElementById('dash-stat-clients').textContent = clientsSnap.size;
    document.getElementById('dash-stat-invoices').textContent = invSnap.size;

    // Revenue: sum each invoice's (subtotal - discount)
    let revenue = 0;
    invSnap.forEach(d => {
      const inv = d.data();
      const items = Array.isArray(inv.items) ? inv.items : [];
      const subtotal = items.reduce((s, it) => s + (Number(it.qty)||0) * (Number(it.price)||0), 0);
      const discountVal = Number(inv.discount) || 0;
      const discAmt = inv.discountType === 'fixed' ? Math.min(discountVal, subtotal) : subtotal * (discountVal/100);
      revenue += Math.max(subtotal - discAmt, 0);
    });
    const revEl = document.getElementById('dash-stat-revenue');
    if (revEl) revEl.textContent = revenue >= 1000 ? `LKR ${(revenue/1000).toFixed(1)}k` : `LKR ${revenue.toFixed(0)}`;

    // Recent projects (latest 5 portfolio items)
    const pfItems = pfSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      .sort((a,b) => (b.createdAt?.toMillis?.()||0) - (a.createdAt?.toMillis?.()||0))
      .slice(0, 5);
    const projBody = document.getElementById('dash-recent-projects');
    if (projBody) {
      projBody.innerHTML = pfItems.length ? pfItems.map(p => `
        <tr>
          <td><div class="proj-title">${escHtml(p.title||p.client||'Untitled')}</div></td>
          <td><div class="proj-dept">${escHtml(p.category||'—')}</div></td>
          <td>${p.published ? statusBadgeHtml('completed','Published') : statusBadgeHtml('pending','Draft')}</td>
          <td style="font-size:.78rem;color:var(--muted);">${escHtml(p.date||timeAgo(p.createdAt))}</td>
        </tr>
      `).join('') : '<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:20px;">No portfolio items yet.</td></tr>';
    }

    // New clients (latest 5)
    const clientItems = clientsSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      .sort((a,b) => (b.createdAt?.toMillis?.()||0) - (a.createdAt?.toMillis?.()||0))
      .slice(0, 5);
    const clientsBody = document.getElementById('dash-new-clients');
    if (clientsBody) {
      clientsBody.innerHTML = clientItems.length ? clientItems.map(c => `
        <div class="client-item">
          <div class="client-av">${escHtml(initialsJs(c.name||'?'))}</div>
          <div class="client-info"><div class="name">${escHtml(c.name||'Unnamed')}</div><div class="role">${escHtml(c.company||c.email||'')}</div></div>
        </div>
      `).join('') : '<div style="text-align:center;color:var(--muted);padding:20px;font-size:.85rem;">No clients added yet.</div>';
    }
  } catch(e) {
    console.error('Failed to load dashboard stats:', e);
  }
}

function initialsJs(name) {
  const parts = (name||'').trim().split(/\s+/);
  return ((parts[0]?.[0]||'') + (parts[1]?.[0]||'')).toUpperCase();
}

function statusBadgeHtml(kind, label) {
  const map = {
    completed: ['#dcfce7','#15803d','#22c55e'],
    pending:   ['#fee2e2','#b91c1c','#ef4444'],
  };
  const c = map[kind] || map.pending;
  return `<span style="background:${c[0]};color:${c[1]};padding:3px 10px;border-radius:50px;font-size:.73rem;font-weight:700;display:inline-flex;align-items:center;gap:5px;"><span style="width:7px;height:7px;border-radius:50%;background:${c[2]};display:inline-block;"></span>${label}</span>`;
}

loadContactMessages();
loadDashboardStats();
</script>

<!-- ═══ PORTFOLIO TILES JS ═══ -->
<script type="module">
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, updateDoc, setDoc, getDoc, orderBy, query, writeBatch } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

if (!document.getElementById('sec-portfoliotiles')) { /* skip */ } else {

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};
const CLOUDINARY_CLOUD  = "djkxcailk";
const CLOUDINARY_PRESET = "MainWall";

const ptApp = getApps().find(a=>a.name==='pt-tiles') || initializeApp(firebaseConfig,'pt-tiles');
const ptDb  = getFirestore(ptApp);

// The 16 default tiles to seed into Firebase on first load
const DEFAULT_TILES = [
  {slug:'post-production-media',     name:'Post-Production & Media',             imageUrl:'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=500&q=80',order:1},
  {slug:'design-studio-branding',    name:'Design Studio & Branding',            imageUrl:'https://images.unsplash.com/photo-1558655146-d09347e92766?w=500&q=80',order:2},
  {slug:'events-projects-advertising',name:'Events, Projects & Advertising',     imageUrl:'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=500&q=80',order:3},
  {slug:'social-media-promo',        name:'Social Media & Outreach Promotions',  imageUrl:'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=500&q=80',order:4},
  {slug:'motion-graphics',           name:'2D/3D Motion Graphics & Animations',  imageUrl:'https://images.unsplash.com/photo-1563089145-599997674d42?w=500&q=80',order:5},
  {slug:'logo-design',               name:'Logo Design & Concept Development',   imageUrl:'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=500&q=80',order:6},
  {slug:'backdrops-set-designs',     name:'Backdrops & Set Designs',             imageUrl:'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=500&q=80',order:7},
  {slug:'vertical-video',            name:'Vertical Video Content',              imageUrl:'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?w=500&q=80',order:8},
  {slug:'video-ads-trailers',        name:'Video Ads & Trailers',                imageUrl:'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&q=80',order:9},
  {slug:'leaflets-booklets',         name:'Leaflets & Booklets / Invitations',   imageUrl:'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=500&q=80',order:10},
  {slug:'signboards-banners',        name:'Sign Boards, Banners & Posters',      imageUrl:'https://images.unsplash.com/photo-1588412079929-790b9f593d8e?w=500&q=80',order:11},
  {slug:'thumbnails-web-banners',    name:'Thumbnails, Web Banners & E-Flyers',  imageUrl:'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=500&q=80',order:12},
  {slug:'documentaries-reels',       name:'Documentaries & Corporate Reels',     imageUrl:'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=500&q=80',order:13},
  {slug:'business-cards',            name:'Business Cards, Name Tags & Labels',  imageUrl:'https://images.unsplash.com/photo-1586282391129-76a6df230234?w=500&q=80',order:14},
  {slug:'cd-dvd-printing',           name:'CD / DVD Bulk Printing',              imageUrl:'https://images.unsplash.com/photo-1603732551658-5fabbafa84eb?w=500&q=80',order:15},
  {slug:'audio-production',          name:'Ringtones & Audio Production',        imageUrl:'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=500&q=80',order:16},
];

let ptDeleteId = null;
window.ptSlugManual = false;

// ── Helpers ───────────────────────────────────────────
function ptStatus(msg, ok) {
  const el = document.getElementById('pt-status');
  if (!el) return;
  el.style.display = 'block';
  el.style.background = ok ? '#dcfce7' : '#fee2e2';
  el.style.color = ok ? '#15803d' : '#b91c1c';
  el.textContent = msg;
  if (ok) setTimeout(() => el.style.display='none', 4000);
}
function ptToSlug(str) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
}

window.ptPreviewImage = function() {
  const file = document.getElementById('pt-image-file').files[0];
  if (!file) return;
  document.getElementById('pt-preview-img').src = URL.createObjectURL(file);
  document.getElementById('pt-preview-wrap').style.display = '';
};

document.getElementById('pt-name').addEventListener('input', function() {
  if (!window.ptSlugManual) document.getElementById('pt-slug').value = ptToSlug(this.value);
});

// ── Cloudinary upload ─────────────────────────────────
async function ptUploadImage(file) {
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', CLOUDINARY_PRESET);
  const wrap = document.getElementById('pt-upload-progress');
  const bar  = document.getElementById('pt-progress-bar');
  const lbl  = document.getElementById('pt-progress-label');
  wrap.style.display = '';
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/image/upload`);
    xhr.upload.onprogress = e => {
      if (e.lengthComputable) { const p=Math.round(e.loaded/e.total*100); bar.style.width=p+'%'; lbl.textContent=`Uploading… ${p}%`; }
    };
    xhr.onload = () => {
      wrap.style.display='none'; bar.style.width='0%';
      const r = JSON.parse(xhr.responseText);
      xhr.status===200 ? resolve(r.secure_url) : reject(new Error(r.error?.message||'Upload failed'));
    };
    xhr.onerror = () => { wrap.style.display='none'; reject(new Error('Network error')); };
    xhr.send(fd);
  });
}

// ── Seed default tiles if collection is empty ─────────
async function ptSeedIfEmpty() {
  const snap = await getDocs(collection(ptDb,'portfolioTiles'));
  if (snap.size > 0) return; // already seeded
  const batch = writeBatch(ptDb);
  DEFAULT_TILES.forEach(t => {
    const ref = doc(collection(ptDb,'portfolioTiles'));
    batch.set(ref, { ...t, isDefault: true, createdAt: new Date().toISOString() });
  });
  await batch.commit();
}

// ── Load all tiles ────────────────────────────────────
async function ptLoadTiles() {
  const grid  = document.getElementById('pt-tiles-grid');
  const count = document.getElementById('pt-count');

  // Remove old static section heading/grid if present
  const staticCard = document.getElementById('pt-static-grid');
  if (staticCard) staticCard.closest('.section-card')?.remove();

  try {
    await ptSeedIfEmpty();
    const snap = await getDocs(query(collection(ptDb,'portfolioTiles'), orderBy('order','asc')));
    const tiles = snap.docs.map(d => ({id:d.id,...d.data()}));
    if (count) count.textContent = tiles.length + ' tile' + (tiles.length!==1?'s':'');

    grid.innerHTML = tiles.map(t => `
      <div style="border:1px solid var(--border);border-radius:8px;overflow:hidden;background:#fff;position:relative;">
        ${t.isDefault ? '<div style="position:absolute;top:6px;left:6px;background:var(--cyan);color:#fff;font-size:.58rem;font-weight:700;padding:2px 7px;border-radius:20px;z-index:1;">DEFAULT</div>' : ''}
        <img src="${t.imageUrl}" style="width:100%;height:100px;object-fit:cover;"
             onerror="this.src='https://images.unsplash.com/photo-1558655146-d09347e92766?w=300'">
        <div style="padding:8px 10px 4px;">
          <div style="font-size:.75rem;font-weight:700;color:var(--dark);line-height:1.3;margin-bottom:2px;">${t.name}</div>
          <div style="font-size:.65rem;color:var(--muted);margin-bottom:6px;">${t.slug}</div>
        </div>
        <div style="display:flex;gap:4px;padding:0 8px 8px;">
          <button class="act-btn" style="flex:1;font-size:.68rem;" onclick="ptEditTile('${t.id}','${(t.name||'').replace(/'/g,"\\'")}','${t.slug}','${t.imageUrl}')"><i class="fas fa-pen"></i></button>
          <button class="act-btn danger" style="flex:1;font-size:.68rem;" onclick="ptDeleteTile('${t.id}')"><i class="fas fa-trash"></i></button>
        </div>
      </div>`).join('');
  } catch(e) {
    grid.innerHTML = `<div style="color:#ef4444;font-size:.82rem;grid-column:1/-1;padding:16px;">${e.message}</div>`;
  }
}

// ── Save tile (add or edit) ───────────────────────────
window.ptSaveTile = async function() {
  const name    = document.getElementById('pt-name').value.trim();
  const slug    = document.getElementById('pt-slug').value.trim() || ptToSlug(name);
  const urlInput= document.getElementById('pt-image-url').value.trim();
  const file    = document.getElementById('pt-image-file').files[0];
  const editId  = document.getElementById('pt-edit-id').value;

  if (!name) { ptStatus('Please enter a tile name.', false); return; }
  if (!slug)  { ptStatus('Please enter a URL slug.', false); return; }

  let imageUrl = urlInput;
  if (file) {
    try { imageUrl = await ptUploadImage(file); }
    catch(e) { ptStatus('Image upload failed: '+e.message, false); return; }
  }
  if (!imageUrl && !editId) { ptStatus('Please provide an image (upload or URL).', false); return; }

  try {
    if (editId) {
      const updateData = { name, slug, updatedAt: new Date().toISOString() };
      if (imageUrl) updateData.imageUrl = imageUrl;
      await updateDoc(doc(ptDb,'portfolioTiles',editId), updateData);
      ptStatus('Tile updated!', true);
    } else {
      const snap = await getDocs(collection(ptDb,'portfolioTiles'));
      await addDoc(collection(ptDb,'portfolioTiles'), {
        name, slug, imageUrl,
        isDefault: false,
        order: snap.size + 1,
        createdAt: new Date().toISOString()
      });
      ptStatus('Tile added!', true);
    }
    ptCancelEdit();
    ptLoadTiles();
  } catch(e) { ptStatus('Error: '+e.message, false); }
};

// ── Edit tile ─────────────────────────────────────────
window.ptEditTile = function(id, name, slug, imageUrl) {
  document.getElementById('pt-edit-id').value = id;
  document.getElementById('pt-name').value = name;
  document.getElementById('pt-slug').value = slug;
  document.getElementById('pt-image-url').value = imageUrl;
  document.getElementById('pt-preview-img').src = imageUrl;
  document.getElementById('pt-preview-wrap').style.display = '';
  document.getElementById('pt-form-heading').textContent = 'Edit Tile';
  document.getElementById('pt-save-label').textContent = 'Save Changes';
  document.getElementById('pt-cancel-btn').style.display = '';
  window.ptSlugManual = true;
  window.scrollTo({top:0,behavior:'smooth'});
};

// ── Cancel edit ───────────────────────────────────────
window.ptCancelEdit = function() {
  document.getElementById('pt-edit-id').value = '';
  document.getElementById('pt-name').value = '';
  document.getElementById('pt-slug').value = '';
  document.getElementById('pt-image-url').value = '';
  document.getElementById('pt-image-file').value = '';
  document.getElementById('pt-preview-wrap').style.display = 'none';
  document.getElementById('pt-form-heading').textContent = 'Add New Tile';
  document.getElementById('pt-save-label').textContent = 'Add Tile';
  document.getElementById('pt-cancel-btn').style.display = 'none';
  window.ptSlugManual = false;
};

// ── Delete tile ───────────────────────────────────────
window.ptDeleteTile = function(id) {
  ptDeleteId = id;
  document.getElementById('ptDelModal').classList.add('show');
};

window.ptConfirmDelete = async function() {
  if (!ptDeleteId) return;
  try {
    await deleteDoc(doc(ptDb,'portfolioTiles',ptDeleteId));
    closeModal('ptDelModal');
    ptStatus('Tile deleted.', true);
    ptLoadTiles();
  } catch(e) { ptStatus('Error: '+e.message, false); }
  ptDeleteId = null;
};

ptLoadTiles();
}
</script>

</body>
</html>