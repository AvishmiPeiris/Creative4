<?php
/**
 * config.php  —  Creative4 Firebase project credentials
 * Keep this file private. Never expose it publicly.
 * Add to .gitignore if using Git.
 */
define('FIREBASE_PROJECT_ID', 'creative4-beddb');
define('FIREBASE_API_KEY',    'AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g');
// ─────────────────────────────────────────────────────────────────
// To get your Web API Key:
//   Firebase Console → Project Settings → General tab
//   → "Your apps" section → Web API Key
// ─────────────────────────────────────────────────────────────────