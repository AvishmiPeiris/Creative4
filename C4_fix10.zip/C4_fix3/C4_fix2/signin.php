<?php
// ================================================================
//  signin.php  —  Creative4 Admin Auth Controller
//
//  TWO login paths:
//
//  PATH 1 — Temporary Admin Login (hardcoded)
//    Username : creative4admin
//    Password : C4@Setup2025!
//    → Only active while the Firestore 'admins' collection is empty
//    → Permanently disabled once a real admin is created
//
//  PATH 2 — Real Admin Login (Firestore 'admins' collection)
//    → Queries Firestore via REST API (no Composer needed)
//    → Verifies bcrypt password hash stored in Firestore
//    → Sets session and redirects to dashboard.php
//
//  REQUIRES:
//    - config.php         (Firebase project ID + Web API key)
//    - AdminManager.php   (Firestore REST helper)
//    Both files must be in the same folder as this file.
// ================================================================
ob_start();

ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_end_clean();
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// ── Load AdminManager ─────────────────────────────────────────────
foreach (['adminmanager.php', 'config.php'] as $f) {
    if (!file_exists(__DIR__ . "/$f")) {
        ob_end_clean();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => "$f not found in project folder."]);
        exit;
    }
}
require_once __DIR__ . '/adminmanager.php';

try {
    $manager = new AdminManager();
} catch (Throwable $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'AdminManager init failed: ' . $e->getMessage()]);
    exit;
}

// ── Input ─────────────────────────────────────────────────────────
$action   = trim($_POST['action']   ?? 'login');
// NOTE: the 'username' POST field is what the person types into the
// login form. Real admins log in with their EMAIL (that's the only
// identifier they're ever shown — there's no separate username UI),
// so for the real-admin lookup below we treat this value as an email.
$username = trim($_POST['username'] ?? '');
$password =      $_POST['password'] ?? '';

// ══════════════════════════════════════════════════════════════════
//  ACTION: create_admin
//  Called from the setup modal in session_guard.php after temp login
// ══════════════════════════════════════════════════════════════════
if ($action === 'create_admin') {

    if (empty($_SESSION['admin_role'])) {
        ob_end_clean(); http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
        exit;
    }

    $name  = trim($_POST['name']     ?? '');
    $uname = trim($_POST['username'] ?? '');
    $email = trim($_POST['email']    ?? '');
    $pwd   =      $_POST['password'] ?? '';
    $role  =      $_POST['role']     ?? 'Admin';
    $dept  = trim($_POST['dept']     ?? '');
    $phone = trim($_POST['phone']    ?? '');

    // Validate
    $errors = [];
    if (!$name)                                     $errors[] = 'Name is required.';
    if (!$uname)                                    $errors[] = 'Username is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (strlen($pwd) < 8)                           $errors[] = 'Password must be at least 8 characters.';

    if ($errors) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => implode(' ', $errors)]);
        exit;
    }

    // Duplicate username check
    try {
        if ($manager->findByUsername($uname)) {
            ob_end_clean();
            echo json_encode(['success' => false, 'message' => 'That username is already taken.']);
            exit;
        }
    } catch (Throwable $e) { /* non-fatal, continue */ }

    // Write to Firestore
    try {
        $result = $manager->createAdmin([
            'name'     => $name,
            'username' => $uname,
            'email'    => $email,
            'password' => $pwd,
            'role'     => $role,
            'dept'     => $dept,
            'phone'    => $phone,
        ]);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Firestore error: ' . $e->getMessage()]);
        exit;
    }

    if (!$result['success']) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => $result['message'] ?? 'Failed to create admin.']);
        exit;
    }

    // Upgrade temp session → real session
    if (!empty($_SESSION['is_temp'])) {
        $_SESSION['admin_id']    = $result['doc_id'];
        $_SESSION['admin_name']  = $name;
        $_SESSION['admin_email'] = $email;
        $_SESSION['admin_role']  = $role;
        $_SESSION['is_temp']     = false;
    }

    ob_end_clean();
    echo json_encode([
        'success' => true,
        'message' => 'Admin account created in Firestore. Temporary credentials are now permanently disabled.',
    ]);
    exit;
}

// ══════════════════════════════════════════════════════════════════
//  ACTION: list_admins
//  Must be BEFORE the login section (which exits if no username/pwd)
// ══════════════════════════════════════════════════════════════════
if ($action === 'list_admins') {
    if (empty($_SESSION['admin_role'])) {
        ob_end_clean(); http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Not authenticated.']);
        exit;
    }
    try {
        $result = $manager->getAllAdmins();
        ob_end_clean();
        echo json_encode($result);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Firestore error: ' . $e->getMessage()]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════════
//  ACTION: login (default)
// ══════════════════════════════════════════════════════════════════
if (!$username || !$password) {
    ob_end_clean(); http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username and password are required.']);
    exit;
}

// ── PATH 1: Temporary hardcoded credentials ───────────────────────
// Only active while the Firestore admins collection is completely empty.
define('TEMP_ADMIN_USER', 'creative4admin');
define('TEMP_ADMIN_PASS', 'C4@Setup2025!');

try {
    $hasReal = $manager->hasRealAdmins();
} catch (Throwable $e) {
    $hasReal = false; // If Firestore is unreachable, fall through to error
}

if (!$hasReal
    && $username === TEMP_ADMIN_USER
    && $password === TEMP_ADMIN_PASS)
{
    $_SESSION['admin_id']    = 0;
    $_SESSION['admin_name']  = 'Temporary Admin';
    $_SESSION['admin_email'] = '';
    $_SESSION['admin_role']  = 'Super Admin';
    $_SESSION['signed_in']   = true;
    $_SESSION['is_temp']     = true;

    ob_end_clean(); http_response_code(200);
    echo json_encode([
        'success'  => true,
        'is_temp'  => true,
        'message'  => 'Signed in with temporary credentials.',
        'redirect' => 'dashboard.php?page=usermgmt&setup=1',
    ]);
    exit;
}

// ── PATH 2: Real admin lookup in Firestore (by EMAIL) ─────────────
try {
    $admin = $manager->findByEmail($username);
} catch (Throwable $e) {
    ob_end_clean(); http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}

if ($admin
    && ($admin['status'] ?? '') === 'active'
    && !empty($admin['password_hash'])
    && password_verify($password, $admin['password_hash']))
{
    // Update last_login timestamp (non-fatal)
    try { $manager->updateLastLogin($admin['doc_id']); } catch (Throwable $e) {}

    $_SESSION['admin_id']    = $admin['doc_id'];
    $_SESSION['admin_name']  = $admin['name']  ?? '';
    $_SESSION['admin_email'] = $admin['email'] ?? '';
    $_SESSION['admin_role']  = $admin['role']  ?? 'Admin';
    $_SESSION['signed_in']   = true;
    $_SESSION['is_temp']     = false;

    ob_end_clean(); http_response_code(200);
    echo json_encode([
        'success'  => true,
        'is_temp'  => false,
        'message'  => 'Sign-in successful!',
        'redirect' => 'dashboard.php',
    ]);
    exit;
}




// ══════════════════════════════════════════════════════════════════
//  ACTION: update_admin
// ══════════════════════════════════════════════════════════════════
if ($action === 'update_admin') {
    if (empty($_SESSION['admin_role'])) {
        ob_end_clean(); http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
    $docId = trim($_POST['doc_id'] ?? '');
    if (!$docId) { ob_end_clean(); echo json_encode(['success'=>false,'message'=>'Missing doc_id.']); exit; }
    $fields = [];
    foreach (['name','email','phone','dept','role','status'] as $f) {
        if (isset($_POST[$f])) $fields[$f] = trim($_POST[$f]);
    }
    try {
        $result = $manager->updateAdmin($docId, $fields);
        ob_end_clean();
        echo json_encode($result);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════════
//  ACTION: delete_admin
// ══════════════════════════════════════════════════════════════════
if ($action === 'delete_admin') {
    if (empty($_SESSION['admin_role'])) {
        ob_end_clean(); http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
    $docId = trim($_POST['doc_id'] ?? '');
    if (!$docId) { ob_end_clean(); echo json_encode(['success'=>false,'message'=>'Missing doc_id.']); exit; }
    try {
        $result = $manager->deleteAdmin($docId);
        ob_end_clean();
        echo json_encode($result);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

// ══════════════════════════════════════════════════════════════════
//  ACTION: reset_password
// ══════════════════════════════════════════════════════════════════
if ($action === 'reset_password') {
    if (empty($_SESSION['admin_role'])) {
        ob_end_clean(); http_response_code(401);
        echo json_encode(['success'=>false,'message'=>'Not authenticated.']); exit;
    }
    $docId = trim($_POST['doc_id'] ?? '');
    $pwd   = $_POST['password'] ?? '';
    if (!$docId || strlen($pwd) < 8) {
        ob_end_clean();
        echo json_encode(['success'=>false,'message'=>'doc_id and password (min 8 chars) required.']); exit;
    }
    try {
        $hash = password_hash($pwd, PASSWORD_BCRYPT);
        $result = $manager->updateAdmin($docId, ['password_hash'=>$hash]);
        ob_end_clean();
        echo json_encode($result);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
    }
    exit;
}

// ── No match ──────────────────────────────────────────────────────
ob_end_clean(); http_response_code(401);
echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
exit;