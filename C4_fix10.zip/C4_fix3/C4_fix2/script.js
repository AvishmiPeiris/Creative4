let currentIndex = 0;
const tileWidth = 245; // tile + gap
const visibleTiles = 4;

function scrollTiles(direction) {
    const container = document.querySelector('.tiles-container');
    const totalTiles = container.children.length;
    const maxIndex = totalTiles - visibleTiles;

    currentIndex += direction;

    if (currentIndex < 0) currentIndex = 0;
    if (currentIndex > maxIndex) currentIndex = maxIndex;

    container.style.transform = `translateX(-${currentIndex * tileWidth}px)`;
}


document.addEventListener('DOMContentLoaded', function() {

    // Hamburger menu
    const hamburger = document.querySelector('.hamburger');
    const menu = document.querySelector('.menu');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            menu.classList.toggle('active');
        });
    }

    // Video fade
    const video = document.getElementById('background-video');
    const videoSection = document.querySelector('.video-section');

    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset;
        const videoHeight = videoSection.offsetHeight;

        const fadeStart = videoHeight / 2;
        let videoOpacity = 1 - (scrollTop / fadeStart);
        videoOpacity = Math.max(0, Math.min(1, videoOpacity));
        video.style.opacity = videoOpacity;
    });

    // ABOUT US OVERLAY
    const companyBtn = document.getElementById('companyBtn');
    const overlay = document.getElementById('companyOverlay');
    const closeBtn = document.querySelector('.overlay-close');

    if (companyBtn && overlay) {
        companyBtn.addEventListener('click', () => {
            overlay.style.display = 'flex';
        });
    }

    if (closeBtn && overlay) {
        closeBtn.addEventListener('click', () => {
            overlay.style.display = 'none';
        });
    }

    const teamBtn = document.getElementById('teamBtn');
const teamOverlay = document.getElementById('teamOverlay');
const teamClose = document.querySelector('.team-close');

if (teamBtn && teamOverlay) {
    teamBtn.addEventListener('click', () => {
        overlay.style.display = 'none';      // hide company overlay
        teamOverlay.style.display = 'block';
    });
}

if (teamClose && teamOverlay) {
    teamClose.addEventListener('click', () => {
        teamOverlay.style.display = 'none';
    });
}

const showreelBtn = document.getElementById('showreelBtn');
const showreelOverlay = document.getElementById('showreelOverlay');
const showreelClose = document.querySelector('.showreel-close');
const showreelVideo = document.getElementById('showreelVideo');

if (showreelBtn && showreelOverlay) {
    showreelBtn.addEventListener('click', () => {
        // hide other overlays
        overlay.style.display = 'none';
        teamOverlay.style.display = 'none';

        // show showreel
        showreelOverlay.style.display = 'block';

        // ▶️ play video ONLY after click
        showreelVideo.play();
    });
}

if (showreelClose && showreelOverlay) {
    showreelClose.addEventListener('click', () => {
        showreelVideo.pause();
        showreelVideo.currentTime = 0; // reset
        showreelOverlay.style.display = 'none';
    });
}

const clientsSection = document.getElementById('clients');
const clientsHeading = document.getElementById('clientsHeading');

window.addEventListener('scroll', () => {
    const sectionTop = clientsSection.offsetTop;
    const scrollPos = window.scrollY;

    if (scrollPos > sectionTop - 150) {
        clientsHeading.classList.add('overlay');
    } else {
        clientsHeading.classList.remove('overlay');
    }
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});


});
