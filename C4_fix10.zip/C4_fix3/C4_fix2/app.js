import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, doc, getDoc, collection, getDocs, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyA7Z0kARsZZU23YNpt-bYO1M8vVrHFol5g",
  authDomain: "creative4-beddb.firebaseapp.com",
  projectId: "creative4-beddb",
  storageBucket: "creative4-beddb.firebasestorage.app",
  messagingSenderId: "234978805664",
  appId: "1:234978805664:web:ff19daaf53a70ed0f986c5"
};

const app = initializeApp(firebaseConfig);
const db  = getFirestore(app);

// ══ MAIN WALL ══════════════════════════════════════
async function applyMainWall() {
  try {
    const snap = await getDoc(doc(db, 'siteConfig', 'mainwall'));
    if (!snap.exists()) return;
    const data = snap.data();
    const hero = document.getElementById('hero');

    // ── Hero Title visibility ──
    const titleEl = document.querySelector('.hero-title');
    if (titleEl) {
      if (data.showTitle === false) {
        titleEl.classList.remove('title-visible');
      } else {
        titleEl.classList.add('title-visible');
      }
    }

    if (data.mode === 'slider' && Array.isArray(data.slides) && data.slides.length) {
      const vid = document.getElementById('hero-video');
      if (vid) { vid.pause(); vid.removeAttribute('src'); vid.style.display = 'none'; }
      const hint = document.getElementById('hero-hint');
      if (hint) hint.style.display = 'none';
      const sliderEl = document.getElementById('hero-slider');
      const slidesEl = document.getElementById('hero-slides');
      if (!sliderEl || !slidesEl) return;
      if (hero) { hero.classList.add('slider-mode'); hero.classList.add('has-media'); }
      slidesEl.innerHTML = '';
      data.slides.forEach((url, i) => {
        const div = document.createElement('div');
        div.className = 'hero-slide' + (i === 0 ? ' active' : '');
        div.style.backgroundImage = `url(${url})`;
        slidesEl.appendChild(div);
      });
      sliderEl.style.display = '';
      let current = 0;
      const slides = slidesEl.querySelectorAll('.hero-slide');
      if (slides.length > 1) {
        setInterval(() => {
          slides[current].classList.remove('active');
          current = (current + 1) % slides.length;
          slides[current].classList.add('active');
        }, 4000);
      }
    } else if (data.mode === 'video' && data.videoUrl) {
      const vid = document.getElementById('hero-video');
      if (!vid) return;
      vid.innerHTML = '';
      const src = document.createElement('source');
      src.src  = data.videoUrl;
      src.type = 'video/mp4';
      vid.appendChild(src);
      vid.load();
      vid.play().catch(() => {});
      if (hero) { hero.classList.add('has-media'); hero.classList.add('slider-mode'); }
      const hint = document.getElementById('hero-hint');
      if (hint) hint.style.display = 'none';
    }
  } catch(e) { console.warn("Main Wall failed:", e); }
}

// ══ ABOUT US ═══════════════════════════════════════
async function applyAboutUs() {
  try {
    const snap = await getDoc(doc(db, 'siteConfig', 'aboutus'));
    if (snap.exists()) {
      const d = snap.data();
      if (d.text1) { const el = document.getElementById('au-profile-text1'); if(el) el.textContent = d.text1; }
      if (d.text2) { const el = document.getElementById('au-profile-text2'); if(el) el.textContent = d.text2; }
      if (d.text3) { const el = document.getElementById('au-profile-text3'); if(el) el.textContent = d.text3; }
      if (d.pdfBase64 || d.pdfUrl) {
        const btn = document.getElementById('au-profile-pdf-btn');
        if (btn) {
          if (d.pdfBase64) {
            btn.href = d.pdfBase64;
            btn.setAttribute('download', d.pdfName || 'Creative4-Company-Profile.pdf');
            btn.removeAttribute('target');
          } else {
            btn.href = d.pdfUrl;
            btn.target = '_blank';
          }
          btn.style.display = '';
        }
      }
      if (d.showreelUrl) {
        const vid = document.getElementById('au-showreel-video');
        const placeholder = document.getElementById('au-showreel-placeholder');
        if (vid) {
          vid.src = d.showreelUrl;
          vid.style.display = '';
          if (placeholder) placeholder.style.display = 'none';
        }
      }
    }

    const teamSnap = await getDocs(collection(db, 'team_members'));
    const members = teamSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (members.length) {
      const grid = document.getElementById('au-team-grid');
      if (grid) {
        const colors = [
          'linear-gradient(135deg,#00d4e8,#00b5c8)',
          'linear-gradient(135deg,#f97316,#e06010)',
          'linear-gradient(135deg,#6366f1,#4f46e5)',
          'linear-gradient(135deg,#22c55e,#16a34a)',
          'linear-gradient(135deg,#ec4899,#db2777)',
          'linear-gradient(135deg,#f59e0b,#d97706)'
        ];
        grid.innerHTML = members.map((m, i) => {
          const avatarContent = m.photoUrl
            ? `<img src="${m.photoUrl}" alt="${m.name||''}">`
            : `<i class="fas fa-user-tie"></i>`;
          return `<div class="team-card">
            <div class="team-avatar" style="background:${colors[i%colors.length]}">${avatarContent}</div>
            <div class="team-name">${m.name||''}</div>
            <div class="team-role">${m.role||''}</div>
          </div>`;
        }).join('');
      }
    }
  } catch(e) { console.warn("About Us load failed:", e); }
}

// ══ CLIENT LOGOS ═══════════════════════════════════
async function applyClientLogos() {
  const grid   = document.getElementById('cl-logo-grid');
  const ticker = document.getElementById('cl-ticker-track');
  if (!grid) return;
  try {
    const snap = await getDocs(collection(db, 'clientLogos'));
    const logos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (!logos.length) return;
    grid.innerHTML = logos.map(l => `
      <div class="logo-item-img">
        <img src="${l.logoUrl}" alt="${l.name}" loading="lazy">
        <span>${l.name}</span>
      </div>`).join('');
    if (ticker) {
      ticker.innerHTML = [...logos, ...logos].map(l => `<span>${l.name}</span>`).join('');
    }
  } catch(e) { console.warn("Client logos load failed:", e); }
}

applyMainWall();
applyAboutUs();
applyClientLogos();

// ══ CONTACT FORM ═══════════════════════════════════
window.submitContactForm = async function() {
  const nameEl    = document.getElementById('contact-name');
  const emailEl   = document.getElementById('contact-email');
  const phoneEl   = document.getElementById('contact-phone');
  const messageEl = document.getElementById('contact-message');
  const statusEl  = document.getElementById('contact-status');
  const btn       = document.getElementById('contact-send-btn');
  const replyEl   = document.querySelector('input[name="reply"]:checked');

  const name    = nameEl.value.trim();
  const email   = emailEl.value.trim();
  const phone   = phoneEl.value.trim();
  const message = messageEl.value.trim();
  const reply   = replyEl ? replyEl.value : 'email';

  if (!name || !message || (!email && !phone)) {
    statusEl.style.color = '#ff6b6b';
    statusEl.textContent = 'Please fill in your name, a way to reach you, and your message.';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Sending…';
  statusEl.textContent = '';

  try {
    await addDoc(collection(db, 'contact_messages'), {
      name, email, phone, message, preferredReply: reply,
      read: false,
      createdAt: serverTimestamp()
    });
    statusEl.style.color = '#4ade80';
    statusEl.textContent = "Message sent! We'll get back to you soon.";
    nameEl.value = ''; emailEl.value = ''; phoneEl.value = ''; messageEl.value = '';
  } catch(e) {
    statusEl.style.color = '#ff6b6b';
    statusEl.textContent = 'Something went wrong — please try again or email us directly.';
    console.error('Contact form error:', e);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send message';
  }
};