<?php
/**
 * session_guard.php  —  Creative4
 *
 * Include at the very top of dashboard.php:
 *   require_once __DIR__ . '/session_guard.php';
 *
 * Does three things:
 *  1. Redirects unauthenticated visitors to login.html
 *  2. Shows a setup banner when logged in via temp credentials
 *  3. Auto-opens the "Create Admin" modal on first-time setup
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Auth gate ─────────────────────────────────────────────────────
if (empty($_SESSION['admin_role'])) {
    header('Location: login.html');
    exit;
}

$isTempSession = !empty($_SESSION['is_temp']);

// ── If temp session but real admins now exist → force re-login ────
// Uses AdminManager to check Firestore directly
function tempShouldExpire(): bool {
    $cfg = __DIR__ . '/config.php';
    $mgr = __DIR__ . '/adminmanager.php';
    if (!file_exists($cfg) || !file_exists($mgr)) return false;
    try {
        require_once $mgr;
        $m = new AdminManager();
        return $m->hasRealAdmins();
    } catch (Throwable $e) {
        return false;
    }
}

if ($isTempSession && tempShouldExpire()) {
    session_destroy();
    header('Location: login.html?msg=setup_complete');
    exit;
}
?>
<?php if ($isTempSession): ?>
<!-- ══════════════════════════════════════════════════════════════
     SETUP BANNER — visible only during temp credential session
══════════════════════════════════════════════════════════════ -->
<style>
  .setup-top-banner {
    position: fixed; top: 0; left: 0; right: 0; z-index: 9999;
    background: linear-gradient(90deg, #d97706, #f59e0b, #d97706);
    background-size: 200% 100%;
    animation: bannerShimmer 3s linear infinite;
    color: #fff; font-family: 'DM Sans', sans-serif;
    font-size: .82rem; font-weight: 600;
    display: flex; align-items: center; justify-content: center;
    gap: 12px; padding: 9px 20px;
    box-shadow: 0 2px 12px rgba(217,119,6,.4);
  }
  @keyframes bannerShimmer {
    0%   { background-position: 0% 0; }
    100% { background-position: 200% 0; }
  }
  .setup-top-banner .stb-btn {
    background: #fff; color: #d97706; border: none; border-radius: 50px;
    padding: 4px 14px; font-size: .78rem; font-weight: 700;
    cursor: pointer; transition: all .2s; font-family: 'DM Sans', sans-serif;
    white-space: nowrap;
  }
  .setup-top-banner .stb-btn:hover { background: #fef3c7; }
  body { padding-top: 42px !important; }
</style>

<div class="setup-top-banner" id="setupTopBanner">
  <span><i class="fas fa-triangle-exclamation"></i></span>
  <span>
    You're logged in with <strong>temporary credentials</strong>.
    Create your permanent admin account to disable them.
  </span>
  <button class="stb-btn" onclick="openSetupModal()">
    <i class="fas fa-user-plus me-1"></i> Create Admin Now
  </button>
</div>

<!-- ── SETUP MODAL ─────────────────────────────────────────────── -->
<div id="setupModal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(4px);z-index:10000;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:20px;width:100%;max-width:460px;box-shadow:0 24px 80px rgba(0,0,0,.25);animation:setupSlide .3s cubic-bezier(.34,1.56,.64,1);">
    <style>@keyframes setupSlide{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:none}}</style>

    <div style="padding:22px 26px 18px;border-bottom:1px solid #e2e8f0;">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:1.4rem;letter-spacing:1.5px;color:#0f172a;">CREATE YOUR ADMIN ACCOUNT</div>
      <div style="font-size:.76rem;color:#64748b;margin-top:2px;">Temporary credentials will be permanently removed after this step.</div>
    </div>

    <div style="padding:22px 26px;">
      <div id="setup-error"   style="display:none;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:9px 13px;color:#b91c1c;font-size:.82rem;margin-bottom:14px;"></div>
      <div id="setup-success" style="display:none;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:9px 13px;color:#15803d;font-size:.82rem;margin-bottom:14px;"></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">

        <div style="grid-column:1/-1;">
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Full Name <span style="color:#ef4444">*</span></label>
          <input id="su-name" type="text" placeholder="e.g. Ashan Kumara"
            style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;"
            onfocus="this.style.borderColor='#0ea5e9'" onblur="this.style.borderColor='#e2e8f0'"/>
        </div>

        <div>
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Username <span style="color:#ef4444">*</span></label>
          <input id="su-username" type="text" placeholder="e.g. ashan_c4"
            style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;"
            onfocus="this.style.borderColor='#0ea5e9'" onblur="this.style.borderColor='#e2e8f0'"/>
        </div>

        <div>
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Email <span style="color:#ef4444">*</span></label>
          <input id="su-email" type="email" placeholder="you@creative4.lk"
            style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;"
            onfocus="this.style.borderColor='#0ea5e9'" onblur="this.style.borderColor='#e2e8f0'"/>
        </div>

        <div style="position:relative;">
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Password <span style="color:#ef4444">*</span></label>
          <input id="su-pwd" type="password" placeholder="Min. 8 characters" oninput="suCheckPwd()"
            style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 36px 9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;"
            onfocus="this.style.borderColor='#0ea5e9'" onblur="this.style.borderColor='#e2e8f0'"/>
          <button type="button" onclick="suTogglePw()" style="position:absolute;right:10px;bottom:9px;background:none;border:none;color:#94a3b8;cursor:pointer;font-size:.85rem;"><i class="fas fa-eye" id="su-eye"></i></button>
          <div style="height:3px;border-radius:3px;background:#e2e8f0;margin-top:5px;overflow:hidden;"><div id="su-pw-bar" style="height:100%;border-radius:3px;width:0;transition:all .4s;"></div></div>
        </div>

        <div>
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Confirm Password <span style="color:#ef4444">*</span></label>
          <input id="su-pwd2" type="password" placeholder="Repeat password"
            style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;"
            onfocus="this.style.borderColor='#0ea5e9'" onblur="this.style.borderColor='#e2e8f0'"/>
        </div>

        <div style="grid-column:1/-1;">
          <label style="font-size:.73rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#64748b;display:block;margin-bottom:4px;">Role</label>
          <select id="su-role" style="width:100%;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:.87rem;outline:none;">
            <option value="Super Admin" selected>Super Admin</option>
            <option value="Admin">Admin</option>
          </select>
        </div>

      </div>

      <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px 13px;margin-top:14px;font-size:.78rem;color:#78350f;display:flex;gap:8px;align-items:flex-start;">
        <i class="fas fa-lock" style="margin-top:1px;color:#d97706;flex-shrink:0;"></i>
        <span>After saving, <strong>creative4admin / C4@Setup2025!</strong> will be <strong>permanently deactivated</strong>.</span>
      </div>
    </div>

    <div style="padding:14px 26px 22px;display:flex;justify-content:flex-end;gap:10px;border-top:1px solid #e2e8f0;">
      <button onclick="document.getElementById('setupModal').style.display='none'"
        style="border:1.5px solid #e2e8f0;background:#fff;border-radius:8px;padding:9px 20px;font-weight:700;font-size:.86rem;font-family:'DM Sans',sans-serif;cursor:pointer;color:#64748b;">
        Later
      </button>
      <button onclick="submitSetup()" id="su-submit"
        style="background:linear-gradient(135deg,#0284c7,#0ea5e9);color:#fff;border:none;border-radius:8px;padding:10px 24px;font-weight:700;font-size:.86rem;font-family:'DM Sans',sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(14,165,233,.35);">
        <i class="fas fa-user-shield me-2"></i>Create & Activate
      </button>
    </div>
  </div>
</div>

<script>
  function openSetupModal() {
    document.getElementById('setupModal').style.display = 'flex';
  }
  function suTogglePw() {
    const f = document.getElementById('su-pwd');
    const i = document.getElementById('su-eye');
    f.type = f.type === 'password' ? 'text' : 'password';
    i.className = f.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
  }
  function suCheckPwd() {
    const v = document.getElementById('su-pwd').value;
    let s = 0;
    if (v.length >= 8) s++;
    if (/[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^a-zA-Z0-9]/.test(v)) s++;
    const colors = ['#ef4444','#f59e0b','#22c55e','#0ea5e9'];
    const widths = ['25%','50%','75%','100%'];
    const bar = document.getElementById('su-pw-bar');
    bar.style.width      = v.length ? (widths[s-1]||'10%') : '0';
    bar.style.background = v.length ? (colors[s-1]||'#ef4444') : '';
  }
  function submitSetup() {
    const name  = document.getElementById('su-name').value.trim();
    const uname = document.getElementById('su-username').value.trim();
    const email = document.getElementById('su-email').value.trim();
    const pwd   = document.getElementById('su-pwd').value;
    const pwd2  = document.getElementById('su-pwd2').value;
    const role  = document.getElementById('su-role').value;
    const errEl = document.getElementById('setup-error');
    const sucEl = document.getElementById('setup-success');
    errEl.style.display = 'none';
    sucEl.style.display = 'none';

    if (!name || !uname || !email || pwd.length < 8) {
      errEl.textContent = 'Please fill in all required fields (password min. 8 characters).';
      errEl.style.display = 'block'; return;
    }
    if (pwd !== pwd2) {
      errEl.textContent = 'Passwords do not match.';
      errEl.style.display = 'block'; return;
    }

    const btn = document.getElementById('su-submit');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creating…';

    const fd = new FormData();
    fd.append('action',   'create_admin');
    fd.append('name',     name);
    fd.append('username', uname);
    fd.append('email',    email);
    fd.append('password', pwd);
    fd.append('role',     role);

    // Posts to signin.php (not auth.php)
    fetch('signin.php', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(data => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-user-shield me-2"></i>Create & Activate';
        if (data.success) {
          sucEl.innerHTML = '✅ Admin account created in Firestore! Temporary credentials are now disabled. Redirecting…';
          sucEl.style.display = 'block';
          document.getElementById('setupTopBanner').style.display = 'none';
          setTimeout(() => { window.location.href = 'login.html'; }, 2200);
        } else {
          errEl.textContent = data.message || 'Something went wrong.';
          errEl.style.display = 'block';
        }
      })
      .catch(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-user-shield me-2"></i>Create & Activate';
        errEl.textContent = 'Server error. Please try again.';
        errEl.style.display = 'block';
      });
  }

  // Auto-open if redirected with ?setup=1
  if (new URLSearchParams(window.location.search).get('setup') === '1') {
    window.addEventListener('load', openSetupModal);
  }
</script>
<?php endif; ?>