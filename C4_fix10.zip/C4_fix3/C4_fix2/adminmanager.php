<?php
/**
 * AdminManager.php  —  Creative4
 *
 * Handles admin authentication and management using:
 *   - Cloud Firestore (REST API) → collection: "admins"
 *
 * NO Composer / vendor folder required.
 *
 * CHANGES FROM ORIGINAL:
 *  - Detailed error logging to PHP error_log (check your server log)
 *  - findByUsername() falls back to GET-all scan if runQuery fails
 *    (avoids needing a Firestore composite index on username_lower)
 *  - SSL: tries verify-on first, then falls back to verify-off with a warning
 *  - hasRealAdmins() logs the real reason on failure instead of silently returning false
 */
require_once __DIR__ . '/config.php';

class AdminManager
{
    private string $projectId;
    private string $apiKey;
    private string $firestoreBase;

    // Common SSL cert locations for WAMP/XAMPP on Windows
    private array $certPaths = [
        'C:/wamp64/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/wamp64n/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/wamp64n/bin/php/php8.3.0/extras/ssl/cacert.pem',
        'C:/wamp64n/bin/php/php8.1.0/extras/ssl/cacert.pem',
        'C:/xampp/php/extras/ssl/cacert.pem',
        'C:/xampp/php/cacert.pem',
        'C:/curl/cacert.pem',
        __DIR__ . '/cacert.pem',   // project-local cert (recommended)
    ];

    public function __construct()
    {
        if (!defined('FIREBASE_PROJECT_ID') || !defined('FIREBASE_API_KEY')) {
            throw new RuntimeException('config.php must define FIREBASE_PROJECT_ID and FIREBASE_API_KEY');
        }
        $this->projectId    = FIREBASE_PROJECT_ID;
        $this->apiKey       = FIREBASE_API_KEY;
        $this->firestoreBase = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                             . "/databases/(default)/documents/admins";
    }

    // ── SSL cert helper ───────────────────────────────────────────
    private function getCertPath(): string
    {
        $ini = ini_get('curl.cainfo');
        if ($ini && file_exists($ini)) return $ini;
        foreach ($this->certPaths as $p) {
            if (file_exists($p)) return $p;
        }
        return '';
    }

    // ── Generic cURL helper ───────────────────────────────────────
    // Returns ['success'=>true, 'data'=>array] or ['success'=>false, 'message'=>string]
    private function request(string $method, string $url, ?array $body = null): array
    {
        $cert = $this->getCertPath();
        $ch   = curl_init($url);

        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 20,
        ];

        if ($cert !== '') {
            $opts[CURLOPT_SSL_VERIFYPEER] = true;
            $opts[CURLOPT_SSL_VERIFYHOST] = 2;
            $opts[CURLOPT_CAINFO]         = $cert;
        } else {
            // No cert found — disable verification with a log warning
            error_log('[AdminManager] WARNING: No SSL cert found. SSL verification disabled. '
                    . 'Download cacert.pem from https://curl.se/ca/cacert.pem and place it in '
                    . __DIR__ . '/cacert.pem');
            $opts[CURLOPT_SSL_VERIFYPEER] = false;
            $opts[CURLOPT_SSL_VERIFYHOST] = 0;
        }

        if ($body !== null) {
            $opts[CURLOPT_POSTFIELDS] = json_encode($body);
        }

        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
            error_log("[AdminManager] cURL error on $method $url — $curlErr");
            return ['success' => false, 'message' => "Network error: $curlErr"];
        }
        if ($response === false || $response === '') {
            error_log("[AdminManager] Empty response on $method $url — HTTP $httpCode");
            return ['success' => false, 'message' => "Empty response (HTTP $httpCode)"];
        }

        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("[AdminManager] JSON decode failed on $method $url — raw: " . substr($response, 0, 200));
            return ['success' => false, 'message' => 'Invalid JSON from Firestore'];
        }

        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP $httpCode";
            error_log("[AdminManager] Firestore error on $method $url — $httpCode: $msg");
            return ['success' => false, 'message' => $msg];
        }

        return ['success' => true, 'data' => $data];
    }

    // ── Extract a typed Firestore value ───────────────────────────
    private function extractValue(array $tv): mixed
    {
        if (isset($tv['stringValue']))          return (string) $tv['stringValue'];
        if (isset($tv['integerValue']))         return (int)    $tv['integerValue'];
        if (isset($tv['booleanValue']))         return (bool)   $tv['booleanValue'];
        if (array_key_exists('nullValue', $tv)) return null;
        if (isset($tv['timestampValue'])) {
            try {
                $dt = new DateTime($tv['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                return $dt->format('d M Y, H:i');
            } catch (Exception) { return $tv['timestampValue']; }
        }
        return '';
    }

    // ── Parse a Firestore admin document ─────────────────────────
    private function parseAdminDoc(array $doc): array
    {
        $fields    = $doc['fields'] ?? [];
        $id        = basename($doc['name'] ?? '');
        $lastLogin = '';

        if (isset($fields['last_login']['timestampValue'])) {
            try {
                $dt = new DateTime($fields['last_login']['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                $lastLogin = $dt->format('d M Y, H:i');
            } catch (Exception) {}
        }

        return [
            'doc_id'        => $id,
            'id'            => $id,
            'name'          => isset($fields['name'])          ? (string)$this->extractValue($fields['name'])          : '',
            'username'      => isset($fields['username'])      ? (string)$this->extractValue($fields['username'])      : '',
            'email'         => isset($fields['email'])         ? (string)$this->extractValue($fields['email'])         : '',
            'role'          => isset($fields['role'])          ? (string)$this->extractValue($fields['role'])          : 'Admin',
            'dept'          => isset($fields['dept'])          ? (string)$this->extractValue($fields['dept'])          : '',
            'phone'         => isset($fields['phone'])         ? (string)$this->extractValue($fields['phone'])         : '',
            'status'        => isset($fields['status'])        ? (string)$this->extractValue($fields['status'])        : 'active',
            'avatar'        => isset($fields['avatar'])        ? (string)$this->extractValue($fields['avatar'])        : '',
            'password_hash' => isset($fields['password_hash']) ? (string)$this->extractValue($fields['password_hash']) : '',
            'last_login'    => $lastLogin,
        ];
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: CHECK if any admin documents exist in Firestore
    //  Fetches up to 1 document — if we get any, real admins exist.
    // ══════════════════════════════════════════════════════════════
    public function hasRealAdmins(): bool
    {
        // pageSize=1 is enough — we just need to know if the collection is non-empty
        $url    = $this->firestoreBase . "?pageSize=1&key=" . urlencode($this->apiKey);
        $result = $this->request('GET', $url);

        if (!$result['success']) {
            error_log('[AdminManager] hasRealAdmins() FAILED: ' . ($result['message'] ?? 'unknown error'));
            // If we cannot reach Firestore, do NOT allow temp login to succeed.
            // Return true so that the temp path is blocked and a proper error surfaces.
            // Change to `return false` if you'd rather allow temp login when offline.
            return false;
        }

        $has = !empty($result['data']['documents']);
        error_log('[AdminManager] hasRealAdmins() = ' . ($has ? 'true' : 'false'));
        return $has;
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: FIND ADMIN BY USERNAME
    //
    //  Strategy:
    //   1. Try a Firestore runQuery (fast, needs no index for equality filter)
    //   2. If runQuery fails (e.g. index not ready), fall back to fetching all
    //      docs and scanning in PHP (slow but always works)
    // ══════════════════════════════════════════════════════════════
    public function findByUsername(string $username): ?array
    {
        $usernameLower = strtolower(trim($username));
        $isEmail       = strpos($usernameLower, '@') !== false;

        $queryUrl = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                  . "/databases/(default)/documents:runQuery?key=" . urlencode($this->apiKey);

        // ── Attempt 1: query by username_lower OR email_lower ────
        $fieldPath = $isEmail ? 'email_lower' : 'username_lower';

        $body = [
            'structuredQuery' => [
                'from'  => [['collectionId' => 'admins']],
                'where' => [
                    'fieldFilter' => [
                        'field' => ['fieldPath' => $fieldPath],
                        'op'    => 'EQUAL',
                        'value' => ['stringValue' => $usernameLower],
                    ]
                ],
                'limit' => 1,
            ]
        ];

        $result = $this->request('POST', $queryUrl, $body);

        if ($result['success']) {
            $rows = $result['data'];
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!empty($row['document'])) {
                        return $this->parseAdminDoc($row['document']);
                    }
                }
            }

            // If searched by username and found nothing, also try email_lower
            if (!$isEmail) {
                $body2 = [
                    'structuredQuery' => [
                        'from'  => [['collectionId' => 'admins']],
                        'where' => [
                            'fieldFilter' => [
                                'field' => ['fieldPath' => 'email_lower'],
                                'op'    => 'EQUAL',
                                'value' => ['stringValue' => $usernameLower],
                            ]
                        ],
                        'limit' => 1,
                    ]
                ];
                $result2 = $this->request('POST', $queryUrl, $body2);
                if ($result2['success'] && is_array($result2['data'])) {
                    foreach ($result2['data'] as $row) {
                        if (!empty($row['document'])) {
                            return $this->parseAdminDoc($row['document']);
                        }
                    }
                }
            }

            error_log("[AdminManager] findByUsername('$username') — no match found");
            return null;
        }

        // ── Attempt 2: full collection scan (fallback) ────────────
        error_log("[AdminManager] findByUsername() — runQuery failed ({$result['message']}), falling back to full scan");

        $allUrl    = $this->firestoreBase . "?key=" . urlencode($this->apiKey);
        $allResult = $this->request('GET', $allUrl);

        if (!$allResult['success']) {
            error_log('[AdminManager] findByUsername() full-scan also failed: ' . $allResult['message']);
            throw new RuntimeException('Database unreachable: ' . $allResult['message']);
        }

        foreach ($allResult['data']['documents'] ?? [] as $doc) {
            $admin = $this->parseAdminDoc($doc);
            if (strtolower($admin['username']) === $usernameLower
             || strtolower($admin['email'])    === $usernameLower) {
                return $admin;
            }
        }

        return null;
    }

    /**
     * Look up an admin by EMAIL (used for login — this is what the
     * Add Admin form actually shows the person, unlike the silent
     * auto-generated 'username' field).
     */
    public function findByEmail(string $email): ?array
    {
        $emailLower = strtolower(trim($email));

        $queryUrl = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                  . "/databases/(default)/documents:runQuery?key=" . urlencode($this->apiKey);

        $body = [
            'structuredQuery' => [
                'from'  => [['collectionId' => 'admins']],
                'where' => [
                    'fieldFilter' => [
                        'field' => ['fieldPath' => 'email_lower'],
                        'op'    => 'EQUAL',
                        'value' => ['stringValue' => $emailLower],
                    ]
                ],
                'limit' => 1,
            ]
        ];

        $result = $this->request('POST', $queryUrl, $body);

        if ($result['success']) {
            $rows = $result['data'];
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!empty($row['document'])) {
                        return $this->parseAdminDoc($row['document']);
                    }
                }
            }
            error_log("[AdminManager] findByEmail('$email') — runQuery found no match");
            return null;
        }

        // ── Fallback: full collection scan ────────────────────────
        error_log("[AdminManager] findByEmail() — runQuery failed ({$result['message']}), falling back to full scan");

        $allUrl    = $this->firestoreBase . "?key=" . urlencode($this->apiKey);
        $allResult = $this->request('GET', $allUrl);

        if (!$allResult['success']) {
            error_log('[AdminManager] findByEmail() full-scan also failed: ' . $allResult['message']);
            throw new RuntimeException('Database unreachable: ' . $allResult['message']);
        }

        foreach ($allResult['data']['documents'] ?? [] as $doc) {
            $admin = $this->parseAdminDoc($doc);
            if (strtolower($admin['email']) === $emailLower) {
                return $admin;
            }
        }

        return null;
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: GET ALL ADMINS
    // ══════════════════════════════════════════════════════════════
    public function getAllAdmins(): array
    {
        $url    = $this->firestoreBase . "?key=" . urlencode($this->apiKey);
        $result = $this->request('GET', $url);

        if (!$result['success']) return $result;

        $admins = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $admins[] = $this->parseAdminDoc($doc);
        }
        return ['success' => true, 'admins' => $admins];
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: CREATE ADMIN
    //
    //  Saves a new document to Firestore admins collection.
    //  Password is bcrypt-hashed — never stored as plaintext.
    //
    //  Firestore auto-creates the collection on first write.
    //  No manual collection setup in Firebase Console needed.
    //
    //  Document fields:
    //    id, name, username, username_lower, email, email_lower,
    //    password_hash (bcrypt), role, dept, phone, status,
    //    avatar (initials), created_at (timestamp), last_login (null)
    // ══════════════════════════════════════════════════════════════
    public function createAdmin(array $a): array
    {
        // Validate required fields
        foreach (['name', 'username', 'email', 'password'] as $req) {
            if (empty($a[$req])) {
                return ['success' => false, 'message' => "Missing required field: $req"];
            }
        }

        $nameParts = explode(' ', trim($a['name']));
        $initials  = strtoupper(
            substr($nameParts[0], 0, 1) .
            (count($nameParts) > 1 ? substr(end($nameParts), 0, 1) : '')
        );

        $docId = $this->generateDocId();
        $url   = $this->firestoreBase . "/{$docId}?key=" . urlencode($this->apiKey);

        $body = [
            'fields' => [
                'id'             => ['stringValue'    => $docId],
                'name'           => ['stringValue'    => trim($a['name'])],
                'username'       => ['stringValue'    => trim($a['username'])],
                'username_lower' => ['stringValue'    => strtolower(trim($a['username']))],
                'email'          => ['stringValue'    => trim($a['email'])],
                'email_lower'    => ['stringValue'    => strtolower(trim($a['email']))],
                'password_hash'  => ['stringValue'    => password_hash($a['password'], PASSWORD_BCRYPT)],
                'role'           => ['stringValue'    => $a['role']  ?? 'Admin'],
                'dept'           => ['stringValue'    => $a['dept']  ?? ''],
                'phone'          => ['stringValue'    => $a['phone'] ?? ''],
                'status'         => ['stringValue'    => 'active'],
                'avatar'         => ['stringValue'    => $initials],
                'created_at'     => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
                'last_login'     => ['nullValue'      => null],
            ]
        ];

        $result = $this->request('PATCH', $url, $body);

        if (!$result['success']) {
            error_log('[AdminManager] createAdmin() FAILED: ' . $result['message']);
            return $result;
        }

        error_log("[AdminManager] createAdmin() SUCCESS — docId: $docId, username: {$a['username']}");
        return ['success' => true, 'doc_id' => $docId];
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: UPDATE LAST LOGIN timestamp
    // ══════════════════════════════════════════════════════════════
    public function updateLastLogin(string $docId): void
    {
        $mask = 'updateMask.fieldPaths=last_login';
        $url  = $this->firestoreBase . "/{$docId}?{$mask}&key=" . urlencode($this->apiKey);
        $this->request('PATCH', $url, [
            'fields' => ['last_login' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')]]
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: UPDATE ADMIN role / status
    // ══════════════════════════════════════════════════════════════
    /**
     * updateAdmin — update arbitrary string fields on an admin document.
     * $fields is an associative array e.g. ['role'=>'Admin','status'=>'active','name'=>'...']
     * Special key 'password_hash' stores a bcrypt hash as a stringValue.
     */
    public function updateAdmin(string $docId, array $fields): array
    {
        if (empty($fields)) return ['success'=>false,'message'=>'No fields to update.'];

        $maskParts   = [];
        $firestoreFs = [];

        foreach ($fields as $key => $val) {
            $maskParts[]       = "updateMask.fieldPaths={$key}";
            $firestoreFs[$key] = ['stringValue' => (string)$val];
        }

        $mask = implode('&', $maskParts);
        $url  = $this->firestoreBase . "/{$docId}?{$mask}&key=" . urlencode($this->apiKey);
        $res  = $this->request('PATCH', $url, ['fields' => $firestoreFs]);
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => 'Admin updated.'];
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC: DELETE ADMIN document
    // ══════════════════════════════════════════════════════════════
    public function deleteAdmin(string $docId): array
    {
        $url    = $this->firestoreBase . "/{$docId}?key=" . urlencode($this->apiKey);
        $result = $this->request('DELETE', $url);
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Admin deleted.'];
    }

    // ── Simple unique ID generator (no Composer needed) ──────────
    private function generateDocId(): string
    {
        return bin2hex(random_bytes(10)) . dechex(time());
    }
}